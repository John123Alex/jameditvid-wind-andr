// Copia el núcleo de FFmpeg (WebAssembly) a /public/ffmpeg para que la app
// funcione sin depender de un CDN (también offline una vez instalada).
import { mkdirSync, copyFileSync, existsSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const src = join(root, 'node_modules', '@ffmpeg', 'core', 'dist', 'esm');
const dest = join(root, 'public', 'ffmpeg');

if (!existsSync(src)) {
  console.warn('[ffmpeg] @ffmpeg/core no está instalado; se omite la copia.');
  process.exit(0);
}
mkdirSync(dest, { recursive: true });
for (const f of ['ffmpeg-core.js', 'ffmpeg-core.wasm']) {
  copyFileSync(join(src, f), join(dest, f));
}
console.log('[ffmpeg] Núcleo copiado a public/ffmpeg');
