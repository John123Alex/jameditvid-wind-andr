# JamEditVid — Editor de video web (PC y celular)

Editor de video que corre completo en el navegador: no sube tus archivos a ningún servidor.
Funciona en Chrome, Edge, Firefox y Safari recientes, en PC, tablet y celular (se puede instalar como app).

## Funciones

- **Línea de tiempo multipista**: pistas ilimitadas de video y audio, arrastrar, recortar por los bordes, dividir, duplicar, borrar cerrando el hueco, imán (ajuste automático), zoom con rueda o pellizco, bloquear/ocultar/silenciar pistas.
- **Vista previa en tiempo real con GPU (WebGL2)**: arrastra el clip en la vista previa para moverlo, rueda o pellizco para escalarlo, calidad de previsualización ajustable, captura de fotograma a PNG.
- **38 efectos**, combinables y reordenables: ajustes de color, looks de cine, B/N, sepia, duotono, posterizar, resaltar un color, desenfoque, nitidez, zoom blur, tilt-shift, viñeta, bloom, fuga de luz, glitch, VHS, grano, CRT, neón, semitono, visión térmica y nocturna, película antigua, ondas, remolino, ojo de pez, caleidoscopio, espejo, sacudida de cámara, pulso al ritmo, gota de agua, **croma (pantalla verde)** y luma key.
- **Animaciones** de entrada y salida (fundido, deslizar, zoom, girar, pop, enfocar, máquina de escribir) y movimiento continuo (Ken Burns, paneo, flotar).
- **Textos** con estilos rápidos, contorno, sombra, caja de fondo y fuentes.
- **Audio**: volumen por clip, fundidos de entrada y salida, velocidad, silencio por pista, forma de onda.
- **Exportación** a MP4, H.265, WebM, MOV, MKV, AVI, 3GP, GIF, WebP animado, MP3, WAV, M4A, OGG, Opus, FLAC, PNG y JPG, **en cualquier resolución** (4K, vertical para Reels/TikTok, cuadrado, personalizada).
- **Convertidor universal** de archivos sueltos o en cola: formato, dimensiones (encajar, recortar o estirar), FPS, calidad, recorte de tiempo, rotar, espejo, velocidad, volumen, quitar audio y **argumentos propios de FFmpeg** para casos avanzados.
- **Autoguardado** del proyecto y de los medios en el dispositivo (IndexedDB) y deshacer/rehacer ilimitado.

## Ejecutar

```bash
npm install        # instala y copia el motor FFmpeg a public/ffmpeg
npm run dev        # http://localhost:5173  (también se muestra la IP para abrirlo desde el celular en la misma red)
npm run build      # genera dist/ para publicar
npm run preview    # prueba local de la versión de producción
```

### Publicar en tu servidor
Sube el contenido de `dist/`. Para que FFmpeg rinda al máximo configura estas cabeceras (ejemplo Apache `.htaccess`):

```apache
Header set Cross-Origin-Opener-Policy "same-origin"
Header set Cross-Origin-Embedder-Policy "require-corp"
AddType application/wasm .wasm
```

Para instalarla en el celular («Agregar a pantalla de inicio») el sitio debe servirse por **HTTPS**.

## Arquitectura

```
src/
├── main.js                 Punto de entrada
├── app/App.js              Crea los servicios y conecta los paneles (único archivo que conoce a todos)
├── core/                   Infraestructura sin dependencias
│   ├── Store.js            Estado del proyecto + deshacer/rehacer
│   ├── EventBus.js         Eventos entre módulos (time, playstate, toast…)
│   └── utils.js
├── model/                  Datos puros (JSON) y operaciones de edición
│   ├── project.js          Estructura de proyecto/pista/clip y selectores
│   └── clipOps.js          Dividir, recortar, mover, duplicar, imán…
├── media/                  Importación y almacenamiento
│   ├── MediaLibrary.js     Registro de medios, URL, imágenes decodificadas
│   ├── MediaStorage.js     IndexedDB (autoguardado)
│   ├── analysis.js         Metadatos, miniaturas y forma de onda
│   └── waveform.worker.js  Cálculo de la onda fuera del hilo principal
├── engine/                 Reproducción
│   ├── PlaybackEngine.js   Reloj maestro y bucle de render bajo demanda
│   ├── SourcePool.js       Elementos <video>/<audio> sincronizados (precarga del siguiente clip)
│   ├── AudioMixer.js       Mezcla con Web Audio
│   └── TextRenderer.js     Texto → textura (con caché)
├── render/                 GPU
│   ├── Compositor.js       Capas, efectos multipasada, transformaciones, modos de fusión
│   └── glUtils.js          Shaders, texturas y pool de framebuffers
├── effects/                Efectos y animaciones
│   ├── registry.js         Registro (añadir un efecto = una definición)
│   ├── definitions/*.js    color, blur, stylize, distort
│   ├── glslPrelude.js      Funciones GLSL comunes
│   └── animations.js       Entradas, salidas y movimiento
├── export/
│   ├── Exporter.js         Render del proyecto (MediaRecorder) + conversión
│   ├── FFmpegService.js    FFmpeg WebAssembly en un worker (cancelable)
│   ├── commandBuilder.js   Opciones → argumentos de FFmpeg (función pura)
│   └── formats.js          Catálogo de formatos y resoluciones
├── ui/                     Interfaz (sin framework)
│   ├── panels/             Medios, Vista previa, Propiedades, Línea de tiempo
│   ├── dialogs/            Exportar, Convertidor, resultado
│   ├── TopBar.js, MobileNav.js, shortcuts.js
│   └── dom.js, icons.js, controls.js, feedback.js
└── styles/                 variables (colores), layout, componentes, timeline, responsive
```

**Flujo de datos**: la interfaz llama a `store.update(draft => …)` con funciones de `model/clipOps.js` → el Store notifica → paneles y motor se actualizan. El tiempo de reproducción no pasa por el Store (cambia 60 veces por segundo): lo publica el motor con el evento `time`.

## Cómo extenderlo

**Nuevo efecto**: agrega un objeto en `src/effects/definitions/<categoria>.js`. Los controles del inspector se generan solos.

```js
{
  id: 'miEfecto', name: 'Mi efecto', category: 'stylize', animated: false,
  params: [range('fuerza', 'Fuerza', 0, 1, 0.5)],
  glsl: `void main(){ vec4 c = tex(v_uv); emit(vec4(c.rgb * u_fuerza, c.a)); }`,
}
```

**Nuevo formato de salida**: añade una entrada en `src/export/formats.js` con sus argumentos de video/audio.
**Nueva animación**: añade un `case` en `apply()` de `src/effects/animations.js` y su opción en `ANIM_IN`/`ANIM_OUT`.
**Nuevo estilo de texto o fuente**: `src/ui/panels/textPresets.js`.
**Colores y medidas de la interfaz**: `src/styles/variables.css`.

## Rendimiento: por qué no se congela

- Efectos y composición en la **GPU**; los efectos trabajan a la resolución útil, nunca mayor que la salida.
- Render **bajo demanda**: en pausa solo se dibuja cuando algo cambia.
- Vista previa en calidad **automática**: solo calcula los píxeles que se ven en pantalla.
- **FFmpeg** y la forma de onda corren en **Web Workers**: la interfaz sigue respondiendo mientras convierte.
- Arrastrar o recortar en la línea de tiempo solo mueve el elemento; se guarda una vez al soltar.
- Los controles deslizantes agrupan sus cambios en un solo paso de deshacer.
- El siguiente clip se **precarga** antes de llegar al corte.
- Al exportar, si un video no tiene listo su fotograma, la grabación se pausa en lugar de grabar un salto.

## Límites a tener en cuenta

- La exportación del proyecto se renderiza **en tiempo real** (un video de 1 minuto tarda ~1 minuto), con la pestaña visible.
  Si el formato final no es el que graba el navegador, después se convierte con FFmpeg.
- FFmpeg en el navegador usa la CPU (sin aceleración por hardware): convertir videos largos en 4K puede tardar.
  Para MP4 se usa el preset `veryfast` para priorizar la velocidad.
- Los archivos muy grandes (> ~1,5 GB) pueden superar la memoria disponible para WebAssembly, sobre todo en celulares.
- En iPhone, Safari limita cuántos videos se decodifican a la vez: con muchas pistas de video superpuestas puede ir más lento.
