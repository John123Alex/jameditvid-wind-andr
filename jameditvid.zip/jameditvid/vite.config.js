import { defineConfig } from 'vite';

// Cabeceras de aislamiento (COOP/COEP): permiten SharedArrayBuffer y
// mejoran el rendimiento de FFmpeg/WebAssembly. Si despliegas en tu propio
// servidor, configura estas mismas cabeceras allí.
const isolation = {
  'Cross-Origin-Opener-Policy': 'same-origin',
  'Cross-Origin-Embedder-Policy': 'require-corp',
};

export default defineConfig({
  base: './',
  server: { headers: isolation },
  preview: { headers: isolation },
  optimizeDeps: { exclude: ['@ffmpeg/ffmpeg', '@ffmpeg/util'] },
  worker: { format: 'es' },
  build: { target: 'es2022', chunkSizeWarningLimit: 1500 },
});
