/**
 * Composición de la aplicación: crea los servicios y conecta los paneles.
 * Es el único archivo que "conoce" a todos; el resto se comunica por
 * el Store (datos) y el EventBus (eventos).
 */
import { EventBus } from '../core/EventBus.js';
import { Store } from '../core/Store.js';
import { debounce } from '../core/utils.js';
import { createProject, PROJECT_VERSION } from '../model/project.js';
import { addTextClip } from '../model/clipOps.js';
import { MediaStorage } from '../media/MediaStorage.js';
import { MediaLibrary } from '../media/MediaLibrary.js';
import { Compositor } from '../render/Compositor.js';
import { AudioMixer } from '../engine/AudioMixer.js';
import { PlaybackEngine } from '../engine/PlaybackEngine.js';
import { FFmpegService } from '../export/FFmpegService.js';
import { Exporter } from '../export/Exporter.js';
import { effectDefinitions } from '../effects/registry.js';
import { TopBar } from '../ui/TopBar.js';
import { MediaPanel } from '../ui/panels/MediaPanel.js';
import { PreviewPanel } from '../ui/panels/PreviewPanel.js';
import { InspectorPanel } from '../ui/panels/InspectorPanel.js';
import { TimelinePanel } from '../ui/panels/TimelinePanel.js';
import { openExportDialog } from '../ui/dialogs/ExportDialog.js';
import { openConverterDialog } from '../ui/dialogs/ConverterDialog.js';
import { initToasts, confirmDialog } from '../ui/feedback.js';
import { bindShortcuts } from '../ui/shortcuts.js';
import { MobileNav } from '../ui/MobileNav.js';
import { h } from '../ui/dom.js';

export class App {
  async start() {
    const bus = new EventBus();
    initToasts(bus, document.getElementById('toasts'));

    // ---- Servicios ----
    const storage = new MediaStorage();
    const media = new MediaLibrary({ bus, storage });
    await media.restore().catch((e) => console.warn('No se pudieron restaurar medios', e));
    const saved = await storage.loadProject().catch(() => null);
    const project = saved?.version === PROJECT_VERSION ? sanitizeProject(saved, media) : createProject();
    const store = new Store(project);

    const canvas = h('canvas');
    const compositor = new Compositor(canvas);
    compositor.onError = (err) => bus.emit('toast', { type: 'error', text: `Error de render: ${err.message.split('\n')[0]}` });
    const mixer = new AudioMixer();
    const engine = new PlaybackEngine({ store, bus, media, compositor, mixer });
    const ffmpeg = new FFmpegService(bus);
    const exporter = new Exporter({ engine, compositor, mixer, ffmpeg, bus });

    // Compilar los efectos en segundo plano evita tirones al aplicarlos por primera vez.
    const idle = window.requestIdleCallback || ((fn) => setTimeout(fn, 300));
    idle(() => {
      const errors = compositor.warmup(effectDefinitions());
      if (errors.length) console.warn('Efectos con error de compilación:', errors);
    });

    // ---- Acciones globales ----
    const actions = {
      openExport: () => openExportDialog({ store, engine, exporter, bus }),
      openConverter: () => openConverterDialog({ ffmpeg, bus }),
      addText: () => {
        let c;
        store.update((d) => { c = addTextClip(d, engine.time); }, { label: 'Añadir texto' });
        store.select(c.id);
        bus.emit('ui:show-panel', 'inspector');
      },
      newProject: async () => {
        const ok = await confirmDialog('Se borrará el proyecto actual y sus medios de este dispositivo. ¿Empezar uno nuevo?', { okText: 'Nuevo proyecto', danger: true });
        if (!ok) return;
        engine.pause();
        engine.pool.disposeAll();
        await media.clear();
        store.replace(createProject());
        engine.seek(0);
      },
    };

    // ---- Interfaz ----
    new TopBar(document.getElementById('topbar'), { store, bus, actions });
    new MediaPanel(document.getElementById('panel-media'), { store, bus, media, engine });
    new PreviewPanel(document.getElementById('panel-preview'), { store, bus, engine, compositor, exporter });
    new InspectorPanel(document.getElementById('panel-inspector'), { store, bus, media });
    const timeline = new TimelinePanel(document.getElementById('panel-timeline'), { store, bus, engine, media });
    new MobileNav(document.getElementById('mobile-nav'), { bus, store, actions });
    bindShortcuts({ store, engine, timeline, actions });
    setupTimelineResizer();

    // ---- Autoguardado ----
    const save = debounce(() => storage.saveProject(store.project).then(() => bus.emit('project:saved')).catch((e) => console.warn(e)), 800);
    store.subscribe((c) => { if (c.type === 'project') save(); });
    window.addEventListener('pagehide', () => save.flush());
    storage.requestPersistence();

    // Al seleccionar un clip en el celular, mostrar sus propiedades rápidamente.
    store.subscribe((c) => { if (c.type === 'selection' && !store.selection) bus.emit('ui:selection-cleared'); });

    engine.requestRender();
    document.body.classList.add('ready');
    if (import.meta.env.DEV) Object.assign(window, { jam: { store, engine, media, compositor, ffmpeg, exporter, bus } });
  }
}

/** Limpia referencias a medios que ya no existen (p. ej. almacenamiento borrado). */
function sanitizeProject(project, media) {
  project.clips = project.clips.filter((c) => !c.mediaId || media.get(c.mediaId));
  return project;
}

/** Permite cambiar la altura de la línea de tiempo arrastrando el divisor. */
function setupTimelineResizer() {
  const handle = document.getElementById('timeline-resizer');
  const app = document.getElementById('app');
  const savedH = localStorage.getItem('jam.timelineH');
  if (savedH) app.style.setProperty('--timeline-h', `${savedH}px`);
  handle.addEventListener('pointerdown', (e) => {
    handle.setPointerCapture(e.pointerId);
    const startY = e.clientY;
    const startH = document.getElementById('panel-timeline').getBoundingClientRect().height;
    const move = (ev) => {
      const hgt = Math.min(window.innerHeight * 0.7, Math.max(140, startH - (ev.clientY - startY)));
      app.style.setProperty('--timeline-h', `${hgt}px`);
    };
    const up = () => {
      handle.removeEventListener('pointermove', move);
      handle.removeEventListener('pointerup', up);
      localStorage.setItem('jam.timelineH', String(parseInt(getComputedStyle(app).getPropertyValue('--timeline-h'), 10)));
    };
    handle.addEventListener('pointermove', move);
    handle.addEventListener('pointerup', up);
  });
}
