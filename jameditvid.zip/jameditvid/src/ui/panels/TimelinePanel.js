/**
 * Línea de tiempo multipista con soporte táctil.
 *
 * Rendimiento:
 *  - Durante un arrastre solo se mueve el elemento DOM (sin tocar el store);
 *    al soltar se guarda UNA vez (un paso de deshacer).
 *  - La regla se dibuja en un canvas del tamaño de la parte visible.
 *  - El cabezal se mueve con transform (sin re-layout).
 */
import { h } from '../dom.js';
import { icon } from '../icons.js';
import { formatTime, clamp, rafThrottle } from '../../core/utils.js';
import { clipEnd, projectDuration, trackAccepts, createTrack } from '../../model/project.js';
import {
  splitClip, deleteClip, rippleDelete, duplicateClip, trimClip, snapTime, resolveOverlap, addMediaClip, findClip,
} from '../../model/clipOps.js';

const HEADER_W = 132;
const RULER_H = 26;
const LANE_H = { video: 64, audio: 48 };
const MIN_PPS = 4;
const MAX_PPS = 800;

export class TimelinePanel {
  pps = Number(localStorage.getItem('jam.pps')) || 60; // píxeles por segundo
  snapping = localStorage.getItem('jam.snap') !== '0';

  #clipEls = new Map();
  #laneEls = new Map();
  #drag = null;

  constructor(root, { store, bus, engine, media }) {
    Object.assign(this, { root, store, bus, engine, media });
    this.#buildDOM();
    this.#bindInteractions();

    const rerender = rafThrottle(() => this.render());
    store.subscribe(rerender);
    bus.on('media:changed', rerender);
    bus.on('time', (t) => this.#updatePlayhead(t));
    new ResizeObserver(() => { this.#drawRuler(); this.#updateContentWidth(); }).observe(this.scroll);
    this.render();
  }

  // ------------------------------------------------------------------ DOM
  #buildDOM() {
    const btn = (ic, title, fn, cls = '') => h('button', { class: `icon-btn ${cls}`, title, onclick: fn }, icon(ic));
    this.undoBtn = btn('undo', 'Deshacer (Ctrl+Z)', () => this.store.undo());
    this.redoBtn = btn('redo', 'Rehacer (Ctrl+Y)', () => this.store.redo());
    this.snapBtn = btn('magnet', 'Imán / ajuste automático', () => this.toggleSnap(), this.snapping ? 'on' : '');
    this.zoomRange = h('input', { type: 'range', class: 'range zoom', min: 0, max: 1, step: 0.001, value: this.#ppsToZoom(this.pps),
      oninput: () => this.setZoom(this.#zoomToPps(Number(this.zoomRange.value))) });

    this.toolbar = h('div', { class: 'tl-toolbar' },
      h('div', { class: 'row gap-xs' }, this.undoBtn, this.redoBtn),
      h('span', { class: 'sep' }),
      h('div', { class: 'row gap-xs' },
        btn('split', 'Dividir en el cabezal (S)', () => this.splitAtPlayhead()),
        btn('copy', 'Duplicar (Ctrl+D)', () => this.duplicateSelected()),
        btn('trash', 'Eliminar (Supr) · Mayús+Supr cierra el hueco', (e) => this.deleteSelected(e.shiftKey))),
      h('span', { class: 'sep' }),
      this.snapBtn,
      h('div', { class: 'row gap-xs zoom-group' },
        btn('zoomOut', 'Alejar (−)', () => this.setZoom(this.pps / 1.4)),
        this.zoomRange,
        btn('zoomIn', 'Acercar (+)', () => this.setZoom(this.pps * 1.4)),
        btn('fit', 'Ajustar a la vista', () => this.zoomToFit())),
      h('span', { class: 'spacer' }),
      h('div', { class: 'row gap-xs' },
        h('button', { class: 'btn small ghost', onclick: () => this.addTrack('video'), title: 'Nueva pista de video' }, icon('plus', 14), h('span', {}, 'Video')),
        h('button', { class: 'btn small ghost', onclick: () => this.addTrack('audio'), title: 'Nueva pista de audio' }, icon('plus', 14), h('span', {}, 'Audio'))),
    );

    this.ruler = h('canvas', { class: 'tl-ruler' });
    this.lanes = h('div', { class: 'tl-lanes' });
    this.playhead = h('div', { class: 'tl-playhead' }, h('div', { class: 'tl-playhead-knob' }));
    this.snapLine = h('div', { class: 'tl-snapline' });
    this.inner = h('div', { class: 'tl-inner' },
      h('div', { class: 'tl-ruler-row', style: { height: `${RULER_H}px` } },
        h('div', { class: 'tl-corner', style: { width: `${HEADER_W}px` } }, h('span', { class: 'timecode small' })),
        this.ruler),
      this.lanes, this.playhead, this.snapLine);
    this.scroll = h('div', { class: 'tl-scroll' }, this.inner);
    this.corner = this.inner.querySelector('.tl-corner .timecode');
    this.root.append(this.toolbar, this.scroll);
    this.scroll.addEventListener('scroll', () => this.#drawRuler(), { passive: true });
  }

  // --------------------------------------------------------------- Render
  render() {
    const p = this.store.project;
    this.undoBtn.disabled = !this.store.canUndo;
    this.redoBtn.disabled = !this.store.canRedo;

    // Pistas
    const aliveTracks = new Set();
    p.tracks.forEach((track, i) => {
      aliveTracks.add(track.id);
      let row = this.#laneEls.get(track.id);
      if (!row) {
        row = this.#createTrackRow(track);
        this.#laneEls.set(track.id, row);
      }
      this.#updateTrackRow(row, track, i, p.tracks.length);
      if (this.lanes.children[i] !== row.el) this.lanes.insertBefore(row.el, this.lanes.children[i] ?? null);
    });
    for (const [id, row] of this.#laneEls) if (!aliveTracks.has(id)) { row.el.remove(); this.#laneEls.delete(id); }

    // Clips
    const alive = new Set();
    for (const clip of p.clips) {
      alive.add(clip.id);
      let el = this.#clipEls.get(clip.id);
      if (!el) { el = this.#createClipEl(clip); this.#clipEls.set(clip.id, el); }
      this.#updateClipEl(el, clip);
      const lane = this.#laneEls.get(clip.trackId)?.lane;
      if (lane && el.parentNode !== lane) lane.append(el);
    }
    for (const [id, el] of this.#clipEls) if (!alive.has(id)) { el.remove(); this.#clipEls.delete(id); }

    this.#updateContentWidth();
    this.#drawRuler();
    this.#updatePlayhead(this.engine.time);
  }

  #createTrackRow(track) {
    const name = h('span', { class: 'tl-track-name', title: 'Doble clic para renombrar' });
    name.addEventListener('dblclick', () => {
      const v = prompt('Nombre de la pista', track.name);
      if (v) this.store.update((d) => { d.tracks.find((t) => t.id === track.id).name = v; }, { label: 'Renombrar pista' });
    });
    const visBtn = h('button', { class: 'icon-btn sm' });
    const lockBtn = h('button', { class: 'icon-btn sm' });
    const upBtn = h('button', { class: 'icon-btn sm', title: 'Subir pista' }, icon('up', 13));
    const delBtn = h('button', { class: 'icon-btn sm', title: 'Eliminar pista' }, icon('x', 13));
    const header = h('div', { class: 'tl-track-header', style: { width: `${HEADER_W}px` } },
      h('div', { class: 'tl-track-title' }, icon(track.type === 'audio' ? 'music' : 'film', 13), name),
      h('div', { class: 'tl-track-btns' }, visBtn, lockBtn, upBtn, delBtn));
    const lane = h('div', { class: `tl-lane lane-${track.type}`, dataset: { track: track.id } });
    const el = h('div', { class: 'tl-track', style: { height: `${LANE_H[track.type]}px` } }, header, lane);

    const toggleProp = (prop) => this.store.update((d) => { const t = d.tracks.find((x) => x.id === track.id); t[prop] = !t[prop]; }, { label: 'Pista' });
    visBtn.onclick = () => toggleProp(track.type === 'audio' ? 'muted' : 'hidden');
    lockBtn.onclick = () => toggleProp('locked');
    upBtn.onclick = () => this.store.update((d) => {
      const i = d.tracks.findIndex((t) => t.id === track.id);
      if (i <= 0) return false;
      [d.tracks[i - 1], d.tracks[i]] = [d.tracks[i], d.tracks[i - 1]];
    }, { label: 'Reordenar pistas' });
    delBtn.onclick = () => {
      const n = this.store.project.clips.filter((c) => c.trackId === track.id).length;
      if (n && !confirm(`La pista tiene ${n} clip(s). ¿Eliminarla con su contenido?`)) return;
      this.store.update((d) => { d.tracks = d.tracks.filter((t) => t.id !== track.id); d.clips = d.clips.filter((c) => c.trackId !== track.id); }, { label: 'Eliminar pista' });
    };

    // Soltar medios desde el panel
    lane.addEventListener('dragover', (e) => { if ([...e.dataTransfer.types].includes('application/x-jam-media')) { e.preventDefault(); lane.classList.add('drop'); } });
    lane.addEventListener('dragleave', () => lane.classList.remove('drop'));
    lane.addEventListener('drop', (e) => {
      lane.classList.remove('drop');
      const id = e.dataTransfer.getData('application/x-jam-media');
      if (!id) return;
      e.preventDefault();
      e.stopPropagation();
      const item = this.media.get(id);
      if (!item) return;
      const t = Math.max(0, this.#timeAtClientX(e.clientX));
      let created;
      this.store.update((d) => { created = addMediaClip(d, item, t, track.id); }, { label: 'Soltar medio' });
      this.store.select(created.id);
    });
    return { el, lane, name, visBtn, lockBtn, upBtn };
  }

  #updateTrackRow(row, track, index) {
    row.name.textContent = track.name;
    const hiddenProp = track.type === 'audio' ? track.muted : track.hidden;
    row.visBtn.replaceChildren(icon(track.type === 'audio' ? (track.muted ? 'volumeX' : 'volume') : (track.hidden ? 'eyeOff' : 'eye'), 13));
    row.visBtn.title = track.type === 'audio' ? (track.muted ? 'Activar sonido' : 'Silenciar pista') : (track.hidden ? 'Mostrar pista' : 'Ocultar pista');
    row.visBtn.classList.toggle('off', hiddenProp);
    row.lockBtn.replaceChildren(icon(track.locked ? 'lock' : 'unlock', 13));
    row.lockBtn.title = track.locked ? 'Desbloquear' : 'Bloquear';
    row.lockBtn.classList.toggle('on', track.locked);
    row.upBtn.disabled = index === 0;
    row.el.classList.toggle('locked', track.locked);
    row.el.classList.toggle('muted', hiddenProp);
  }

  #createClipEl(clip) {
    const el = h('div', { class: `tl-clip clip-${clip.type}`, dataset: { id: clip.id } },
      h('div', { class: 'tl-clip-bg' }),
      h('div', { class: 'tl-clip-wave' }),
      h('div', { class: 'tl-clip-label' }, h('span', { class: 'tl-clip-name' }), h('span', { class: 'tl-clip-badges' })),
      h('div', { class: 'tl-handle left', dataset: { edge: 'start' } }),
      h('div', { class: 'tl-handle right', dataset: { edge: 'end' } }));
    return el;
  }

  #updateClipEl(el, clip) {
    el.style.transform = `translateX(${clip.start * this.pps}px)`;
    el.style.width = `${Math.max(2, clip.duration * this.pps)}px`;
    el.classList.toggle('selected', clip.id === this.store.selection);
    el.querySelector('.tl-clip-name').textContent = clip.type === 'text' ? clip.text.content.split('\n')[0] || 'Texto' : clip.name;
    const badges = [];
    if (clip.speed !== 1) badges.push(`${clip.speed}×`);
    if (clip.effects.length) badges.push(`✦${clip.effects.length}`);
    if (clip.muted) badges.push('🔇');
    el.querySelector('.tl-clip-badges').textContent = badges.join(' ');

    const media = clip.mediaId ? this.media.get(clip.mediaId) : null;
    const bg = el.querySelector('.tl-clip-bg');
    const wave = el.querySelector('.tl-clip-wave');
    if (media?.thumb && (clip.type === 'video' || clip.type === 'image')) {
      const key = media.thumb.length + media.id;
      if (bg.dataset.key !== key) { bg.style.backgroundImage = `url(${media.thumb})`; bg.dataset.key = key; }
    }
    if (media?.waveform && clip.type !== 'image') {
      // La forma de onda abarca el archivo completo y se desplaza según el punto de entrada.
      const full = (media.duration / clip.speed) * this.pps;
      wave.style.backgroundImage = `url(${media.waveform})`;
      wave.style.backgroundSize = `${full}px 100%`;
      wave.style.backgroundPosition = `${-(clip.offset / clip.speed) * this.pps}px 0`;
      wave.hidden = false;
    } else wave.hidden = true;
  }

  #contentWidth() {
    const d = projectDuration(this.store.project);
    const visible = Math.max(0, this.scroll.clientWidth - HEADER_W);
    return Math.max(visible, (d + 30) * this.pps);
  }

  #updateContentWidth() {
    this.inner.style.width = `${HEADER_W + this.#contentWidth()}px`;
  }

  #updatePlayhead(t) {
    const x = HEADER_W + t * this.pps;
    this.playhead.style.transform = `translateX(${x}px)`;
    this.corner.textContent = formatTime(t);
    // Seguir el cabezal durante la reproducción
    if (this.engine.playing && !this.#drag) {
      const left = this.scroll.scrollLeft;
      const w = this.scroll.clientWidth;
      if (x > left + w - 40 || x < left + HEADER_W) this.scroll.scrollLeft = x - HEADER_W - 40;
    }
  }

  #drawRuler() {
    const c = this.ruler;
    const w = Math.max(1, this.scroll.clientWidth - HEADER_W);
    const dpr = Math.min(devicePixelRatio || 1, 2);
    if (c.width !== Math.round(w * dpr)) { c.width = Math.round(w * dpr); c.height = Math.round(RULER_H * dpr); }
    c.style.width = `${w}px`;
    c.style.height = `${RULER_H}px`;
    const g = c.getContext('2d');
    g.setTransform(dpr, 0, 0, dpr, 0, 0);
    g.clearRect(0, 0, w, RULER_H);
    const css = getComputedStyle(this.root);
    g.fillStyle = css.getPropertyValue('--tl-ruler-text').trim() || '#999';
    g.strokeStyle = css.getPropertyValue('--tl-ruler-tick').trim() || '#555';
    g.font = '10px system-ui, sans-serif';
    g.textBaseline = 'top';

    const start = this.scroll.scrollLeft / this.pps;
    const end = start + w / this.pps;
    // Intervalo de marcas según el zoom (≥ ~70 px entre etiquetas)
    const steps = [1 / 30, 0.1, 0.25, 0.5, 1, 2, 5, 10, 15, 30, 60, 120, 300, 600];
    const major = steps.find((s) => s * this.pps >= 70) ?? 600;
    const minor = major / (major >= 1 ? 5 : 2);
    g.beginPath();
    for (let t = Math.floor(start / minor) * minor; t <= end; t += minor) {
      const x = Math.round((t - start) * this.pps) + 0.5;
      const isMajor = Math.abs(t / major - Math.round(t / major)) < 1e-6;
      g.moveTo(x, RULER_H);
      g.lineTo(x, isMajor ? 8 : RULER_H - 6);
      if (isMajor && t >= 0) g.fillText(major < 1 ? formatTime(t) : formatTime(t, false), x + 3, 3);
    }
    g.stroke();
  }

  // ---------------------------------------------------------- Interacción
  #timeAtClientX(clientX) {
    const r = this.scroll.getBoundingClientRect();
    return (clientX - r.left + this.scroll.scrollLeft - HEADER_W) / this.pps;
  }

  #bindInteractions() {
    const s = this.scroll;
    s.addEventListener('pointerdown', (e) => {
      if (e.button !== 0) return;
      const handle = e.target.closest('.tl-handle');
      const clipEl = e.target.closest('.tl-clip');
      const onRuler = e.target.closest('.tl-ruler-row');
      const onLane = e.target.closest('.tl-lane');
      if (e.target.closest('.tl-track-header')) return;

      if (clipEl) {
        const id = clipEl.dataset.id;
        const clip = findClip(this.store.project, id);
        const track = this.store.project.tracks.find((t) => t.id === clip?.trackId);
        const wasSelected = this.store.selection === id;
        this.store.select(id);
        if (!clip || track?.locked) return;
        // En táctil: el primer toque selecciona; arrastrar mueve un clip ya seleccionado.
        if (e.pointerType === 'touch' && !wasSelected && !handle) return;
        e.preventDefault();
        s.setPointerCapture(e.pointerId);
        this.#drag = {
          mode: handle ? `trim-${handle.dataset.edge}` : 'move',
          id, el: clipEl, x0: e.clientX, y0: e.clientY, moved: false, scroll0: s.scrollLeft,
          orig: structuredClone(clip), trackId: clip.trackId,
          media: clip.mediaId ? this.media.get(clip.mediaId) : null,
        };
        clipEl.classList.add('dragging');
        return;
      }
      if (onRuler || onLane) {
        if (onLane && !onRuler) this.store.select(null);
        if (onLane && e.pointerType === 'touch') return; // en táctil el carril desplaza la vista
        e.preventDefault();
        s.setPointerCapture(e.pointerId);
        this.#drag = { mode: 'scrub' };
        this.engine.seek(Math.max(0, this.#timeAtClientX(e.clientX)));
      }
    });

    s.addEventListener('pointermove', (e) => {
      const d = this.#drag;
      if (!d) return;
      if (d.mode === 'scrub') { this.engine.seek(Math.max(0, this.#timeAtClientX(e.clientX))); return; }
      const dx = e.clientX - d.x0;
      if (!d.moved && Math.abs(dx) < 3 && Math.abs(e.clientY - d.y0) < 3) return;
      d.moved = true;
      this.#autoScroll(e.clientX);
      const dt = (dx + (this.scroll.scrollLeft - d.scroll0)) / this.pps;
      const snapOpts = { threshold: 10 / this.pps, playhead: this.engine.time, excludeId: d.id };
      const o = d.orig;
      let snapAt = null;

      if (d.mode === 'move') {
        let start = Math.max(0, o.start + dt);
        if (this.snapping) {
          const a = snapTime(this.store.project, start, snapOpts);
          const b = snapTime(this.store.project, start + o.duration, snapOpts);
          if (a.snapped && (!b.snapped || Math.abs(a.time - start) <= Math.abs(b.time - start - o.duration))) { start = a.time; snapAt = a.time; }
          else if (b.snapped) { start = b.time - o.duration; snapAt = b.time; }
        }
        d.start = Math.max(0, start);
        d.el.style.transform = `translateX(${d.start * this.pps}px)`;
        // Cambio de pista según la posición vertical
        const laneEl = document.elementsFromPoint(e.clientX, e.clientY).find((x) => x.classList?.contains('tl-lane'));
        const target = laneEl && this.store.project.tracks.find((t) => t.id === laneEl.dataset.track);
        if (target && !target.locked && trackAccepts(target, o.type) && laneEl !== d.el.parentNode) { laneEl.append(d.el); d.trackId = target.id; }
      } else {
        const tmp = structuredClone(o);
        const edge = d.mode === 'trim-start' ? 'start' : 'end';
        let tt = (edge === 'start' ? o.start : clipEnd(o)) + dt;
        if (this.snapping) { const sn = snapTime(this.store.project, tt, snapOpts); if (sn.snapped) { tt = sn.time; snapAt = tt; } }
        const maxDur = o.type === 'video' || o.type === 'audio' ? (d.media?.duration ?? Infinity) : Infinity;
        trimClip(tmp, edge, tt, maxDur);
        d.trimmed = tmp;
        d.el.style.transform = `translateX(${tmp.start * this.pps}px)`;
        d.el.style.width = `${tmp.duration * this.pps}px`;
        this.engine.seek(edge === 'start' ? tmp.start : clipEnd(tmp) - 1 / this.store.project.fps);
      }
      this.snapLine.style.display = snapAt != null ? 'block' : 'none';
      if (snapAt != null) this.snapLine.style.transform = `translateX(${HEADER_W + snapAt * this.pps}px)`;
    });

    const finish = () => {
      const d = this.#drag;
      this.#drag = null;
      this.snapLine.style.display = 'none';
      if (!d || d.mode === 'scrub') return;
      d.el.classList.remove('dragging');
      if (!d.moved) return;
      if (d.mode === 'move') {
        this.store.update((p) => {
          const c = findClip(p, d.id);
          c.start = d.start ?? c.start;
          c.trackId = d.trackId;
          resolveOverlap(p, c);
        }, { label: 'Mover clip' });
      } else if (d.trimmed) {
        this.store.update((p) => {
          const c = findClip(p, d.id);
          Object.assign(c, { start: d.trimmed.start, duration: d.trimmed.duration, offset: d.trimmed.offset });
        }, { label: 'Recortar clip' });
      }
      this.render();
    };
    s.addEventListener('pointerup', finish);
    s.addEventListener('pointercancel', finish);

    // Ctrl/⌘ + rueda = zoom centrado en el puntero
    s.addEventListener('wheel', (e) => {
      if (!(e.ctrlKey || e.metaKey)) return;
      e.preventDefault();
      const t = this.#timeAtClientX(e.clientX);
      this.setZoom(this.pps * Math.exp(-e.deltaY * 0.002), { anchorTime: t, clientX: e.clientX });
    }, { passive: false });

    // Pellizco para zoom en táctil
    const touches = new Map();
    let pinch = null;
    s.addEventListener('touchstart', (e) => {
      for (const t of e.changedTouches) touches.set(t.identifier, t.clientX);
      if (touches.size === 2) {
        const [a, b] = [...touches.values()];
        pinch = { dist: Math.abs(a - b) || 1, pps: this.pps, center: (a + b) / 2 };
      }
    }, { passive: true });
    s.addEventListener('touchmove', (e) => {
      for (const t of e.changedTouches) touches.set(t.identifier, t.clientX);
      if (!pinch || touches.size !== 2) return;
      const [a, b] = [...touches.values()];
      this.setZoom(pinch.pps * ((Math.abs(a - b) || 1) / pinch.dist), { anchorTime: this.#timeAtClientX(pinch.center), clientX: pinch.center });
    }, { passive: true });
    s.addEventListener('touchend', (e) => { for (const t of e.changedTouches) touches.delete(t.identifier); if (touches.size < 2) pinch = null; });
  }

  #autoScroll(clientX) {
    const r = this.scroll.getBoundingClientRect();
    if (clientX > r.right - 30) this.scroll.scrollLeft += 12;
    else if (clientX < r.left + HEADER_W + 30) this.scroll.scrollLeft -= 12;
  }

  // ------------------------------------------------------------- Acciones
  #ppsToZoom(pps) { return Math.log(pps / MIN_PPS) / Math.log(MAX_PPS / MIN_PPS); }
  #zoomToPps(z) { return MIN_PPS * (MAX_PPS / MIN_PPS) ** z; }

  setZoom(pps, { anchorTime = this.engine.time, clientX = null } = {}) {
    const old = this.pps;
    this.pps = clamp(pps, MIN_PPS, MAX_PPS);
    if (old === this.pps) return;
    localStorage.setItem('jam.pps', String(Math.round(this.pps)));
    this.zoomRange.value = this.#ppsToZoom(this.pps);
    const r = this.scroll.getBoundingClientRect();
    const screenX = clientX != null ? clientX - r.left : HEADER_W + (this.scroll.clientWidth - HEADER_W) / 2;
    this.render();
    this.scroll.scrollLeft = Math.max(0, HEADER_W + anchorTime * this.pps - screenX);
  }

  zoomToFit() {
    const d = projectDuration(this.store.project) || 10;
    this.setZoom((this.scroll.clientWidth - HEADER_W - 40) / d, { anchorTime: 0, clientX: this.scroll.getBoundingClientRect().left + HEADER_W });
  }

  toggleSnap() {
    this.snapping = !this.snapping;
    localStorage.setItem('jam.snap', this.snapping ? '1' : '0');
    this.snapBtn.classList.toggle('on', this.snapping);
    this.bus.emit('toast', { text: `Imán ${this.snapping ? 'activado' : 'desactivado'}`, timeout: 1200 });
  }

  /** Divide el clip seleccionado (o todos los que estén bajo el cabezal). */
  splitAtPlayhead() {
    const t = this.engine.time;
    const sel = this.store.selectedClip;
    const targets = sel && t > sel.start && t < clipEnd(sel)
      ? [sel.id]
      : this.store.project.clips.filter((c) => t > c.start && t < clipEnd(c)).map((c) => c.id);
    if (!targets.length) { this.bus.emit('toast', { type: 'warn', text: 'Coloca el cabezal sobre un clip para dividirlo' }); return; }
    let right = null;
    this.store.update((d) => { for (const id of targets) right = splitClip(d, id, t) ?? right; }, { label: 'Dividir' });
    if (right) this.store.select(right.id);
  }

  deleteSelected(ripple = false) {
    const id = this.store.selection;
    if (!id) return;
    this.store.update((d) => (ripple ? rippleDelete(d, id) : deleteClip(d, id)), { label: 'Eliminar clip' });
  }

  duplicateSelected() {
    const id = this.store.selection;
    if (!id) return;
    let copy;
    this.store.update((d) => { copy = duplicateClip(d, id); }, { label: 'Duplicar clip' });
    if (copy) this.store.select(copy.id);
  }

  addTrack(type) {
    this.store.update((d) => {
      const n = d.tracks.filter((t) => t.type === type).length + 1;
      const t = createTrack(type, `${type === 'audio' ? 'Audio' : 'Video'} ${n}`);
      if (type === 'audio') d.tracks.push(t); else d.tracks.splice(Math.max(0, d.tracks.findIndex((x) => x.type === 'video')), 0, t);
    }, { label: 'Añadir pista' });
  }

  /** Mueve el clip seleccionado n frames (atajo de teclado). */
  nudgeSelected(frames) {
    const id = this.store.selection;
    if (!id) return false;
    this.store.update((d) => { const c = findClip(d, id); c.start = Math.max(0, c.start + frames / d.fps); }, { label: 'Mover clip', coalesce: `nudge-${id}` });
    return true;
  }
}

