/**
 * Vista previa: lienzo WebGL, controles de reproducción y edición directa
 * (arrastrar el clip seleccionado para moverlo, rueda/pellizco para escalar).
 */
import { h } from '../dom.js';
import { icon } from '../icons.js';
import { formatTime, downloadBlob, clamp } from '../../core/utils.js';
import { isVisual } from '../../model/project.js';

const QUALITY = [['auto', 'Calidad: automática'], ['full', 'Completa'], ['half', '50 %'], ['quarter', '25 %']];

export class PreviewPanel {
  quality = localStorage.getItem('jam.previewQuality') || 'auto';

  constructor(root, { store, bus, engine, compositor, exporter }) {
    Object.assign(this, { root, store, bus, engine, compositor, exporter });
    this.canvas = compositor.canvas;
    this.canvas.classList.add('preview-canvas');
    this.stage = h('div', { class: 'stage' }, this.canvas);

    this.playBtn = h('button', { class: 'icon-btn play', title: 'Reproducir (Espacio)', onclick: () => engine.toggle() }, icon('play', 22));
    this.timeLabel = h('span', { class: 'timecode' }, '00:00.00');
    this.durLabel = h('span', { class: 'timecode dim' }, '/ 00:00.00');
    this.loopBtn = h('button', { class: 'icon-btn', title: 'Repetir', onclick: () => { engine.loop = !engine.loop; this.loopBtn.classList.toggle('on', engine.loop); } }, icon('repeat'));
    const qSel = h('select', { class: 'select compact', title: 'Calidad de la vista previa (no afecta la exportación)',
      onchange: () => { this.quality = qSel.value; localStorage.setItem('jam.previewQuality', qSel.value); this.applySize(); } },
    QUALITY.map(([v, t]) => h('option', { value: v, selected: v === this.quality }, t)));
    this.scrub = h('input', { type: 'range', class: 'range scrub', min: 0, max: 1, step: 0.001, value: 0,
      oninput: () => engine.seek(Number(this.scrub.value) * engine.duration) });

    root.append(
      this.stage,
      h('div', { class: 'transport' },
        this.scrub,
        h('div', { class: 'transport-row' },
          h('div', { class: 'row gap-s' }, this.timeLabel, this.durLabel),
          h('div', { class: 'row gap-s transport-main' },
            h('button', { class: 'icon-btn', title: 'Inicio (Inicio)', onclick: () => engine.seek(0) }, icon('start')),
            h('button', { class: 'icon-btn', title: 'Frame anterior (←)', onclick: () => engine.step(-1) }, icon('stepBack')),
            this.playBtn,
            h('button', { class: 'icon-btn', title: 'Frame siguiente (→)', onclick: () => engine.step(1) }, icon('stepFwd')),
            h('button', { class: 'icon-btn', title: 'Final (Fin)', onclick: () => engine.seek(engine.duration) }, icon('end'))),
          h('div', { class: 'row gap-s transport-extra' },
            this.loopBtn,
            h('button', { class: 'icon-btn', title: 'Capturar fotograma (PNG)', onclick: () => this.snapshot() }, icon('camera')),
            qSel,
            h('button', { class: 'icon-btn', title: 'Pantalla completa', onclick: () => this.fullscreen() }, icon('maximize'))))),
    );

    bus.on('time', (t) => this.#onTime(t));
    bus.on('playstate', (p) => {
      this.playBtn.replaceChildren(icon(p ? 'pause' : 'play', 22));
      this.playBtn.title = p ? 'Pausa (Espacio)' : 'Reproducir (Espacio)';
    });
    bus.on('preview:resize', () => this.applySize());
    store.subscribe((c) => { if (c.type === 'project') { this.applySize(); this.#onTime(engine.time); } });
    new ResizeObserver(() => this.applySize()).observe(this.stage);
    this.#setupDirectManipulation();
    this.applySize();
  }

  #onTime(t) {
    const d = this.engine.duration;
    this.timeLabel.textContent = formatTime(t);
    this.durLabel.textContent = `/ ${formatTime(d)}`;
    if (document.activeElement !== this.scrub) this.scrub.value = d > 0 ? t / d : 0;
  }

  /** Ajusta el tamaño visible (CSS) y la resolución interna del lienzo. */
  applySize() {
    if (this.engine.strict) return; // exportando: el exportador controla la resolución
    const { width: PW, height: PH } = this.store.project;
    const box = this.stage.getBoundingClientRect();
    if (!box.width || !box.height) return;
    const k = Math.min(box.width / PW, box.height / PH);
    const cssW = Math.floor(PW * k);
    const cssH = Math.floor(PH * k);
    this.canvas.style.width = `${cssW}px`;
    this.canvas.style.height = `${cssH}px`;

    let scale;
    switch (this.quality) {
      case 'full': scale = 1; break;
      case 'half': scale = 0.5; break;
      case 'quarter': scale = 0.25; break;
      default: scale = Math.min(1, (cssW * Math.min(devicePixelRatio || 1, 2)) / PW); // solo los píxeles que se ven
    }
    this.compositor.resize(PW * scale, PH * scale);
    this.engine.requestRender();
  }

  async snapshot() {
    const { width, height } = this.store.project;
    const { blob, filename } = await this.exporter.exportFrame({ format: 'png', width, height });
    downloadBlob(blob, filename);
    this.bus.emit('toast', { type: 'success', text: 'Fotograma guardado', timeout: 1800 });
  }

  fullscreen() {
    const el = this.root;
    if (document.fullscreenElement) document.exitFullscreen();
    else (el.requestFullscreen || el.webkitRequestFullscreen)?.call(el);
  }

  /** Arrastrar mueve el clip seleccionado; rueda/pellizco lo escala; un toque reproduce/pausa. */
  #setupDirectManipulation() {
    const c = this.canvas;
    const pointers = new Map();
    let drag = null;

    c.addEventListener('pointerdown', (e) => {
      c.setPointerCapture(e.pointerId);
      pointers.set(e.pointerId, { x: e.clientX, y: e.clientY });
      const clip = this.store.selectedClip;
      const rect = c.getBoundingClientRect();
      drag = {
        sx: e.clientX, sy: e.clientY, moved: false, rect,
        clip: clip && isVisual(clip) && this.#isOnScreen(clip) ? clip : null,
        base: clip ? { ...clip.transform } : null,
        pinch0: null,
      };
      if (pointers.size === 2 && drag.clip) drag.pinch0 = this.#pinchDist(pointers);
    });

    c.addEventListener('pointermove', (e) => {
      if (!drag || !pointers.has(e.pointerId)) return;
      pointers.set(e.pointerId, { x: e.clientX, y: e.clientY });
      const dx = e.clientX - drag.sx;
      const dy = e.clientY - drag.sy;
      if (Math.hypot(dx, dy) > 4) drag.moved = true;
      if (!drag.clip || !drag.moved) return;
      if (pointers.size === 2 && drag.pinch0) {
        const k = this.#pinchDist(pointers) / drag.pinch0;
        this.#updateTransform(drag.clip.id, { scale: clamp(drag.base.scale * k, 0.05, 10) });
        return;
      }
      this.#updateTransform(drag.clip.id, {
        x: round1(drag.base.x + (dx / drag.rect.width) * 100),
        y: round1(drag.base.y + (dy / drag.rect.height) * 100),
      });
    });

    const end = (e) => {
      pointers.delete(e.pointerId);
      if (!drag) return;
      if (!drag.moved && pointers.size === 0) this.engine.toggle();
      if (pointers.size === 0) drag = null;
    };
    c.addEventListener('pointerup', end);
    c.addEventListener('pointercancel', end);

    c.addEventListener('wheel', (e) => {
      const clip = this.store.selectedClip;
      if (!clip || !isVisual(clip)) return;
      e.preventDefault();
      const k = Math.exp(-e.deltaY * 0.0015);
      this.#updateTransform(clip.id, { scale: clamp(round2(clip.transform.scale * k), 0.05, 10) });
    }, { passive: false });
  }

  #isOnScreen(clip) {
    const t = this.engine.time;
    return t >= clip.start && t < clip.start + clip.duration;
  }

  #pinchDist(pointers) {
    const [a, b] = [...pointers.values()];
    return Math.hypot(a.x - b.x, a.y - b.y) || 1;
  }

  #updateTransform(clipId, patch) {
    this.store.update((d) => {
      const clip = d.clips.find((x) => x.id === clipId);
      if (!clip) return false;
      Object.assign(clip.transform, patch);
    }, { label: 'Mover/escalar en la vista previa', coalesce: `xf-${clipId}` });
  }
}

const round1 = (v) => Math.round(v * 10) / 10;
const round2 = (v) => Math.round(v * 100) / 100;
