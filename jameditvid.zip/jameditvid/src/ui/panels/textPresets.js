/** Fuentes y estilos rápidos para los textos. Añade los tuyos aquí. */
export const FONTS = [
  ['Inter, system-ui, sans-serif', 'Sans (sistema)'],
  ['Georgia, "Times New Roman", serif', 'Serif clásica'],
  ['"Arial Black", Impact, sans-serif', 'Impacto'],
  ['Impact, "Arial Narrow", sans-serif', 'Condensada'],
  ['"Courier New", ui-monospace, monospace', 'Máquina de escribir'],
  ['"Trebuchet MS", Verdana, sans-serif', 'Humanista'],
  ['"Comic Sans MS", "Chalkboard SE", cursive', 'Informal'],
  ['"Brush Script MT", "Segoe Script", cursive', 'Manuscrita'],
  ['Palatino, "Palatino Linotype", serif', 'Elegante'],
];

export const TEXT_PRESETS = [
  { name: 'Título', preview: { fontWeight: 800 },
    style: { font: FONTS[2][0], size: 140, color: '#ffffff', bold: true, italic: false, strokeWidth: 0, shadow: true, background: false } },
  { name: 'Subtítulo', preview: { background: '#000a', color: '#fff' },
    style: { font: FONTS[0][0], size: 56, color: '#ffffff', bold: false, strokeWidth: 0, shadow: false, background: true, bgColor: '#000000', bgOpacity: 0.65, padding: 18 } },
  { name: 'Contorno', preview: { color: '#ffe14d', textShadow: '0 0 2px #000' },
    style: { font: FONTS[2][0], size: 120, color: '#ffe14d', bold: true, strokeColor: '#000000', strokeWidth: 8, shadow: false, background: false } },
  { name: 'Neón', preview: { color: '#4dfff3', textShadow: '0 0 6px #4dfff3' },
    style: { font: FONTS[5][0], size: 110, color: '#b9fffa', bold: true, strokeColor: '#00e5ff', strokeWidth: 3, shadow: true, background: false } },
  { name: 'Etiqueta', preview: { background: '#ff3d6e', color: '#fff' },
    style: { font: FONTS[0][0], size: 64, color: '#ffffff', bold: true, strokeWidth: 0, shadow: false, background: true, bgColor: '#ff3d6e', bgOpacity: 1, padding: 22 } },
  { name: 'Cine', preview: { fontFamily: 'Georgia, serif', letterSpacing: '2px' },
    style: { font: FONTS[1][0], size: 90, color: '#f3e9d2', bold: false, italic: true, strokeWidth: 0, shadow: true, background: false } },
];
