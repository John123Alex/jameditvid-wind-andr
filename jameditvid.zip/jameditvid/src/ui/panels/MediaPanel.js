/**
 * Panel de medios: importar (botón o arrastrar), ver y añadir a la línea de tiempo.
 */
import { h, clear } from '../dom.js';
import { icon } from '../icons.js';
import { formatTime, formatBytes } from '../../core/utils.js';
import { addMediaClip, addTextClip } from '../../model/clipOps.js';
import { confirmDialog } from '../feedback.js';

export class MediaPanel {
  #filter = 'all';

  constructor(root, { store, bus, media, engine }) {
    Object.assign(this, { root, store, bus, media, engine });
    this.fileInput = h('input', { type: 'file', multiple: true, accept: 'video/*,audio/*,image/*', hidden: true,
      onchange: () => { this.import(this.fileInput.files); this.fileInput.value = ''; } });

    this.grid = h('div', { class: 'media-grid' });
    this.tabs = h('div', { class: 'seg' },
      [['all', 'Todo'], ['video', 'Video'], ['audio', 'Audio'], ['image', 'Imagen']].map(([id, label]) =>
        h('button', { class: `seg-btn ${id === 'all' ? 'active' : ''}`, dataset: { id }, onclick: () => this.setFilter(id) }, label)));

    root.append(
      h('div', { class: 'panel-head' },
        h('h2', {}, icon('folder'), 'Medios'),
        h('div', { class: 'row gap-s' },
          h('button', { class: 'btn small', onclick: () => this.addText(), title: 'Añadir texto' }, icon('text', 16), h('span', {}, 'Texto')),
          h('button', { class: 'btn primary small', onclick: () => this.fileInput.click() }, icon('upload', 16), h('span', {}, 'Importar')))),
      this.tabs,
      h('div', { class: 'panel-scroll' },
        h('div', { class: 'dropzone', onclick: () => this.fileInput.click() },
          icon('upload', 28), h('p', {}, 'Arrastra aquí videos, audios o imágenes'), h('small', {}, 'o toca para elegir archivos')),
        this.grid),
      this.fileInput,
    );

    this.#setupDrop();
    bus.on('media:changed', () => this.render());
    this.render();
  }

  async import(files) {
    if (!files?.length) return;
    const items = await this.media.importFiles(files);
    if (items.length) this.bus.emit('toast', { type: 'success', text: `${items.length} archivo(s) importado(s)` });
    // Si el proyecto está vacío, añade automáticamente lo importado y ajusta el lienzo.
    if (items.length && this.store.project.clips.length === 0) {
      const firstVisual = items.find((i) => i.kind === 'video') ?? items.find((i) => i.kind === 'image');
      this.store.update((d) => {
        if (firstVisual?.width && firstVisual?.height) { d.width = evenDim(firstVisual.width); d.height = evenDim(firstVisual.height); }
        let t = 0;
        for (const it of items) {
          const clip = addMediaClip(d, it, it.kind === 'audio' ? 0 : t);
          if (it.kind !== 'audio') t += clip.duration;
        }
      }, { label: 'Añadir medios' });
    }
  }

  addToTimeline(item) {
    let created;
    this.store.update((d) => { created = addMediaClip(d, item, this.engine.time); }, { label: 'Añadir a la línea de tiempo' });
    this.store.select(created.id);
    this.bus.emit('toast', { text: `«${item.name}» añadido en ${formatTime(this.engine.time)}`, timeout: 1800 });
  }

  addText() {
    let created;
    this.store.update((d) => { created = addTextClip(d, this.engine.time); }, { label: 'Añadir texto' });
    this.store.select(created.id);
    this.bus.emit('ui:show-panel', 'inspector');
  }

  async removeItem(item) {
    const used = this.store.project.clips.filter((c) => c.mediaId === item.id).length;
    const ok = await confirmDialog(used
      ? `«${item.name}» se usa en ${used} clip(s). Se quitarán también de la línea de tiempo. ¿Continuar?`
      : `¿Quitar «${item.name}» de la biblioteca?`, { okText: 'Quitar', danger: true });
    if (!ok) return;
    if (used) this.store.update((d) => { d.clips = d.clips.filter((c) => c.mediaId !== item.id); }, { label: 'Quitar medio' });
    await this.media.remove(item.id);
  }

  setFilter(id) {
    this.#filter = id;
    this.tabs.querySelectorAll('.seg-btn').forEach((b) => b.classList.toggle('active', b.dataset.id === id));
    this.render();
  }

  render() {
    const items = this.media.items.filter((i) => this.#filter === 'all' || i.kind === this.#filter);
    clear(this.grid);
    if (!items.length) return;
    for (const item of items) {
      const kindIcon = { video: 'film', audio: 'music', image: 'image' }[item.kind];
      const thumb = item.thumb
        ? h('img', { src: item.thumb, alt: '', loading: 'lazy', draggable: false })
        : h('div', { class: 'thumb-placeholder' }, item.waveform ? h('img', { src: item.waveform, alt: '', class: 'wave' }) : icon(kindIcon, 28));
      const card = h('div', { class: `media-card ${item.loading ? 'loading' : ''}`, draggable: true, title: `${item.name}\n${formatBytes(item.size)}`,
        ondragstart: (e) => { e.dataTransfer.setData('application/x-jam-media', item.id); e.dataTransfer.effectAllowed = 'copy'; },
        ondblclick: () => !item.loading && this.addToTimeline(item) },
        h('div', { class: 'media-thumb' }, thumb,
          h('span', { class: 'badge' }, icon(kindIcon, 12), item.kind === 'image' ? 'IMG' : formatTime(item.duration, false)),
          item.loading && h('span', { class: 'spinner' })),
        h('div', { class: 'media-meta' },
          h('span', { class: 'media-name' }, item.name),
          h('div', { class: 'media-actions' },
            h('button', { class: 'icon-btn sm', title: 'Quitar', onclick: (e) => { e.stopPropagation(); this.removeItem(item); } }, icon('trash', 14)),
            h('button', { class: 'icon-btn sm accent', title: 'Añadir en el cabezal', disabled: item.loading,
              onclick: (e) => { e.stopPropagation(); this.addToTimeline(item); } }, icon('plus', 16)))));
      this.grid.append(card);
    }
  }

  #setupDrop() {
    // Soltar archivos en cualquier parte de la app los importa.
    const app = document.getElementById('app');
    app.addEventListener('dragover', (e) => {
      if ([...e.dataTransfer.types].includes('Files')) { e.preventDefault(); app.classList.add('dragging-files'); }
    });
    app.addEventListener('dragleave', (e) => { if (e.target === app || !app.contains(e.relatedTarget)) app.classList.remove('dragging-files'); });
    app.addEventListener('drop', (e) => {
      app.classList.remove('dragging-files');
      if (e.dataTransfer.files?.length) { e.preventDefault(); this.import(e.dataTransfer.files); }
    });
  }
}

const evenDim = (n) => Math.max(2, Math.round(n / 2) * 2);
