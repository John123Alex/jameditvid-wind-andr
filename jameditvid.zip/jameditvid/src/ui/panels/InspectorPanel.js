/**
 * Inspector: propiedades del clip seleccionado (o del proyecto si no hay selección).
 * Los controles se generan a partir de los datos, incluidos los de cada efecto.
 */
import { h, clear } from '../dom.js';
import { icon } from '../icons.js';
import { slider, select, toggle, colorInput, textInput, numberInput, section } from '../controls.js';
import { RESOLUTION_PRESETS, isVisual, hasAudio, defaultTransform } from '../../model/project.js';
import { setClipSpeed } from '../../model/clipOps.js';
import { effectDefinitions, getEffectDef, createEffectInstance, CATEGORIES } from '../../effects/registry.js';
import { ANIM_IN, ANIM_OUT, MOTIONS } from '../../effects/animations.js';
import { rafThrottle, even } from '../../core/utils.js';
import { TEXT_PRESETS, FONTS } from './textPresets.js';

export class InspectorPanel {
  #tab = 'props';
  #selfUpdate = false;
  #lastClipId = null;

  constructor(root, { store, bus, media }) {
    Object.assign(this, { root, store, bus, media });
    this.body = h('div', { class: 'panel-scroll inspector' });
    this.title = h('h2', {}, icon('sliders'), 'Propiedades');
    root.append(h('div', { class: 'panel-head' }, this.title), this.body);
    const rerender = rafThrottle(() => this.render());
    store.subscribe((c) => {
      if (c.type === 'project' && this.#selfUpdate) return;
      rerender();
    });
    this.render();
  }

  /** Edita el clip seleccionado sin reconstruir el panel (no interrumpe el arrastre). */
  #edit(mutate, key) {
    const id = this.store.selection;
    this.#selfUpdate = true;
    try {
      this.store.update((d) => {
        const clip = d.clips.find((c) => c.id === id);
        if (!clip) return false;
        mutate(clip, d);
      }, { label: 'Editar propiedades', coalesce: key ? `${id}:${key}` : null });
    } finally { this.#selfUpdate = false; }
  }

  #editProject(mutate, key) {
    this.#selfUpdate = true;
    try { this.store.update(mutate, { label: 'Ajustes del proyecto', coalesce: key }); } finally { this.#selfUpdate = false; }
  }

  render() {
    const clip = this.store.selectedClip;
    if (clip?.id !== this.#lastClipId) {
      // Al cambiar de clip: los textos abren su pestaña; entre videos se conserva (útil para efectos).
      if (clip?.type === 'text') this.#tab = 'text';
      else if (clip && this.#tab === 'text') this.#tab = 'props';
      this.#lastClipId = clip?.id ?? null;
    }
    const scrollTop = this.body.scrollTop;
    clear(this.body);
    if (!clip) {
      this.title.lastChild.textContent = 'Proyecto';
      this.#renderProject();
    } else {
      this.title.lastChild.textContent = clip.name;
      this.#renderClip(clip);
    }
    this.body.scrollTop = scrollTop;
  }

  // ---------------- Proyecto ----------------
  #renderProject() {
    const p = this.store.project;
    const presetId = RESOLUTION_PRESETS.find((r) => r.w === p.width && r.h === p.height)?.id ?? 'custom';
    this.body.append(
      section('Proyecto',
        textInput({ label: 'Nombre', value: p.name, onInput: (v) => this.#editProject((d) => { d.name = v; }, 'name') }),
        select({ label: 'Formato del lienzo', value: presetId,
          options: [...RESOLUTION_PRESETS.map((r) => [r.id, `${r.label} — ${r.w}×${r.h}`]), ['custom', 'Personalizado']],
          onChange: (id) => {
            const r = RESOLUTION_PRESETS.find((x) => x.id === id);
            if (r) this.store.update((d) => { d.width = r.w; d.height = r.h; }, { label: 'Cambiar formato' });
          } }),
        h('div', { class: 'grid-2' },
          numberInput({ label: 'Ancho (px)', value: p.width, min: 16, max: 7680, step: 2, onChange: (v) => this.store.update((d) => { d.width = even(v); }, { label: 'Ancho' }) }),
          numberInput({ label: 'Alto (px)', value: p.height, min: 16, max: 7680, step: 2, onChange: (v) => this.store.update((d) => { d.height = even(v); }, { label: 'Alto' }) })),
        select({ label: 'Fotogramas por segundo', value: p.fps, options: [24, 25, 30, 50, 60].map((f) => [f, `${f} fps`]),
          onChange: (v) => this.store.update((d) => { d.fps = Number(v); }, { label: 'FPS' }) }),
        colorInput({ label: 'Color de fondo', value: p.background, onInput: (v) => this.#editProject((d) => { d.background = v; }, 'bg') }),
      ),
      h('p', { class: 'hint-box' }, icon('sparkles', 16),
        'Selecciona un clip en la línea de tiempo para editar su posición, velocidad, audio, efectos especiales, animaciones y texto.'),
    );
  }

  // ---------------- Clip ----------------
  #renderClip(clip) {
    const tabs = [['props', 'Ajustes', 'sliders']];
    if (clip.type === 'text') tabs.unshift(['text', 'Texto', 'text']);
    if (isVisual(clip)) tabs.push(['fx', `Efectos${clip.effects.length ? ` (${clip.effects.length})` : ''}`, 'wand'], ['anim', 'Animación', 'sparkles']);
    if (!tabs.some(([id]) => id === this.#tab)) this.#tab = tabs[0][0];

    this.body.append(h('div', { class: 'tabs' }, tabs.map(([id, label, ic]) =>
      h('button', { class: `tab ${this.#tab === id ? 'active' : ''}`, onclick: () => { this.#tab = id; this.render(); } }, icon(ic, 15), h('span', {}, label)))));

    const content = { props: () => this.#propsTab(clip), text: () => this.#textTab(clip), fx: () => this.#fxTab(clip), anim: () => this.#animTab(clip) }[this.#tab]();
    this.body.append(...[content].flat());
  }

  #propsTab(clip) {
    const out = [];
    const media = clip.mediaId ? this.media.get(clip.mediaId) : null;
    out.push(section('Tiempo',
      h('div', { class: 'grid-2' },
        numberInput({ label: 'Inicio (s)', value: +clip.start.toFixed(2), min: 0, step: 0.1, onChange: (v) => { this.#edit((c) => { c.start = Math.max(0, v); }); this.render(); } }),
        numberInput({ label: 'Duración (s)', value: +clip.duration.toFixed(2), min: 0.05, step: 0.1, onChange: (v) => {
          this.#edit((c) => {
            const max = media?.duration ? (media.duration - c.offset) / c.speed : Infinity;
            c.duration = Math.min(Math.max(0.05, v), max);
          });
          this.render();
        } })),
      (clip.type === 'video' || clip.type === 'audio') && slider({ label: 'Velocidad', value: clip.speed, min: 0.1, max: 8, step: 0.05, def: 1,
        onInput: (v) => this.#edit((c) => {
          setClipSpeed(c, v);
          if (media?.duration) c.duration = Math.min(c.duration, (media.duration - c.offset) / c.speed);
        }, 'speed') }),
    ));

    if (isVisual(clip)) {
      const t = clip.transform;
      const xf = (key) => (v) => this.#edit((c) => { c.transform[key] = v; }, key);
      out.push(section('Transformación',
        h('div', { class: 'grid-2' },
          slider({ label: 'Posición X (%)', value: t.x, min: -150, max: 150, step: 0.5, def: 0, onInput: xf('x') }),
          slider({ label: 'Posición Y (%)', value: t.y, min: -150, max: 150, step: 0.5, def: 0, onInput: xf('y') })),
        slider({ label: 'Escala', value: t.scale, min: 0.05, max: 5, step: 0.01, def: 1, onInput: xf('scale') }),
        slider({ label: 'Rotación (°)', value: t.rotation, min: -180, max: 180, step: 1, def: 0, onInput: xf('rotation') }),
        slider({ label: 'Opacidad', value: t.opacity, min: 0, max: 1, step: 0.01, def: 1, onInput: xf('opacity') }),
        clip.type !== 'text' && select({ label: 'Ajuste al lienzo', value: t.fit,
          options: [['contain', 'Encajar (sin recortar)'], ['cover', 'Rellenar (recorta)'], ['stretch', 'Estirar'], ['none', 'Tamaño original']],
          onChange: (v) => { this.#edit((c) => { c.transform.fit = v; }); } }),
        h('div', { class: 'row gap-m wrap' },
          toggle({ label: 'Espejo horizontal', value: t.flipH, onChange: (v) => this.#edit((c) => { c.transform.flipH = v; }) }),
          toggle({ label: 'Espejo vertical', value: t.flipV, onChange: (v) => this.#edit((c) => { c.transform.flipV = v; }) })),
        select({ label: 'Modo de fusión', value: clip.blend,
          options: [['normal', 'Normal'], ['screen', 'Trama (aclarar)'], ['add', 'Sumar (luz)'], ['multiply', 'Multiplicar (oscurecer)']],
          onChange: (v) => this.#edit((c) => { c.blend = v; }) }),
        h('button', { class: 'btn small ghost', onclick: () => { this.#edit((c) => { c.transform = { ...defaultTransform(), fit: c.transform.fit }; }); this.render(); } }, 'Restablecer transformación'),
      ));
    }

    if (hasAudio(clip)) {
      out.push(section('Audio',
        slider({ label: 'Volumen', value: clip.volume, min: 0, max: 2, step: 0.01, def: 1, onInput: (v) => this.#edit((c) => { c.volume = v; }, 'vol') }),
        toggle({ label: 'Silenciar este clip', value: clip.muted, onChange: (v) => this.#edit((c) => { c.muted = v; }) }),
        h('div', { class: 'grid-2' },
          slider({ label: 'Fundido entrada (s)', value: clip.fadeIn, min: 0, max: 5, step: 0.1, def: 0, onInput: (v) => this.#edit((c) => { c.fadeIn = v; }, 'fi') }),
          slider({ label: 'Fundido salida (s)', value: clip.fadeOut, min: 0, max: 5, step: 0.1, def: 0, onInput: (v) => this.#edit((c) => { c.fadeOut = v; }, 'fo') })),
      ));
    }
    if (media) out.push(h('p', { class: 'meta-line' }, `${media.name}${media.width ? ` · ${media.width}×${media.height}` : ''}`));
    return out;
  }

  #textTab(clip) {
    const t = clip.text;
    const tx = (key, coalesce = true) => (v) => this.#edit((c) => { c.text[key] = v; }, coalesce ? `t-${key}` : null);
    return [
      section('Estilos rápidos',
        h('div', { class: 'preset-grid' }, TEXT_PRESETS.map((p) =>
          h('button', { class: 'preset', style: p.preview, onclick: () => { this.#edit((c) => { Object.assign(c.text, p.style); }); this.render(); } }, p.name)))),
      section('Contenido',
        textInput({ value: t.content, multiline: true, onInput: (v) => this.#edit((c) => { c.text.content = v; c.name = v.split('\n')[0].slice(0, 40) || 'Texto'; }, 't-content') }),
        select({ label: 'Fuente', value: t.font, options: FONTS, onChange: tx('font', false) }),
        slider({ label: 'Tamaño', value: t.size, min: 10, max: 400, step: 1, def: 96, onInput: tx('size') }),
        h('div', { class: 'row gap-m wrap' },
          toggle({ label: 'Negrita', value: t.bold, onChange: tx('bold', false) }),
          toggle({ label: 'Cursiva', value: t.italic, onChange: tx('italic', false) })),
        select({ label: 'Alineación', value: t.align, options: [['left', 'Izquierda'], ['center', 'Centro'], ['right', 'Derecha']], onChange: tx('align', false) }),
        slider({ label: 'Interlineado', value: t.lineHeight, min: 0.8, max: 2.5, step: 0.05, def: 1.2, onInput: tx('lineHeight') }),
      ),
      section('Color y borde',
        colorInput({ label: 'Color del texto', value: t.color, onInput: tx('color') }),
        h('div', { class: 'grid-2' },
          colorInput({ label: 'Color del contorno', value: t.strokeColor, onInput: tx('strokeColor') }),
          slider({ label: 'Grosor contorno', value: t.strokeWidth, min: 0, max: 20, step: 0.5, def: 0, onInput: tx('strokeWidth') })),
        toggle({ label: 'Sombra', value: t.shadow, onChange: tx('shadow', false) }),
      ),
      section('Fondo',
        toggle({ label: 'Caja de fondo', value: t.background, onChange: (v) => { tx('background', false)(v); this.render(); } }),
        t.background && h('div', {},
          colorInput({ label: 'Color de la caja', value: t.bgColor, onInput: tx('bgColor') }),
          slider({ label: 'Opacidad de la caja', value: t.bgOpacity, min: 0, max: 1, step: 0.01, onInput: tx('bgOpacity') }),
          slider({ label: 'Margen interior', value: t.padding, min: 0, max: 120, step: 1, onInput: tx('padding') })),
      ),
    ];
  }

  #fxTab(clip) {
    const list = h('div', { class: 'fx-list' });
    clip.effects.forEach((fx, idx) => {
      const def = getEffectDef(fx.type);
      if (!def) return;
      const setParam = (key) => (v) => this.#edit((c) => { const e = c.effects.find((x) => x.id === fx.id); if (e) e.params[key] = v; }, `fx-${fx.id}-${key}`);
      const controls = def.params.map((p) => {
        const v = fx.params[p.key] ?? p.default;
        if (p.type === 'range') return slider({ label: p.label, value: v, min: p.min, max: p.max, step: p.step, def: p.default, onInput: setParam(p.key) });
        if (p.type === 'color') return colorInput({ label: p.label, value: v, onInput: setParam(p.key) });
        if (p.type === 'bool') return toggle({ label: p.label, value: v, onChange: setParam(p.key) });
        if (p.type === 'select') return select({ label: p.label, value: v, options: p.options.map(([, text], i) => [i, text]), onChange: (s) => setParam(p.key)(Number(s)) });
        return null;
      });
      const move = (dir) => { this.#edit((c) => { const i = c.effects.findIndex((x) => x.id === fx.id); const j = i + dir; if (j < 0 || j >= c.effects.length) return; [c.effects[i], c.effects[j]] = [c.effects[j], c.effects[i]]; }); this.render(); };
      const card = h('details', { class: `fx-card ${fx.enabled ? '' : 'disabled'}`, open: true },
        h('summary', {},
          h('span', { class: 'fx-name' }, def.name),
          h('span', { class: 'fx-tools', onclick: (e) => e.preventDefault() },
            h('button', { class: 'icon-btn sm', title: fx.enabled ? 'Desactivar' : 'Activar', onclick: () => { this.#edit((c) => { const e = c.effects.find((x) => x.id === fx.id); e.enabled = !e.enabled; }); this.render(); } }, icon(fx.enabled ? 'eye' : 'eyeOff', 14)),
            h('button', { class: 'icon-btn sm', title: 'Subir', disabled: idx === 0, onclick: () => move(-1) }, icon('up', 14)),
            h('button', { class: 'icon-btn sm', title: 'Bajar', disabled: idx === clip.effects.length - 1, onclick: () => move(1) }, icon('down', 14)),
            h('button', { class: 'icon-btn sm', title: 'Quitar', onclick: () => { this.#edit((c) => { c.effects = c.effects.filter((x) => x.id !== fx.id); }); this.render(); } }, icon('trash', 14)))),
        h('div', { class: 'fx-body' }, controls,
          h('button', { class: 'btn small ghost', onclick: () => { this.#edit((c) => { const e = c.effects.find((x) => x.id === fx.id); for (const p of def.params) e.params[p.key] = p.default; }); this.render(); } }, 'Valores por defecto')));
      list.append(card);
    });

    return [
      clip.effects.length ? list : h('p', { class: 'hint-box' }, icon('wand', 16), 'Este clip aún no tiene efectos. Elige uno abajo: se aplican en tiempo real con la GPU y puedes combinar varios.'),
      clip.effects.length > 0 && h('div', { class: 'row gap-s' },
        h('button', { class: 'btn small ghost', onclick: () => { this.#edit((c) => { c.effects = []; }); this.render(); } }, 'Quitar todos'),
        h('button', { class: 'btn small ghost', onclick: () => this.#copyEffectsToAll(clip) }, 'Aplicar a todos los clips visuales')),
      this.#effectPicker(),
    ];
  }

  #effectPicker() {
    const results = h('div', { class: 'fx-picker' });
    const search = h('input', { class: 'input', placeholder: 'Buscar efecto…', type: 'search' });
    const draw = () => {
      clear(results);
      const q = search.value.trim().toLowerCase();
      for (const cat of CATEGORIES) {
        const defs = effectDefinitions().filter((d) => d.category === cat.id && (!q || d.name.toLowerCase().includes(q)));
        if (!defs.length) continue;
        results.append(h('h5', {}, cat.name), h('div', { class: 'fx-chips' }, defs.map((d) =>
          h('button', { class: `chip ${d.animated ? 'animated' : ''}`, title: d.animated ? 'Efecto animado' : '', onclick: () => {
            this.#edit((c) => { c.effects.push(createEffectInstance(d.id)); });
            this.render();
          } }, d.animated && icon('sparkles', 12), d.name))));
      }
    };
    search.addEventListener('input', draw);
    draw();
    return section('Añadir efecto', search, results);
  }

  #copyEffectsToAll(clip) {
    const fx = clip.effects;
    this.store.update((d) => {
      for (const c of d.clips) if (c.id !== clip.id && isVisual(c)) c.effects = fx.map((e) => ({ ...createEffectInstance(e.type), params: { ...e.params }, enabled: e.enabled }));
    }, { label: 'Copiar efectos' });
    this.bus.emit('toast', { type: 'success', text: 'Efectos aplicados a todos los clips visuales' });
  }

  #animTab(clip) {
    const maxDur = Math.max(0.1, Math.min(5, clip.duration));
    return [
      section('Entrada',
        select({ label: 'Animación de entrada', value: clip.animIn.type, options: ANIM_IN.filter(([id]) => id !== 'typewriter' || clip.type === 'text'),
          onChange: (v) => this.#edit((c) => { c.animIn.type = v; }) }),
        slider({ label: 'Duración (s)', value: clip.animIn.duration, min: 0.1, max: maxDur, step: 0.05, onInput: (v) => this.#edit((c) => { c.animIn.duration = v; }, 'ain') })),
      section('Salida',
        select({ label: 'Animación de salida', value: clip.animOut.type, options: ANIM_OUT, onChange: (v) => this.#edit((c) => { c.animOut.type = v; }) }),
        slider({ label: 'Duración (s)', value: clip.animOut.duration, min: 0.1, max: maxDur, step: 0.05, onInput: (v) => this.#edit((c) => { c.animOut.duration = v; }, 'aout') })),
      section('Movimiento continuo',
        select({ label: 'Movimiento', value: clip.motion.type, options: MOTIONS, onChange: (v) => this.#edit((c) => { c.motion.type = v; }) }),
        slider({ label: 'Intensidad', value: clip.motion.amount, min: 0.02, max: 0.6, step: 0.01, def: 0.15, onInput: (v) => this.#edit((c) => { c.motion.amount = v; }, 'mot') })),
      h('p', { class: 'hint-box' }, icon('layers', 16), 'Transición entre clips: pon el segundo clip en la pista superior solapado unos segundos con el primero y dale «Aparecer (fundido)» de entrada.'),
    ];
  }
}

