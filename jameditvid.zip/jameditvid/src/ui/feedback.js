/** Notificaciones (toasts) y ventanas modales. */
import { h } from './dom.js';
import { icon } from './icons.js';

export function initToasts(bus, root) {
  bus.on('toast', ({ type = 'info', text, timeout = 4000 }) => {
    const t = h('div', { class: `toast toast-${type}`, role: 'status' }, text);
    root.append(t);
    requestAnimationFrame(() => t.classList.add('show'));
    setTimeout(() => { t.classList.remove('show'); setTimeout(() => t.remove(), 300); }, timeout);
  });
}

/**
 * Abre un modal. Devuelve { el, body, close }.
 * @param {{ title: string, wide?: boolean, onClose?: () => boolean|void }} opts  onClose puede devolver false para impedir cerrar.
 */
export function openModal({ title, wide = false, onClose }) {
  const root = document.getElementById('modal-root');
  const body = h('div', { class: 'modal-body' });
  const close = () => {
    if (onClose?.() === false) return;
    overlay.remove();
    document.removeEventListener('keydown', onKey);
  };
  const onKey = (e) => { if (e.key === 'Escape') close(); };
  const overlay = h('div', { class: 'modal-overlay', onclick: (e) => { if (e.target === overlay) close(); } },
    h('div', { class: `modal ${wide ? 'modal-wide' : ''}`, role: 'dialog', 'aria-label': title },
      h('header', { class: 'modal-header' },
        h('h3', {}, title),
        h('button', { class: 'icon-btn', onclick: close, title: 'Cerrar' }, icon('x'))),
      body));
  root.append(overlay);
  document.addEventListener('keydown', onKey);
  return { el: overlay, body, close, forceClose: () => { overlay.remove(); document.removeEventListener('keydown', onKey); } };
}

export function confirmDialog(text, { okText = 'Aceptar', danger = false } = {}) {
  return new Promise((resolve) => {
    let done = false;
    const m = openModal({ title: 'Confirmar', onClose: () => { if (!done) resolve(false); } });
    m.body.append(
      h('p', { class: 'confirm-text' }, text),
      h('div', { class: 'modal-actions' },
        h('button', { class: 'btn', onclick: () => m.close() }, 'Cancelar'),
        h('button', { class: `btn ${danger ? 'danger' : 'primary'}`, onclick: () => { done = true; resolve(true); m.forceClose(); } }, okText)),
    );
  });
}

/** Barra de progreso reutilizable. */
export function progressBar() {
  const fill = h('div', { class: 'progress-fill' });
  const label = h('span', { class: 'progress-label' }, '0%');
  const el = h('div', { class: 'progress' }, fill, label);
  return {
    el,
    set(p) {
      const pct = Math.round(Math.max(0, Math.min(1, p)) * 100);
      fill.style.width = `${pct}%`;
      label.textContent = `${pct}%`;
    },
  };
}
