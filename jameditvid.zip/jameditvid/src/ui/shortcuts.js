/** Atajos de teclado globales. */
export const SHORTCUTS_HELP = [
  ['Espacio', 'Reproducir / pausar'],
  ['← / →', 'Frame anterior / siguiente (con clip seleccionado y Alt: mover el clip)'],
  ['Mayús + ← / →', 'Retroceder / avanzar 1 segundo'],
  ['Inicio / Fin', 'Ir al inicio / final'],
  ['S', 'Dividir en el cabezal'],
  ['Supr / Retroceso', 'Eliminar clip seleccionado'],
  ['Mayús + Supr', 'Eliminar y cerrar el hueco'],
  ['Ctrl + D', 'Duplicar clip'],
  ['Ctrl + Z / Ctrl + Y', 'Deshacer / rehacer'],
  ['T', 'Añadir texto en el cabezal'],
  ['+ / −', 'Acercar / alejar la línea de tiempo'],
  ['Ctrl + rueda', 'Zoom en la línea de tiempo'],
  ['Esc', 'Quitar selección / cerrar ventana'],
  ['Ctrl + E', 'Exportar'],
];

export function bindShortcuts({ store, engine, timeline, actions }) {
  window.addEventListener('keydown', (e) => {
    const tag = e.target.tagName;
    if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT' || e.target.isContentEditable) return;
    if (document.querySelector('.modal-overlay')) return;
    const mod = e.ctrlKey || e.metaKey;
    const k = e.key;

    if (k === ' ') { e.preventDefault(); engine.toggle(); }
    else if (mod && k.toLowerCase() === 'z' && !e.shiftKey) { e.preventDefault(); store.undo(); }
    else if (mod && (k.toLowerCase() === 'y' || (k.toLowerCase() === 'z' && e.shiftKey))) { e.preventDefault(); store.redo(); }
    else if (mod && k.toLowerCase() === 'd') { e.preventDefault(); timeline.duplicateSelected(); }
    else if (mod && k.toLowerCase() === 'e') { e.preventDefault(); actions.openExport(); }
    else if (mod) return;
    else if (k === 'ArrowLeft' || k === 'ArrowRight') {
      e.preventDefault();
      const dir = k === 'ArrowLeft' ? -1 : 1;
      if (e.altKey && timeline.nudgeSelected(dir)) return;
      if (e.shiftKey) engine.seek(engine.time + dir); else engine.step(dir);
    }
    else if (k === 'Home') engine.seek(0);
    else if (k === 'End') engine.seek(engine.duration);
    else if (k.toLowerCase() === 's') timeline.splitAtPlayhead();
    else if (k.toLowerCase() === 't') actions.addText();
    else if (k === 'Delete' || k === 'Backspace') { e.preventDefault(); timeline.deleteSelected(e.shiftKey); }
    else if (k === '+' || k === '=') timeline.setZoom(timeline.pps * 1.4);
    else if (k === '-') timeline.setZoom(timeline.pps / 1.4);
    else if (k === 'Escape') store.select(null);
  });
}
