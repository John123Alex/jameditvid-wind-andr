/** Barra superior: proyecto, convertidor, ayuda y exportar. */
import { h } from './dom.js';
import { icon } from './icons.js';
import { openModal } from './feedback.js';
import { SHORTCUTS_HELP } from './shortcuts.js';

export class TopBar {
  constructor(root, { store, bus, actions }) {
    this.saved = h('span', { class: 'save-state', title: 'Se guarda automáticamente en este dispositivo' }, 'Guardado');
    this.name = h('input', { class: 'project-name', value: store.project.name, 'aria-label': 'Nombre del proyecto',
      onchange: () => store.update((d) => { d.name = this.name.value || 'Proyecto sin título'; }, { label: 'Renombrar proyecto' }) });

    root.append(
      h('div', { class: 'brand' }, h('span', { class: 'logo' }, icon('film', 18)), h('span', { class: 'brand-name' }, 'JamEditVid')),
      h('div', { class: 'project-box' }, this.name, this.saved),
      h('div', { class: 'top-actions' },
        h('button', { class: 'btn ghost hide-sm', onclick: actions.newProject, title: 'Nuevo proyecto' }, icon('file', 16), h('span', {}, 'Nuevo')),
        h('button', { class: 'btn ghost', onclick: actions.openConverter, title: 'Convertir cualquier archivo a otro formato' }, icon('convert', 16), h('span', { class: 'hide-xs' }, 'Convertidor')),
        h('button', { class: 'icon-btn hide-sm', onclick: () => this.#help(), title: 'Atajos de teclado' }, icon('keyboard')),
        h('button', { class: 'btn primary', onclick: actions.openExport }, icon('download', 16), h('span', {}, 'Exportar'))),
    );

    store.subscribe((c) => {
      if (c.type !== 'project') return;
      if (document.activeElement !== this.name) this.name.value = store.project.name;
      this.saved.textContent = 'Guardando…';
      this.saved.classList.add('pending');
    });
    bus.on('project:saved', () => { this.saved.textContent = 'Guardado'; this.saved.classList.remove('pending'); });
  }

  #help() {
    const m = openModal({ title: 'Atajos de teclado' });
    m.body.append(h('table', { class: 'shortcuts' }, SHORTCUTS_HELP.map(([k, d]) => h('tr', {}, h('td', {}, h('kbd', {}, k)), h('td', {}, d)))));
  }
}
