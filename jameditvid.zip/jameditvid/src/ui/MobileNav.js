/**
 * Navegación inferior para celular: abre Medios / Propiedades como paneles
 * deslizables sobre la línea de tiempo (la vista previa siempre visible).
 */
import { h } from './dom.js';
import { icon } from './icons.js';

export class MobileNav {
  #open = null;

  constructor(root, { bus, store, actions }) {
    this.panels = {
      media: document.getElementById('panel-media'),
      inspector: document.getElementById('panel-inspector'),
    };
    const item = (id, ic, label, fn) => h('button', { class: 'nav-item', dataset: { id }, onclick: fn }, icon(ic, 20), h('span', {}, label));
    this.items = [
      item('media', 'folder', 'Medios', () => this.toggle('media')),
      item('inspector', 'sliders', 'Editar', () => this.toggle('inspector')),
      item('text', 'text', 'Texto', () => actions.addText()),
      item('convert', 'convert', 'Convertir', () => actions.openConverter()),
      item('export', 'download', 'Exportar', () => actions.openExport()),
    ];
    root.append(...this.items);

    // Botón de cierre dentro de cada panel (solo visible en móvil)
    for (const [id, panel] of Object.entries(this.panels)) {
      panel.prepend(h('div', { class: 'sheet-grip', onclick: () => this.toggle(id) }, h('span')));
    }
    bus.on('ui:show-panel', (id) => this.show(id));
    // En celular, al tocar un clip se abre "Editar" solo si el usuario ya lo tenía abierto.
    store.subscribe((c) => { if (c.type === 'selection' && store.selection && this.#open === 'media') this.show('inspector'); });
  }

  show(id) {
    if (!matchMedia('(max-width: 900px), (max-height: 500px) and (pointer: coarse)').matches) return;
    this.#open = id;
    this.#apply();
  }

  toggle(id) {
    this.#open = this.#open === id ? null : id;
    this.#apply();
  }

  #apply() {
    for (const [id, panel] of Object.entries(this.panels)) panel.classList.toggle('sheet-open', this.#open === id);
    for (const b of this.items) b.classList.toggle('active', b.dataset.id === this.#open);
  }
}
