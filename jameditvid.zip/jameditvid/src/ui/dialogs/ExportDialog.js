/** Diálogo de exportación del proyecto. */
import { h, clear } from '../dom.js';
import { icon } from '../icons.js';
import { select, slider, numberInput, section } from '../controls.js';
import { openModal, progressBar } from '../feedback.js';
import { FORMATS, OUTPUT_RESOLUTIONS, getFormat } from '../../export/formats.js';
import { formatTime, even } from '../../core/utils.js';
import { resultBlock } from './shareResult.js';

export function openExportDialog({ store, engine, exporter, bus }) {
  const p = store.project;
  if (engine.duration <= 0) { bus.emit('toast', { type: 'warn', text: 'Agrega clips a la línea de tiempo antes de exportar' }); return; }

  const opts = {
    format: localStorage.getItem('jam.exportFormat') || 'mp4',
    res: 'project', width: p.width, height: p.height,
    fit: 'contain', fps: p.fps, quality: Number(localStorage.getItem('jam.exportQuality') || 75),
  };
  let running = false;
  const m = openModal({ title: 'Exportar video', onClose: () => {
    if (running && !confirm('¿Cancelar la exportación en curso?')) return false;
    if (running) exporter.cancel();
  } });

  const resOptions = [['project', `Igual al proyecto — ${p.width}×${p.height}`], ...OUTPUT_RESOLUTIONS.filter((r) => r.id !== 'source').map((r) => [r.id, r.label])];
  const customBox = h('div', { class: 'grid-2', hidden: true },
    numberInput({ label: 'Ancho', value: opts.width, min: 16, max: 7680, step: 2, onChange: (v) => { opts.width = even(v); info(); } }),
    numberInput({ label: 'Alto', value: opts.height, min: 16, max: 7680, step: 2, onChange: (v) => { opts.height = even(v); info(); } }));
  const fitSel = select({ label: 'Si la proporción es distinta', value: opts.fit,
    options: [['contain', 'Encajar con barras'], ['cover', 'Rellenar (recorta bordes)'], ['stretch', 'Estirar']], onChange: (v) => { opts.fit = v; } });
  const infoLine = h('p', { class: 'meta-line' });
  const info = () => {
    const fmt = getFormat(opts.format);
    infoLine.textContent = `${fmt.kind === 'audio' ? 'Audio' : `${opts.width}×${opts.height} · ${opts.fps} fps`} · duración ${formatTime(engine.duration, false)}`
      + (fmt.kind === 'frame' ? ' · se exporta el fotograma actual' : ' · el render tarda aprox. lo mismo que el video');
    fitSel.hidden = Math.abs(opts.width / opts.height - p.width / p.height) < 0.01;
  };

  const form = h('div', {},
    section('Formato',
      select({ value: opts.format, options: FORMATS.map((f) => [f.id, f.label]), onChange: (v) => { opts.format = v; localStorage.setItem('jam.exportFormat', v); info(); } }),
      slider({ label: 'Calidad', value: opts.quality, min: 10, max: 100, step: 1, onInput: (v) => { opts.quality = v; localStorage.setItem('jam.exportQuality', String(v)); } })),
    section('Dimensiones',
      select({ value: 'project', options: [...resOptions, ['custom', 'Personalizada…']], onChange: (id) => {
        customBox.hidden = id !== 'custom';
        if (id === 'project') { opts.width = p.width; opts.height = p.height; }
        const r = OUTPUT_RESOLUTIONS.find((x) => x.id === id);
        if (r && r.w) { opts.width = r.w; opts.height = r.h; }
        info();
      } }),
      customBox, fitSel,
      select({ label: 'Fotogramas por segundo', value: opts.fps, options: [15, 24, 25, 30, 50, 60].map((f) => [f, `${f} fps`]), onChange: (v) => { opts.fps = Number(v); info(); } })),
    infoLine,
    h('div', { class: 'modal-actions' },
      h('button', { class: 'btn', onclick: () => m.close() }, 'Cancelar'),
      h('button', { class: 'btn primary', onclick: () => start() }, icon('download', 16), h('span', {}, 'Exportar'))));
  m.body.append(form);
  info();

  async function start() {
    running = true;
    const bar = progressBar();
    const status = h('p', { class: 'status' }, 'Preparando…');
    const log = h('pre', { class: 'log', hidden: true });
    const logBtn = h('button', { class: 'btn small ghost', onclick: () => { log.hidden = !log.hidden; } }, 'Ver registro técnico');
    const cancelBtn = h('button', { class: 'btn danger', onclick: () => exporter.cancel() }, 'Cancelar');
    clear(m.body).append(h('div', { class: 'export-progress' }, status, bar.el, h('div', { class: 'row gap-s' }, cancelBtn, logBtn), log));
    const t0 = performance.now();
    try {
      const { blob, filename } = await exporter.export({
        ...opts,
        onProgress: (v) => bar.set(v),
        onStatus: (s) => { status.textContent = s; },
        onLog: (line) => { log.textContent += `${line}\n`; if (log.textContent.length > 60000) log.textContent = log.textContent.slice(-40000); },
      });
      running = false;
      clear(m.body).append(
        h('p', { class: 'status ok' }, icon('sparkles', 16), `¡Listo en ${formatTime((performance.now() - t0) / 1000, false)}!`),
        resultBlock(blob, filename),
        h('div', { class: 'modal-actions' }, h('button', { class: 'btn', onclick: () => m.close() }, 'Cerrar')));
    } catch (err) {
      running = false;
      if (err?.name === 'AbortError' || /terminat|cancel/i.test(err?.message)) { m.forceClose(); bus.emit('toast', { text: 'Exportación cancelada' }); return; }
      console.error(err);
      status.textContent = `Error: ${err.message}`;
      status.classList.add('error');
      cancelBtn.textContent = 'Cerrar';
      cancelBtn.onclick = () => m.forceClose();
    }
  }
}
