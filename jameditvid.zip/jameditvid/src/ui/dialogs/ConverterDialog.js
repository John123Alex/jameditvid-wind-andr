/**
 * Convertidor universal: cualquier archivo de video/audio/imagen animada a
 * cualquier formato y dimensión (FFmpeg en un worker). Admite varios archivos en cola.
 */
import { h, clear } from '../dom.js';
import { icon } from '../icons.js';
import { select, slider, numberInput, toggle, section, textInput } from '../controls.js';
import { openModal, progressBar } from '../feedback.js';
import { FORMATS, OUTPUT_RESOLUTIONS, getFormat } from '../../export/formats.js';
import { buildFFmpegArgs } from '../../export/commandBuilder.js';
import { formatBytes, formatTime } from '../../core/utils.js';
import { resultBlock } from './shareResult.js';

export function openConverterDialog({ ffmpeg, bus, initialFiles = [] }) {
  let files = [...initialFiles];
  let running = false;
  const o = {
    format: 'mp4', res: 'source', width: 0, height: 0, fit: 'contain', padColor: '#000000', fps: 0,
    quality: 70, trimStart: 0, trimEnd: 0, rotate: 0, flipH: false, flipV: false, speed: 1, volume: 1,
    removeAudio: false, custom: '',
  };
  const m = openModal({ title: 'Convertidor universal', wide: true, onClose: () => {
    if (running && !confirm('¿Cancelar la conversión?')) return false;
    if (running) ffmpeg.cancel();
  } });

  const input = h('input', { type: 'file', multiple: true, hidden: true, accept: 'video/*,audio/*,image/gif,image/webp,.mkv,.avi,.mov,.flv,.wmv,.3gp,.ts,.mts',
    onchange: () => { addFiles(input.files); input.value = ''; } });
  const fileList = h('div', { class: 'conv-files' });
  const cmdPreview = h('code', { class: 'cmd' });
  const customBox = h('div', { class: 'grid-2', hidden: true });

  function addFiles(list) {
    for (const f of list) files.push(f);
    drawFiles();
    probeFirst();
  }
  function drawFiles() {
    clear(fileList);
    if (!files.length) {
      fileList.append(h('div', { class: 'dropzone', onclick: () => input.click() }, icon('upload', 26), h('p', {}, 'Elige o arrastra los archivos a convertir'), h('small', {}, 'MP4, MOV, MKV, AVI, WEBM, FLV, WMV, MP3, WAV, GIF…')));
      return;
    }
    files.forEach((f, i) => fileList.append(h('div', { class: 'conv-file' }, icon(f.type.startsWith('audio') ? 'music' : 'film', 16),
      h('span', { class: 'grow ellipsis' }, f.name), h('span', { class: 'dim' }, formatBytes(f.size)),
      h('button', { class: 'icon-btn sm', title: 'Quitar', onclick: () => { files.splice(i, 1); drawFiles(); } }, icon('x', 14)))));
    fileList.append(h('button', { class: 'btn small ghost', onclick: () => input.click() }, icon('plus', 14), h('span', {}, 'Añadir más')));
  }
  const meta = { duration: 0 };
  const metaLine = h('p', { class: 'meta-line' });
  async function probeFirst() {
    const f = files[0];
    if (!f) return;
    const el = document.createElement(f.type.startsWith('audio') ? 'audio' : 'video');
    el.preload = 'metadata';
    el.src = URL.createObjectURL(f);
    await new Promise((r) => { el.onloadedmetadata = r; el.onerror = r; setTimeout(r, 4000); });
    meta.duration = Number.isFinite(el.duration) ? el.duration : 0;
    metaLine.textContent = el.videoWidth ? `${f.name}: ${el.videoWidth}×${el.videoHeight} · ${formatTime(meta.duration)}` : meta.duration ? `${f.name}: ${formatTime(meta.duration)}` : '';
    releaseEl(el);
  }

  const update = () => {
    const { args } = build('input.ext');
    cmdPreview.textContent = `ffmpeg ${args.map((a) => (/[\s;\[\]]/.test(a) ? `"${a}"` : a)).join(' ')}`;
  };
  const set = (k) => (v) => { o[k] = v; update(); };
  const build = (inputName) => {
    if (o.custom.trim()) {
      // Modo avanzado: el usuario escribe sus propios argumentos. {in} y {out} se reemplazan.
      const fmt = getFormat(o.format);
      const out = `output.${fmt.ext}`;
      const args = splitArgs(o.custom.replaceAll('{in}', inputName).replaceAll('{out}', out));
      if (!args.includes(inputName)) args.unshift('-i', inputName);
      if (!args.includes(out)) args.push(out);
      return { args, output: out, mime: fmt.mime };
    }
    return buildFFmpegArgs({ ...o, input: inputName, padColor: o.padColor.replace('#', '0x') });
  };

  customBox.append(
    numberInput({ label: 'Ancho (px)', value: 1920, min: 16, max: 7680, step: 2, onChange: (v) => { o.width = v; update(); } }),
    numberInput({ label: 'Alto (0 = proporcional)', value: 1080, min: 0, max: 7680, step: 2, onChange: (v) => { o.height = v; update(); } }));

  const form = h('div', { class: 'conv-grid' },
    h('div', {},
      section('Archivos', fileList, metaLine),
      section('Formato de salida',
        select({ value: o.format, options: FORMATS.map((f) => [f.id, f.label]), onChange: set('format') }),
        slider({ label: 'Calidad (más alta = archivo más grande)', value: o.quality, min: 5, max: 100, step: 1, onInput: set('quality') })),
      section('Dimensiones',
        select({ value: 'source', options: OUTPUT_RESOLUTIONS.map((r) => [r.id, r.label]), onChange: (id) => {
          const r = OUTPUT_RESOLUTIONS.find((x) => x.id === id);
          customBox.hidden = id !== 'custom';
          if (id === 'custom') { o.width = 1920; o.height = 1080; } else { o.width = r.w; o.height = r.h; }
          update();
        } }),
        customBox,
        select({ label: 'Ajuste', value: o.fit, options: [['contain', 'Encajar con barras'], ['cover', 'Rellenar recortando'], ['stretch', 'Estirar']], onChange: set('fit') }),
        select({ label: 'Fotogramas por segundo', value: 0, options: [[0, 'Igual al original'], [12, '12'], [15, '15'], [24, '24'], [25, '25'], [30, '30'], [50, '50'], [60, '60']], onChange: (v) => set('fps')(Number(v)) }))),
    h('div', {},
      section('Recortar',
        h('div', { class: 'grid-2' },
          numberInput({ label: 'Desde (s)', value: 0, min: 0, step: 0.1, onChange: set('trimStart') }),
          numberInput({ label: 'Hasta (s, 0 = final)', value: 0, min: 0, step: 0.1, onChange: set('trimEnd') }))),
      section('Transformar',
        select({ label: 'Rotar', value: 0, options: [[0, 'Sin rotación'], [90, '90° horario'], [270, '90° antihorario'], [180, '180°']], onChange: (v) => set('rotate')(Number(v)) }),
        h('div', { class: 'row gap-m wrap' }, toggle({ label: 'Espejo H', value: false, onChange: set('flipH') }), toggle({ label: 'Espejo V', value: false, onChange: set('flipV') })),
        slider({ label: 'Velocidad', value: 1, min: 0.25, max: 4, step: 0.05, onInput: set('speed') })),
      section('Audio',
        slider({ label: 'Volumen', value: 1, min: 0, max: 3, step: 0.05, onInput: set('volume') }),
        toggle({ label: 'Quitar audio', value: false, onChange: set('removeAudio') })),
      h('details', { class: 'advanced' }, h('summary', {}, 'Avanzado: argumentos propios de FFmpeg'),
        textInput({ value: '', multiline: true, placeholder: 'Ej.: -i {in} -vf "eq=contrast=1.3" -c:v libx264 -crf 20 {out}', onInput: set('custom') }),
        h('small', { class: 'dim' }, 'Si escribes algo aquí se ignoran las opciones de arriba (excepto el formato, que define la extensión).'))),
  );

  m.body.append(form, h('div', { class: 'cmd-box' }, h('span', { class: 'dim' }, 'Comando:'), cmdPreview),
    h('div', { class: 'modal-actions' },
      h('button', { class: 'btn', onclick: () => m.close() }, 'Cerrar'),
      h('button', { class: 'btn primary', onclick: () => run() }, icon('convert', 16), h('span', {}, 'Convertir'))),
    input);
  drawFiles();
  probeFirst();
  update();

  m.el.addEventListener('dragover', (e) => e.preventDefault());
  m.el.addEventListener('drop', (e) => { e.preventDefault(); e.stopPropagation(); if (e.dataTransfer.files.length) addFiles(e.dataTransfer.files); });

  async function run() {
    if (!files.length) { bus.emit('toast', { type: 'warn', text: 'Primero elige un archivo' }); return; }
    running = true;
    const queue = [...files];
    const results = h('div', { class: 'conv-results' });
    const status = h('p', { class: 'status' });
    const bar = progressBar();
    const log = h('pre', { class: 'log', hidden: true });
    const cancelBtn = h('button', { class: 'btn danger', onclick: () => { ffmpeg.cancel(); queue.length = 0; } }, 'Cancelar');
    const backBtn = h('button', { class: 'btn', hidden: true, onclick: () => { m.forceClose(); openConverterDialog({ ffmpeg, bus }); } }, 'Convertir otros');
    clear(m.body).append(status, bar.el, h('div', { class: 'row gap-s' }, cancelBtn, backBtn,
      h('button', { class: 'btn small ghost', onclick: () => { log.hidden = !log.hidden; } }, 'Ver registro técnico')), log, results);

    let i = 0;
    const total = queue.length;
    while (queue.length) {
      const f = queue.shift();
      i++;
      bar.set(0);
      status.textContent = `(${i}/${total}) ${f.name}`;
      let duration = 0;
      try {
        const el = document.createElement('video');
        el.preload = 'metadata'; el.src = URL.createObjectURL(f);
        await new Promise((r) => { el.onloadedmetadata = r; el.onerror = r; setTimeout(r, 3000); });
        duration = Number.isFinite(el.duration) ? el.duration : 0;
        releaseEl(el);
        if (o.trimEnd > 0) duration = Math.min(duration || Infinity, o.trimEnd) - o.trimStart;
        else duration -= o.trimStart;
        duration /= o.speed;
        const blob = await ffmpeg.run(f, build, {
          duration: Math.max(0, duration),
          onProgress: (p) => bar.set(p),
          onStatus: (s) => { status.textContent = `(${i}/${total}) ${f.name} — ${s}`; },
          onLog: (l) => { log.textContent += `${l}\n`; if (log.textContent.length > 60000) log.textContent = log.textContent.slice(-40000); },
        });
        const name = `${f.name.replace(/\.[^.]+$/, '')}_convertido.${getFormat(o.format).ext}`;
        results.append(resultBlock(blob, name));
      } catch (err) {
        if (/terminat|cancel|abort/i.test(err?.message || '')) { status.textContent = 'Conversión cancelada'; break; }
        console.error(err);
        results.append(h('p', { class: 'status error' }, `${f.name}: ${err.message}`));
        log.hidden = false;
      }
    }
    running = false;
    if (!/cancelada/.test(status.textContent)) status.textContent = `Terminado: ${total} archivo(s)`;
    cancelBtn.hidden = true;
    backBtn.hidden = false;
  }
}

/** Divide respetando comillas: -vf "a, b" → ['-vf', 'a, b'] */
function splitArgs(s) {
  const out = [];
  const re = /"([^"]*)"|'([^']*)'|(\S+)/g;
  let mm;
  while ((mm = re.exec(s))) out.push(mm[1] ?? mm[2] ?? mm[3]);
  return out;
}

/** Suelta el archivo de un elemento multimedia temporal sin errores de red. */
function releaseEl(el) {
  const url = el.src;
  el.removeAttribute('src');
  el.load();
  URL.revokeObjectURL(url);
}
