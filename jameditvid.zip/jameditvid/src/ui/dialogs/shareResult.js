/** Bloque de resultado: descargar / compartir (en celular abre el menú nativo). */
import { h } from '../dom.js';
import { icon } from '../icons.js';
import { downloadBlob, formatBytes } from '../../core/utils.js';

export function resultBlock(blob, filename) {
  const file = new File([blob], filename, { type: blob.type });
  const canShare = !!navigator.canShare?.({ files: [file] });
  const url = URL.createObjectURL(blob);
  const isVideo = blob.type.startsWith('video/');
  const isImage = blob.type.startsWith('image/');
  const isAudio = blob.type.startsWith('audio/');
  return h('div', { class: 'result' },
    isVideo && h('video', { src: url, controls: true, playsInline: true, class: 'result-preview' }),
    isImage && h('img', { src: url, class: 'result-preview', alt: '' }),
    isAudio && h('audio', { src: url, controls: true }),
    h('div', { class: 'result-info' }, h('strong', {}, filename), h('span', {}, formatBytes(blob.size))),
    h('div', { class: 'row gap-s wrap' },
      h('button', { class: 'btn primary', onclick: () => downloadBlob(blob, filename) }, icon('download', 16), h('span', {}, 'Descargar')),
      canShare && h('button', { class: 'btn', onclick: () => navigator.share({ files: [file], title: filename }).catch(() => {}) }, icon('upload', 16), h('span', {}, 'Compartir'))));
}
