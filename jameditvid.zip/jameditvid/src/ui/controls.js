/**
 * Controles de formulario reutilizables. Todos reciben:
 *   value, onInput(v) (mientras se arrastra) y onChange(v) (al soltar).
 */
import { h } from './dom.js';

export function field(label, control, hint) {
  return h('label', { class: 'field' },
    h('span', { class: 'field-label' }, label),
    control,
    hint && h('span', { class: 'field-hint' }, hint));
}

/** Deslizador + campo numérico sincronizados. Doble clic = valor por defecto. */
export function slider({ label, value, min, max, step = 0.01, def, onInput, format }) {
  const num = h('input', { type: 'number', class: 'num', min, max, step, value: round(value, step) });
  const range = h('input', { type: 'range', class: 'range', min, max, step, value });
  const fire = (v, from) => {
    v = Math.min(max, Math.max(min, Number(v)));
    if (Number.isNaN(v)) return;
    if (from !== range) range.value = v;
    if (from !== num) num.value = round(v, step);
    onInput(v);
  };
  range.addEventListener('input', () => fire(range.value, range));
  num.addEventListener('change', () => fire(num.value, num));
  if (def != null) range.addEventListener('dblclick', () => fire(def));
  const wrap = h('div', { class: 'slider-row' }, range, num);
  if (format) num.title = format(value);
  return h('div', { class: 'field' }, h('span', { class: 'field-label' }, label), wrap);
}

const round = (v, step) => {
  const d = String(step).includes('.') ? String(step).split('.')[1].length : 0;
  return Number(v).toFixed(Math.min(d, 3));
};

export function select({ label, value, options, onChange }) {
  const s = h('select', { class: 'select' },
    options.map(([v, text]) => h('option', { value: v, selected: String(v) === String(value) }, text)));
  s.addEventListener('change', () => onChange(s.value));
  return label ? field(label, s) : s;
}

export function toggle({ label, value, onChange }) {
  const input = h('input', { type: 'checkbox', checked: !!value });
  input.addEventListener('change', () => onChange(input.checked));
  return h('label', { class: 'toggle' }, input, h('span', { class: 'toggle-track' }), h('span', {}, label));
}

export function colorInput({ label, value, onInput }) {
  const c = h('input', { type: 'color', class: 'color', value });
  c.addEventListener('input', () => onInput(c.value));
  return field(label, c);
}

export function textInput({ label, value, onInput, multiline = false, placeholder = '' }) {
  const el = multiline
    ? h('textarea', { class: 'input', rows: 3, placeholder }, value)
    : h('input', { class: 'input', value, placeholder });
  if (multiline) el.value = value;
  el.addEventListener('input', () => onInput(el.value));
  return label ? field(label, el) : el;
}

export function numberInput({ label, value, min, max, step = 1, onChange }) {
  const el = h('input', { type: 'number', class: 'input', min, max, step, value });
  el.addEventListener('change', () => onChange(Number(el.value)));
  return label ? field(label, el) : el;
}

export function section(title, ...children) {
  return h('section', { class: 'insp-section' }, h('h4', {}, title), ...children);
}

export function button(text, onclick, { icon: ic, variant = '', title, disabled } = {}) {
  return h('button', { class: `btn ${variant}`, onclick, title: title ?? (typeof text === 'string' ? text : ''), disabled }, ic, text && h('span', {}, text));
}
