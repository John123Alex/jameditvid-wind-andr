/**
 * Servicio FFmpeg (WebAssembly). Corre en un Web Worker propio de
 * @ffmpeg/ffmpeg, así que la interfaz NUNCA se bloquea mientras convierte.
 *
 * - Carga perezosa: el núcleo (~30 MB) solo se descarga la primera vez que
 *   se necesita y luego queda en la caché del navegador.
 * - cancel(): termina el worker al instante y lo recrea en la próxima tarea.
 */
import { FFmpeg } from '@ffmpeg/ffmpeg';
import { fetchFile } from '@ffmpeg/util';
import { parseProgressLine } from './commandBuilder.js';

const BASE = new URL(`${import.meta.env.BASE_URL}ffmpeg/`, location.href).href;

export class FFmpegService {
  #ffmpeg = null;
  #loading = null;
  #busy = false;

  constructor(bus) { this.bus = bus; }

  get loaded() { return !!this.#ffmpeg?.loaded; }
  get busy() { return this.#busy; }

  async load(onStatus) {
    if (this.loaded) return this.#ffmpeg;
    if (this.#loading) return this.#loading;
    this.#loading = (async () => {
      onStatus?.('Cargando motor de conversión (solo la primera vez)…');
      const ff = new FFmpeg();
      await ff.load({ coreURL: `${BASE}ffmpeg-core.js`, wasmURL: `${BASE}ffmpeg-core.wasm` });
      this.#ffmpeg = ff;
      return ff;
    })();
    try { return await this.#loading; } finally { this.#loading = null; }
  }

  /**
   * Ejecuta una conversión.
   * @param {Blob|File} file      archivo de entrada
   * @param {(inputName) => {args, output, mime}} build  constructor de argumentos
   * @param {{ duration?: number, onProgress?: (p:number)=>void, onLog?: (s:string)=>void, onStatus?: (s:string)=>void }} opts
   * @returns {Promise<Blob>}
   */
  async run(file, build, { duration = 0, onProgress, onLog, onStatus } = {}) {
    if (this.#busy) throw new Error('Ya hay una conversión en curso');
    this.#busy = true;
    const ff = await this.load(onStatus);
    const ext = (file.name?.split('.').pop() || guessExt(file.type)).toLowerCase().replace(/[^a-z0-9]/g, '') || 'bin';
    const input = `input.${ext}`;
    const { args, output, mime } = build(input);

    const logHandler = ({ message }) => {
      onLog?.(message);
      const p = parseProgressLine(message, duration);
      if (p != null) onProgress?.(p);
    };
    const progressHandler = ({ progress }) => {
      if (!duration && progress >= 0 && progress <= 1) onProgress?.(progress);
    };
    ff.on('log', logHandler);
    ff.on('progress', progressHandler);
    try {
      onStatus?.('Preparando archivo…');
      await ff.writeFile(input, await fetchFile(file));
      onStatus?.('Convirtiendo…');
      onLog?.(`ffmpeg ${args.join(' ')}`);
      const code = await ff.exec(args);
      if (code !== 0) throw new Error('FFmpeg terminó con error. Revisa el registro (formato o códec no soportado).');
      const data = await ff.readFile(output);
      onProgress?.(1);
      return new Blob([data.buffer], { type: mime });
    } finally {
      ff.off('log', logHandler);
      ff.off('progress', progressHandler);
      // Libera memoria del sistema de archivos virtual.
      if (this.#ffmpeg) {
        await ff.deleteFile(input).catch(() => {});
        await ff.deleteFile(output).catch(() => {});
      }
      this.#busy = false;
    }
  }

  /** Cancela de inmediato (mata el worker). */
  cancel() {
    if (!this.#ffmpeg) return;
    try { this.#ffmpeg.terminate(); } catch { /* ignore */ }
    this.#ffmpeg = null;
    this.#busy = false;
  }
}

function guessExt(mime = '') {
  if (mime.includes('mp4')) return 'mp4';
  if (mime.includes('webm')) return 'webm';
  if (mime.includes('quicktime')) return 'mov';
  if (mime.includes('mpeg')) return 'mp3';
  if (mime.includes('wav')) return 'wav';
  return 'bin';
}
