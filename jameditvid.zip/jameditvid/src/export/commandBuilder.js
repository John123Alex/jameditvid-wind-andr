/**
 * Construye los argumentos de FFmpeg a partir de opciones legibles.
 * Función pura: fácil de probar y de modificar.
 *
 * @param {object} o
 * @param {string} o.input        nombre del archivo de entrada en el FS virtual
 * @param {string} o.format       id del formato (ver formats.js)
 * @param {number} [o.width]      0 = mantener
 * @param {number} [o.height]     0 = mantener / proporcional
 * @param {'contain'|'cover'|'stretch'} [o.fit]
 * @param {string} [o.padColor]
 * @param {number} [o.fps]        0 = mantener
 * @param {number} [o.quality]    0..100
 * @param {number} [o.trimStart]  segundos
 * @param {number} [o.trimEnd]    segundos (0 = hasta el final)
 * @param {0|90|180|270} [o.rotate]
 * @param {boolean} [o.flipH]
 * @param {boolean} [o.flipV]
 * @param {number} [o.speed]
 * @param {number} [o.volume]
 * @param {boolean} [o.removeAudio]
 * @param {boolean} [o.remux]     solo cambiar contenedor (sin recodificar, rapidísimo)
 * @param {number} [o.frameTime]  instante para exportar un fotograma
 */
import { getFormat } from './formats.js';
import { even } from '../core/utils.js';

export function buildFFmpegArgs(o) {
  const fmt = getFormat(o.format);
  const output = `output.${fmt.ext}`;
  const q = o.quality ?? 70;
  const args = ['-hide_banner', '-y'];

  // Recorte: -ss antes de -i = búsqueda rápida
  if (fmt.kind !== 'frame' && o.trimStart > 0) args.push('-ss', String(o.trimStart));
  if (fmt.kind === 'frame') args.push('-ss', String(o.frameTime ?? o.trimStart ?? 0));
  args.push('-i', o.input);
  if (fmt.kind !== 'frame' && o.trimEnd > 0 && o.trimEnd > (o.trimStart || 0)) {
    args.push('-t', String(o.trimEnd - (o.trimStart || 0)));
  }

  // Remux: copia directa de flujos (no aplica filtros).
  if (o.remux) {
    args.push('-c', 'copy');
    if (fmt.extra) args.push(...fmt.extra);
    args.push(output);
    return { args, output, mime: fmt.mime, format: fmt };
  }

  const vf = videoFilters(o);
  const af = audioFilters(o);

  switch (fmt.kind) {
    case 'audio':
      args.push('-vn');
      if (af.length) args.push('-af', af.join(','));
      args.push(...fmt.audio(q));
      break;

    case 'frame':
      if (vf.length) args.push('-vf', vf.join(','));
      args.push('-frames:v', '1');
      if (fmt.id === 'jpg') args.push('-q:v', String(Math.round(2 + (100 - q) / 10)));
      break;

    case 'gif': {
      const fps = o.fps || 15;
      const base = [...vf, `fps=${fps}`];
      if (fmt.id === 'gif') {
        // Paleta optimizada en una sola pasada: mucha mejor calidad de color.
        const colors = Math.round(32 + (q / 100) * 224);
        args.push('-filter_complex',
          `[0:v]${base.join(',')},split[a][b];[a]palettegen=max_colors=${colors}:stats_mode=diff[p];[b][p]paletteuse=dither=bayer:bayer_scale=4`,
          '-loop', '0');
      } else {
        args.push('-vf', base.join(','), ...fmt.video(q));
      }
      args.push('-an');
      break;
    }

    default: // video
      if (vf.length) args.push('-vf', vf.join(','));
      if (o.fps > 0) args.push('-r', String(o.fps));
      args.push(...fmt.video(q));
      if (o.removeAudio) args.push('-an');
      else {
        if (af.length) args.push('-af', af.join(','));
        args.push(...fmt.audio(q));
      }
      if (fmt.extra) args.push(...fmt.extra);
  }
  args.push(output);
  return { args, output, mime: fmt.mime, format: fmt };
}

function videoFilters(o) {
  const f = [];
  if (o.speed && o.speed !== 1) f.push(`setpts=PTS/${o.speed}`);
  if (o.rotate === 90) f.push('transpose=1');
  else if (o.rotate === 270) f.push('transpose=2');
  else if (o.rotate === 180) f.push('hflip,vflip');
  if (o.flipH) f.push('hflip');
  if (o.flipV) f.push('vflip');

  const w = o.width ? even(o.width) : 0;
  const h = o.height ? even(o.height) : 0;
  if (w && h) {
    const pad = o.padColor || 'black';
    if (o.fit === 'cover') f.push(`scale=${w}:${h}:force_original_aspect_ratio=increase`, `crop=${w}:${h}`);
    else if (o.fit === 'stretch') f.push(`scale=${w}:${h}`);
    else f.push(`scale=${w}:${h}:force_original_aspect_ratio=decrease`, `pad=${w}:${h}:(ow-iw)/2:(oh-ih)/2:color=${pad}`);
    f.push('setsar=1');
  } else if (w) f.push(`scale=${w}:-2`, 'setsar=1');
  else if (h) f.push(`scale=-2:${h}`, 'setsar=1');
  else if (!['gif', 'frame'].includes(getFormat(o.format).kind)) {
    // Garantiza dimensiones pares (requisito de H.264/H.265).
    f.push('scale=trunc(iw/2)*2:trunc(ih/2)*2');
  }
  return f;
}

function audioFilters(o) {
  const f = [];
  if (o.volume != null && o.volume !== 1) f.push(`volume=${o.volume}`);
  if (o.speed && o.speed !== 1) {
    // atempo solo acepta 0.5..2: se encadena para otros valores.
    let s = o.speed;
    while (s > 2) { f.push('atempo=2'); s /= 2; }
    while (s < 0.5) { f.push('atempo=0.5'); s /= 0.5; }
    f.push(`atempo=${s.toFixed(4)}`);
  }
  return f;
}

/** Extrae el progreso (0..1) de una línea de log de FFmpeg ("time=00:00:05.12"). */
export function parseProgressLine(line, totalSeconds) {
  const m = /time=(\d+):(\d+):(\d+(?:\.\d+)?)/.exec(line);
  if (!m || !totalSeconds) return null;
  const t = +m[1] * 3600 + +m[2] * 60 + +m[3];
  return Math.min(1, t / totalSeconds);
}
