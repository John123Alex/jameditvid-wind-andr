/**
 * Exportador del proyecto.
 *
 * Fase 1 (render): el motor reproduce la línea de tiempo a la resolución de
 *   salida y se graba el lienzo + la mezcla de audio con MediaRecorder
 *   (codificación por hardware del navegador → muy rápido).
 *   Si un video tarda en entregar su frame, la grabación se pausa: no hay saltos.
 * Fase 2 (conversión): FFmpeg en un worker cambia al formato pedido
 *   (o solo re-empaqueta, que es casi instantáneo).
 */
import { getFormat } from './formats.js';
import { buildFFmpegArgs } from './commandBuilder.js';
import { even } from '../core/utils.js';

const RECORDER_TYPES = {
  mp4: ['video/mp4;codecs=avc1.640028,mp4a.40.2', 'video/mp4;codecs=avc1.42E01E,mp4a.40.2', 'video/mp4;codecs=avc1,mp4a.40.2', 'video/mp4'],
  webm: ['video/webm;codecs=vp9,opus', 'video/webm;codecs=vp8,opus', 'video/webm'],
};

export class Exporter {
  #cancelled = false;
  #recorder = null;

  constructor({ engine, compositor, mixer, ffmpeg, bus }) {
    this.engine = engine;
    this.compositor = compositor;
    this.mixer = mixer;
    this.ffmpeg = ffmpeg;
    this.bus = bus;
  }

  /** Mejor tipo de MediaRecorder disponible según el formato final. */
  static pickRecorderType(formatId) {
    const preferMp4 = ['mp4', 'mov', 'mkv', 'mp4-hevc', '3gp', 'avi', 'm4a'].includes(formatId);
    const order = preferMp4 ? [...RECORDER_TYPES.mp4, ...RECORDER_TYPES.webm] : [...RECORDER_TYPES.webm, ...RECORDER_TYPES.mp4];
    return order.find((t) => window.MediaRecorder?.isTypeSupported?.(t)) ?? '';
  }

  /**
   * @param {{ width, height, fps, format, quality, fit, bitrate?, onProgress, onStatus, onLog }} opts
   * @returns {Promise<{blob: Blob, filename: string}>}
   */
  async export(opts) {
    const { onProgress = () => {}, onStatus = () => {} } = opts;
    const fmt = getFormat(opts.format);
    const project = this.engine.project;
    const duration = this.engine.duration;
    if (duration <= 0) throw new Error('El proyecto está vacío: agrega clips a la línea de tiempo.');
    this.#cancelled = false;

    if (fmt.kind === 'frame') return this.exportFrame(opts);
    if (!window.MediaRecorder) throw new Error('Este navegador no permite grabar video (MediaRecorder).');

    const width = even(opts.width);
    const height = even(opts.height);
    const fps = opts.fps || project.fps;
    const prev = { w: this.compositor.canvas.width, h: this.compositor.canvas.height, fit: this.engine.fit };

    const cleanups = [];
    try {
      // ---------- Fase 1: render en tiempo real ----------
      onStatus('Renderizando… mantén esta pestaña visible');
      this.engine.pause();
      this.compositor.resize(width, height);
      this.engine.fit = opts.fit || 'contain';
      this.engine.strict = true;
      this.engine.seek(0);
      await this.#waitReady(0);

      const mimeType = Exporter.pickRecorderType(fmt.id);
      const stream = this.compositor.canvas.captureStream(fps);
      const tracks = [...stream.getVideoTracks()];
      try { tracks.push(this.mixer.exportTrack()); } catch { /* sin audio */ }
      const mixed = new MediaStream(tracks);
      const pixels = width * height * fps;
      const bitrate = opts.bitrate || Math.round(Math.min(60e6, Math.max(2e6, pixels * 0.12 * (0.5 + (opts.quality ?? 70) / 100))));
      const recorder = new MediaRecorder(mixed, { mimeType, videoBitsPerSecond: bitrate, audioBitsPerSecond: 192_000 });
      this.#recorder = recorder;
      const chunks = [];
      recorder.ondataavailable = (e) => e.data.size && chunks.push(e.data);
      const stopped = new Promise((res) => { recorder.onstop = res; });

      cleanups.push(this.bus.on('engine:stall', () => recorder.state === 'recording' && recorder.pause()));
      cleanups.push(this.bus.on('engine:resume', () => recorder.state === 'paused' && recorder.resume()));
      cleanups.push(this.bus.on('time', (t) => onProgress(Math.min(1, t / duration) * 0.7, 'render')));
      const onVis = () => {
        if (document.hidden && recorder.state === 'recording') recorder.pause();
        else if (!document.hidden && recorder.state === 'paused' && !this.engine.stalled) recorder.resume();
      };
      document.addEventListener('visibilitychange', onVis);
      cleanups.push(() => document.removeEventListener('visibilitychange', onVis));

      const ended = new Promise((res) => cleanups.push(this.bus.once('ended', res)));
      recorder.start(1000);
      await this.engine.play();
      await ended;
      // Pequeño margen para que el último frame llegue al codificador.
      await new Promise((r) => setTimeout(r, 120));
      if (recorder.state !== 'inactive') recorder.stop();
      await stopped;
      stream.getTracks().forEach((t) => t.stop());
      if (this.#cancelled) throw new DOMException('Cancelado', 'AbortError');

      const recordedType = (mimeType || 'video/webm').split(';')[0];
      const recorded = new Blob(chunks, { type: recordedType });
      const recExt = recordedType.includes('mp4') ? 'mp4' : 'webm';
      const filename = `${sanitize(project.name)}.${fmt.ext}`;

      // ---------- Fase 2: conversión ----------
      const sameContainer = (fmt.ext === recExt) && (fmt.id === 'webm' || (fmt.id === 'mp4' && recExt === 'mp4'));
      onStatus(sameContainer ? 'Optimizando archivo…' : `Convirtiendo a ${fmt.ext.toUpperCase()}…`);
      try {
        const blob = await this.ffmpeg.run(
          new File([recorded], `render.${recExt}`, { type: recordedType }),
          (input) => buildFFmpegArgs({
            input, format: fmt.id, quality: opts.quality, remux: sameContainer,
            fps: sameContainer ? 0 : fps,
          }),
          {
            duration,
            onProgress: (p) => onProgress(0.7 + p * 0.3, 'convert'),
            onStatus,
            onLog: opts.onLog,
          },
        );
        return { blob, filename };
      } catch (err) {
        if (this.#cancelled) throw err;
        if (sameContainer) {
          console.warn('Optimización omitida:', err);
          return { blob: recorded, filename: `${sanitize(project.name)}.${recExt}` };
        }
        throw err;
      }
    } finally {
      cleanups.forEach((fn) => fn());
      this.engine.strict = false;
      this.engine.pause();
      this.engine.fit = prev.fit;
      this.compositor.resize(prev.w, prev.h);
      this.#recorder = null;
      this.bus.emit('preview:resize');
      this.engine.requestRender();
    }
  }

  /** Exporta el fotograma actual como imagen (PNG/JPG). */
  async exportFrame(opts) {
    const fmt = getFormat(opts.format);
    const prev = { w: this.compositor.canvas.width, h: this.compositor.canvas.height, fit: this.engine.fit };
    try {
      this.compositor.resize(even(opts.width), even(opts.height));
      this.engine.fit = opts.fit || 'contain';
      await this.#waitReady(this.engine.time);
      this.engine.renderNow();
      const blob = await new Promise((res) => this.compositor.canvas.toBlob(res, fmt.mime, 0.92));
      return { blob, filename: `${sanitize(this.engine.project.name)}_frame.${fmt.ext}` };
    } finally {
      this.engine.fit = prev.fit;
      this.compositor.resize(prev.w, prev.h);
      this.bus.emit('preview:resize');
      this.engine.requestRender();
    }
  }

  async #waitReady(t, timeout = 8000) {
    const start = performance.now();
    this.engine.renderNow(); // crea/posiciona los elementos de video
    while (!this.engine.pool.allReady(this.engine.project, t)) {
      if (performance.now() - start > timeout) break;
      await new Promise((r) => setTimeout(r, 50));
      this.engine.renderNow();
    }
  }

  cancel() {
    this.#cancelled = true;
    this.ffmpeg.cancel();
    if (this.engine.playing) {
      this.engine.pause();
      this.bus.emit('ended');
    }
    if (this.#recorder && this.#recorder.state !== 'inactive') this.#recorder.stop();
  }
}

const sanitize = (s) => (s || 'video').replace(/[^\w\-áéíóúñÁÉÍÓÚÑ ]+/g, '').trim().replace(/\s+/g, '_') || 'video';
