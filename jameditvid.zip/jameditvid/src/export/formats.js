/**
 * Catálogo de formatos de salida. Cada formato define cómo construir los
 * argumentos de FFmpeg. Añadir un formato = añadir una entrada aquí.
 *
 * quality: 0 (mínima) .. 100 (máxima)
 */
const crf = (q, best = 16, worst = 36) => Math.round(worst - (q / 100) * (worst - best));
const aBitrate = (q) => `${q > 80 ? 256 : q > 50 ? 192 : q > 25 ? 128 : 96}k`;

// "ultrafast/veryfast": en WebAssembly la codificación es lenta; priorizamos tiempo.
const x264 = (q, speed = 'veryfast') => ['-c:v', 'libx264', '-preset', speed, '-crf', String(crf(q)), '-pix_fmt', 'yuv420p'];

export const FORMATS = [
  { id: 'mp4', label: 'MP4 (H.264) — el más compatible', ext: 'mp4', mime: 'video/mp4', kind: 'video',
    video: (q) => x264(q), audio: (q) => ['-c:a', 'aac', '-b:a', aBitrate(q)], extra: ['-movflags', '+faststart'] },
  { id: 'mp4-hevc', label: 'MP4 (H.265/HEVC) — menor peso, más lento', ext: 'mp4', mime: 'video/mp4', kind: 'video',
    video: (q) => ['-c:v', 'libx265', '-preset', 'ultrafast', '-crf', String(crf(q, 20, 38)), '-pix_fmt', 'yuv420p', '-tag:v', 'hvc1'],
    audio: (q) => ['-c:a', 'aac', '-b:a', aBitrate(q)], extra: ['-movflags', '+faststart'] },
  { id: 'webm', label: 'WebM (VP8) — web', ext: 'webm', mime: 'video/webm', kind: 'video',
    video: (q) => ['-c:v', 'libvpx', '-deadline', 'realtime', '-cpu-used', '8', '-crf', String(crf(q, 6, 40)), '-b:v', `${Math.round(1 + q / 12)}M`],
    audio: () => ['-c:a', 'libvorbis', '-q:a', '5'] },
  { id: 'mov', label: 'MOV (QuickTime / iPhone)', ext: 'mov', mime: 'video/quicktime', kind: 'video',
    video: (q) => x264(q), audio: (q) => ['-c:a', 'aac', '-b:a', aBitrate(q)], extra: ['-movflags', '+faststart'] },
  { id: 'mkv', label: 'MKV (Matroska)', ext: 'mkv', mime: 'video/x-matroska', kind: 'video',
    video: (q) => x264(q), audio: (q) => ['-c:a', 'aac', '-b:a', aBitrate(q)] },
  { id: 'avi', label: 'AVI (MPEG-4, equipos antiguos)', ext: 'avi', mime: 'video/x-msvideo', kind: 'video',
    video: (q) => ['-c:v', 'mpeg4', '-q:v', String(Math.round(2 + (100 - q) / 12))], audio: () => ['-c:a', 'libmp3lame', '-q:a', '3'] },
  { id: '3gp', label: '3GP (celulares básicos)', ext: '3gp', mime: 'video/3gpp', kind: 'video',
    video: () => ['-c:v', 'libx264', '-preset', 'veryfast', '-profile:v', 'baseline', '-crf', '30', '-pix_fmt', 'yuv420p'], audio: () => ['-c:a', 'aac', '-b:a', '64k', '-ac', '1'] },
  { id: 'gif', label: 'GIF animado', ext: 'gif', mime: 'image/gif', kind: 'gif' },
  { id: 'webp', label: 'WebP animado', ext: 'webp', mime: 'image/webp', kind: 'gif',
    video: (q) => ['-c:v', 'libwebp', '-lossless', '0', '-q:v', String(Math.round(q)), '-loop', '0'] },
  { id: 'mp3', label: 'MP3 (solo audio)', ext: 'mp3', mime: 'audio/mpeg', kind: 'audio',
    audio: (q) => ['-c:a', 'libmp3lame', '-b:a', aBitrate(q)] },
  { id: 'wav', label: 'WAV (audio sin compresión)', ext: 'wav', mime: 'audio/wav', kind: 'audio', audio: () => ['-c:a', 'pcm_s16le'] },
  { id: 'm4a', label: 'M4A / AAC (solo audio)', ext: 'm4a', mime: 'audio/mp4', kind: 'audio', audio: (q) => ['-c:a', 'aac', '-b:a', aBitrate(q)] },
  { id: 'ogg', label: 'OGG Vorbis (solo audio)', ext: 'ogg', mime: 'audio/ogg', kind: 'audio', audio: () => ['-c:a', 'libvorbis', '-q:a', '6'] },
  { id: 'opus', label: 'Opus (solo audio, voz)', ext: 'opus', mime: 'audio/ogg', kind: 'audio', audio: (q) => ['-c:a', 'libopus', '-b:a', aBitrate(q)] },
  { id: 'flac', label: 'FLAC (audio sin pérdida)', ext: 'flac', mime: 'audio/flac', kind: 'audio', audio: () => ['-c:a', 'flac'] },
  { id: 'png', label: 'PNG (un fotograma)', ext: 'png', mime: 'image/png', kind: 'frame' },
  { id: 'jpg', label: 'JPG (un fotograma)', ext: 'jpg', mime: 'image/jpeg', kind: 'frame' },
];

export const getFormat = (id) => FORMATS.find((f) => f.id === id) ?? FORMATS[0];

export const OUTPUT_RESOLUTIONS = [
  { id: 'source', label: 'Igual al original', w: 0, h: 0 },
  { id: '2160p', label: '4K — 3840×2160', w: 3840, h: 2160 },
  { id: '1440p', label: '2K — 2560×1440', w: 2560, h: 1440 },
  { id: '1080p', label: 'Full HD — 1920×1080', w: 1920, h: 1080 },
  { id: '720p', label: 'HD — 1280×720', w: 1280, h: 720 },
  { id: '480p', label: 'SD — 854×480', w: 854, h: 480 },
  { id: '360p', label: '640×360', w: 640, h: 360 },
  { id: '240p', label: '426×240', w: 426, h: 240 },
  { id: 'v1080', label: 'Vertical 1080×1920 (Reels/TikTok)', w: 1080, h: 1920 },
  { id: 'v720', label: 'Vertical 720×1280', w: 720, h: 1280 },
  { id: 'sq1080', label: 'Cuadrado 1080×1080', w: 1080, h: 1080 },
  { id: 'p45', label: 'Retrato 4:5 — 1080×1350', w: 1080, h: 1350 },
  { id: 'custom', label: 'Personalizada…', w: 0, h: 0 },
];
