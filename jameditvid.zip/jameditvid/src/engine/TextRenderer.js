/**
 * Dibuja textos en un canvas 2D para usarlos como textura.
 * Cachea el resultado: solo se vuelve a dibujar si cambia el contenido/estilo.
 */
export class TextRenderer {
  #cache = new Map(); // clipId -> { key, canvas, version }

  /** Devuelve { canvas, version } con el texto listo. */
  render(clip, progress = 1) {
    const t = clip.text;
    const visibleChars = progress >= 1 ? Infinity : Math.floor(t.content.length * progress);
    const key = JSON.stringify(t) + '|' + visibleChars;
    const hit = this.#cache.get(clip.id);
    if (hit && hit.key === key) return hit;

    const canvas = hit?.canvas ?? document.createElement('canvas');
    const g = canvas.getContext('2d');
    const font = `${t.italic ? 'italic ' : ''}${t.bold ? '700' : '400'} ${t.size}px ${t.font}`;
    const fullLines = t.content.split('\n');
    const lines = visibleChars === Infinity ? fullLines : cutLines(fullLines, visibleChars);

    g.font = font;
    // El tamaño se calcula con el texto completo para que no "salte" al escribir.
    const widths = fullLines.map((l) => g.measureText(l || ' ').width);
    const lineH = t.size * t.lineHeight;
    const pad = (t.background ? t.padding : 0) + t.strokeWidth + (t.shadow ? t.size * 0.12 : 0) + 4;
    const w = Math.ceil(Math.max(1, ...widths) + pad * 2);
    const h = Math.ceil(lineH * fullLines.length + pad * 2);
    canvas.width = Math.min(w, 8192);
    canvas.height = Math.min(h, 8192);

    g.font = font; // al redimensionar se resetea el contexto
    g.textBaseline = 'middle';
    g.textAlign = t.align;
    g.lineJoin = 'round';

    if (t.background) {
      g.globalAlpha = t.bgOpacity;
      g.fillStyle = t.bgColor;
      roundRect(g, 0, 0, canvas.width, canvas.height, Math.min(24, t.size * 0.25));
      g.globalAlpha = 1;
    }
    const x = t.align === 'left' ? pad : t.align === 'right' ? canvas.width - pad : canvas.width / 2;
    lines.forEach((line, i) => {
      const y = pad + lineH * i + lineH / 2;
      if (t.shadow) {
        g.shadowColor = 'rgba(0,0,0,0.6)';
        g.shadowBlur = t.size * 0.12;
        g.shadowOffsetY = t.size * 0.04;
      }
      if (t.strokeWidth > 0) {
        g.strokeStyle = t.strokeColor;
        g.lineWidth = t.strokeWidth * 2;
        g.strokeText(line, x, y);
        g.shadowColor = 'transparent';
      }
      g.fillStyle = t.color;
      g.fillText(line, x, y);
      g.shadowColor = 'transparent';
    });

    const entry = { key, canvas, version: (hit?.version ?? 0) + 1 };
    this.#cache.set(clip.id, entry);
    return entry;
  }

  release(clipId) { this.#cache.delete(clipId); }
  prune(aliveIds) { for (const id of this.#cache.keys()) if (!aliveIds.has(id)) this.#cache.delete(id); }
}

function cutLines(lines, chars) {
  const out = [];
  let left = chars;
  for (const l of lines) {
    if (left <= 0) { out.push(''); continue; }
    out.push(l.slice(0, left));
    left -= l.length + 1;
  }
  return out;
}

function roundRect(g, x, y, w, h, r) {
  g.beginPath();
  g.moveTo(x + r, y);
  g.arcTo(x + w, y, x + w, y + h, r);
  g.arcTo(x + w, y + h, x, y + h, r);
  g.arcTo(x, y + h, x, y, r);
  g.arcTo(x, y, x + w, y, r);
  g.closePath();
  g.fill();
}
