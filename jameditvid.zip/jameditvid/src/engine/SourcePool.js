/**
 * Pool de elementos <video>/<audio>: uno por clip con medio temporal.
 * Se encarga de mantenerlos sincronizados con el reloj del motor:
 *  - en reproducción: play() y corrección de deriva si se desfasa.
 *  - en pausa: seek exacto al frame (sin acumular seeks pendientes).
 * También "precalienta" el clip siguiente para que el corte sea limpio.
 */
import { clipEnd, sourceTime, trackById } from '../model/project.js';

const DRIFT_TOLERANCE = 0.2; // s
const PRELOAD_AHEAD = 1.5; // s

export class SourcePool {
  #entries = new Map(); // clipId -> entry

  constructor({ media, mixer, onFrameReady }) {
    this.media = media;
    this.mixer = mixer;
    this.onFrameReady = onFrameReady; // se llama cuando un seek termina (re-render)
  }

  /** Obtiene (o crea) el elemento de un clip. */
  get(clip) {
    let e = this.#entries.get(clip.id);
    if (e && e.mediaId !== clip.mediaId) { this.#dispose(clip.id); e = null; }
    if (e) return e;
    const url = this.media.url(clip.mediaId);
    if (!url) return null;
    const isVideo = clip.type === 'video';
    const el = document.createElement(isVideo ? 'video' : 'audio');
    el.preload = 'auto';
    el.playsInline = true;
    el.setAttribute('playsinline', '');
    el.crossOrigin = 'anonymous';
    el.src = url;
    e = { el, mediaId: clip.mediaId, isVideo, audio: null, pendingSeek: null, frameVersion: 0 };
    try { e.audio = this.mixer.connectElement(el); } catch (err) { console.warn('Audio no conectado', err); }
    el.addEventListener('seeked', () => {
      e.frameVersion++;
      if (e.pendingSeek != null) {
        const target = e.pendingSeek;
        e.pendingSeek = null;
        if (Math.abs(el.currentTime - target) > 0.01) { el.currentTime = target; return; }
      }
      this.onFrameReady?.();
    });
    el.addEventListener('loadeddata', () => this.onFrameReady?.());
    this.#entries.set(clip.id, e);
    return e;
  }

  #seek(e, t) {
    if (e.el.seeking) { e.pendingSeek = t; return; }
    e.el.currentTime = t;
  }

  /** Sincroniza todos los elementos con el instante `t`. */
  sync(project, t, playing, fps) {
    const alive = new Set();
    for (const clip of project.clips) {
      if (clip.type !== 'video' && clip.type !== 'audio') continue;
      alive.add(clip.id);
      const active = t >= clip.start && t < clipEnd(clip);
      const upcoming = !active && clip.start > t && clip.start - t < PRELOAD_AHEAD;
      const existing = this.#entries.get(clip.id);
      if (!active && !upcoming) {
        if (existing && !existing.el.paused) existing.el.pause();
        continue;
      }
      const e = this.get(clip);
      if (!e) continue;
      const el = e.el;
      const track = trackById(project, clip.trackId);

      if (upcoming) {
        if (!el.paused) el.pause();
        if (Math.abs(el.currentTime - clip.offset) > 0.05 && !el.seeking) this.#seek(e, clip.offset);
        if (e.audio) this.mixer.setGain(e.audio.gain, 0);
        continue;
      }

      const target = sourceTime(clip, t);
      el.playbackRate = clip.speed;
      if (playing) {
        if (el.paused) {
          if (Math.abs(el.currentTime - target) > 0.05) el.currentTime = target;
          el.play().catch(() => {});
        } else if (Math.abs(el.currentTime - target) > DRIFT_TOLERANCE * Math.max(1, clip.speed)) {
          this.#seek(e, target);
        }
      } else {
        if (!el.paused) el.pause();
        if (Math.abs(el.currentTime - target) > 0.5 / fps) this.#seek(e, target);
      }

      if (e.audio) {
        const local = t - clip.start;
        let g = clip.muted || track?.muted ? 0 : clip.volume;
        if (clip.fadeIn > 0 && local < clip.fadeIn) g *= local / clip.fadeIn;
        const remain = clip.duration - local;
        if (clip.fadeOut > 0 && remain < clip.fadeOut) g *= Math.max(0, remain / clip.fadeOut);
        this.mixer.setGain(e.audio.gain, playing ? g : 0);
      }
    }
    for (const id of this.#entries.keys()) if (!alive.has(id)) this.#dispose(id);
  }

  /** ¿Todos los videos activos tienen su frame listo? (para exportar sin frames negros) */
  allReady(project, t) {
    for (const clip of project.clips) {
      if (clip.type !== 'video' || t < clip.start || t >= clipEnd(clip)) continue;
      const e = this.#entries.get(clip.id);
      if (!e || e.el.readyState < 2 || e.el.seeking) return false;
    }
    return true;
  }

  /** Fuente para el compositor (o null si aún no hay frame). */
  videoSource(clip) {
    const e = this.#entries.get(clip.id);
    if (!e || !e.isVideo || e.el.readyState < 2 || !e.el.videoWidth) return null;
    return { source: e.el, width: e.el.videoWidth, height: e.el.videoHeight };
  }

  pauseAll() { for (const e of this.#entries.values()) e.el.pause(); }

  #dispose(id) {
    const e = this.#entries.get(id);
    if (!e) return;
    e.el.pause();
    try { e.audio?.source.disconnect(); e.audio?.gain.disconnect(); } catch { /* ya desconectado */ }
    e.el.removeAttribute('src');
    e.el.load();
    this.#entries.delete(id);
  }

  disposeAll() { for (const id of [...this.#entries.keys()]) this.#dispose(id); }
}
