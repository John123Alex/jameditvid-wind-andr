/**
 * Motor de reproducción: reloj maestro, bucle de render y sincronía.
 *
 * - El tiempo avanza con performance.now() (reloj estable).
 * - Solo se renderiza cuando hace falta: en reproducción cada frame,
 *   en pausa únicamente tras un cambio (seek, edición, frame listo).
 * - Modo estricto (exportación): si algún video no tiene su frame listo,
 *   el reloj se congela hasta que lo tenga → sin saltos ni frames negros.
 */
import { projectDuration, visualClipsAt } from '../model/project.js';
import { animatedState } from '../effects/animations.js';
import { SourcePool } from './SourcePool.js';
import { TextRenderer } from './TextRenderer.js';
import { clamp } from '../core/utils.js';

export class PlaybackEngine {
  time = 0;
  playing = false;
  loop = false;
  strict = false; // true durante la exportación
  stalled = false;
  fit = 'contain';

  #raf = 0;
  #renderQueued = false;
  #anchorPerf = 0;
  #anchorTime = 0;
  #endTime = null;
  #wasHidden = false;

  constructor({ store, bus, media, compositor, mixer }) {
    this.store = store;
    this.bus = bus;
    this.media = media;
    this.compositor = compositor;
    this.mixer = mixer;
    this.text = new TextRenderer();
    this.pool = new SourcePool({ media, mixer, onFrameReady: () => this.requestRender() });
    compositor.onRestored = () => this.requestRender();

    store.subscribe((c) => {
      if (c.type !== 'project') return;
      const ids = new Set(store.project.clips.map((x) => x.id));
      this.compositor.prune(ids);
      this.text.prune(ids);
      if (this.time > this.duration) this.time = this.duration;
      this.requestRender();
    });
    bus.on('media:changed', () => this.requestRender());
    document.addEventListener('visibilitychange', () => { if (document.hidden) this.#wasHidden = true; });
  }

  get project() { return this.store.project; }
  get duration() { return projectDuration(this.project); }
  get fps() { return this.project.fps; }

  async play({ endTime = null } = {}) {
    if (this.playing) return;
    await this.mixer.resume();
    this.#endTime = endTime;
    const end = endTime ?? this.duration;
    if (this.time >= end - 1e-3) this.time = 0;
    if (end <= 0) return;
    this.playing = true;
    this.stalled = false;
    this.#anchor();
    this.bus.emit('playstate', true);
    this.#loop();
  }

  pause() {
    if (!this.playing) return;
    this.playing = false;
    this.stalled = false;
    cancelAnimationFrame(this.#raf);
    this.pool.pauseAll();
    this.bus.emit('playstate', false);
    this.requestRender();
  }

  toggle() { return this.playing ? this.pause() : this.play(); }

  seek(t) {
    this.time = clamp(t, 0, Math.max(this.duration, 0));
    if (this.playing) this.#anchor();
    this.bus.emit('time', this.time);
    this.requestRender();
  }

  /** Avanza/retrocede n frames. */
  step(frames) {
    this.pause();
    this.seek(Math.round((this.time + frames / this.fps) * this.fps) / this.fps);
  }

  #anchor() {
    this.#anchorPerf = performance.now();
    this.#anchorTime = this.time;
  }

  #loop = () => {
    if (!this.playing) return;
    const now = performance.now();
    // Si la pestaña estuvo oculta (rAF detenido) no "saltamos" el tiempo perdido al exportar.
    if (this.#wasHidden) {
      this.#wasHidden = false;
      if (this.strict) this.#anchor();
    }

    if (this.stalled) {
      if (this.pool.allReady(this.project, this.time)) {
        this.stalled = false;
        this.#anchor();
        this.bus.emit('engine:resume');
      }
    } else {
      this.time = this.#anchorTime + (now - this.#anchorPerf) / 1000;
    }

    const end = this.#endTime ?? this.duration;
    if (this.time >= end) {
      this.time = end;
      if (this.loop && !this.strict) { this.time = 0; this.#anchor(); }
      else {
        this.#frame();
        this.pause();
        this.bus.emit('ended');
        return;
      }
    }
    if (this.strict && !this.stalled && !this.pool.allReady(this.project, this.time)) {
      this.stalled = true;
      this.bus.emit('engine:stall');
    }
    this.#frame();
    this.#raf = requestAnimationFrame(this.#loop);
  };

  /** Pide un render en el próximo frame (agrupa varias peticiones). */
  requestRender() {
    if (this.playing || this.#renderQueued) return;
    this.#renderQueued = true;
    requestAnimationFrame(() => {
      this.#renderQueued = false;
      if (!this.playing) this.#frame();
    });
  }

  /** Sincroniza fuentes, compone el frame y avisa a la interfaz. */
  #frame() {
    const project = this.project;
    this.pool.sync(project, this.time, this.playing && !this.stalled, this.fps);
    this.compositor.render({ project, layers: this.buildLayers(this.time), fit: this.fit });
    this.bus.emit('time', this.time);
  }

  /** Renderiza ya mismo (para capturas). */
  renderNow() { this.#frame(); }

  buildLayers(t) {
    const layers = [];
    for (const clip of visualClipsAt(this.project, t)) {
      const state = animatedState(clip, t);
      const localTime = t - clip.start;
      let src = null;
      if (clip.type === 'video') {
        const v = this.pool.videoSource(clip);
        if (v) src = { ...v, version: null };
        else if (this.compositor.textures.has(clip.id)) {
          const e = this.compositor.textures.get(clip.id);
          src = { source: null, width: e.w, height: e.h, version: null };
        }
      } else if (clip.type === 'image') {
        const c = this.media.bitmap(clip.mediaId);
        if (c) src = { source: c, width: c.width, height: c.height, version: clip.mediaId };
      } else if (clip.type === 'text') {
        const r = this.text.render(clip, state.textProgress);
        src = { source: r.canvas, width: r.canvas.width, height: r.canvas.height, version: r.version };
      }
      if (!src) continue;
      layers.push({ clip, ...src, state, localTime });
    }
    return layers;
  }
}
