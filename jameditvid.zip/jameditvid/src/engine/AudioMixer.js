/**
 * Mezclador de audio (Web Audio API).
 * Cada clip con sonido tiene su propio nodo de ganancia -> master.
 * El master va a los altavoces y, al exportar, también a una pista grabable.
 */
export class AudioMixer {
  #ctx = null;
  #master = null;
  #exportDest = null;
  #analyser = null;

  get ctx() {
    if (!this.#ctx) {
      const Ctx = window.AudioContext || window.webkitAudioContext;
      this.#ctx = new Ctx({ latencyHint: 'interactive' });
      this.#master = this.#ctx.createGain();
      this.#analyser = this.#ctx.createAnalyser();
      this.#analyser.fftSize = 256;
      this.#master.connect(this.#analyser);
      this.#master.connect(this.#ctx.destination);
    }
    return this.#ctx;
  }

  get master() { this.ctx; return this.#master; }

  /** Debe llamarse dentro de un gesto del usuario (clic/toque) en móviles. */
  async resume() {
    if (this.ctx.state !== 'running') {
      try { await this.ctx.resume(); } catch { /* el navegador puede negarlo sin gesto */ }
    }
  }

  /** Conecta un <video>/<audio> al mezclador. Devuelve su nodo de ganancia. */
  connectElement(el) {
    const source = this.ctx.createMediaElementSource(el);
    const gain = this.ctx.createGain();
    source.connect(gain).connect(this.master);
    return { source, gain };
  }

  setGain(gainNode, value) {
    const now = this.ctx.currentTime;
    gainNode.gain.cancelScheduledValues(now);
    gainNode.gain.setTargetAtTime(value, now, 0.012);
  }

  setMasterVolume(v) { this.master.gain.value = v; }

  /** Nivel actual 0..1 (para el vúmetro). */
  level() {
    if (!this.#analyser) return 0;
    const data = new Uint8Array(this.#analyser.fftSize);
    this.#analyser.getByteTimeDomainData(data);
    let peak = 0;
    for (const v of data) peak = Math.max(peak, Math.abs(v - 128));
    return peak / 128;
  }

  /** Pista de audio para grabar durante la exportación. */
  exportTrack() {
    if (!this.#exportDest) {
      this.#exportDest = this.ctx.createMediaStreamDestination();
      this.master.connect(this.#exportDest);
    }
    return this.#exportDest.stream.getAudioTracks()[0];
  }
}
