/**
 * Worker: calcula los picos de la forma de onda fuera del hilo principal
 * para que la interfaz nunca se congele con audios largos.
 * Entrada: { id, channels: Float32Array[], buckets }  Salida: { id, peaks }
 */
self.onmessage = (e) => {
  const { id, channels, buckets } = e.data;
  const len = channels[0].length;
  const size = Math.max(1, Math.floor(len / buckets));
  const peaks = new Float32Array(buckets);
  for (let b = 0; b < buckets; b++) {
    let max = 0;
    const startI = b * size;
    const endI = Math.min(len, startI + size);
    // Muestreo con salto para archivos enormes: precisión visual suficiente.
    const step = Math.max(1, Math.floor(size / 400));
    for (const ch of channels) {
      for (let i = startI; i < endI; i += step) {
        const v = Math.abs(ch[i]);
        if (v > max) max = v;
      }
    }
    peaks[b] = max;
  }
  self.postMessage({ id, peaks }, [peaks.buffer]);
};
