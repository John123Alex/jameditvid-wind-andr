/**
 * Biblioteca de medios: importa archivos, guarda sus metadatos y
 * ofrece recursos listos para el render (URL de objeto, ImageBitmap).
 *
 * Registro de un medio:
 * { id, name, kind, mime, size, duration, width, height, thumb, waveform }
 */
import { uid } from '../core/utils.js';
import { detectKind, probeMedia, buildWaveform } from './analysis.js';

export class MediaLibrary {
  #items = new Map(); // id -> registro
  #blobs = new Map(); // id -> Blob
  #urls = new Map(); // id -> objectURL
  #bitmaps = new Map(); // id -> ImageBitmap (imágenes)

  constructor({ bus, storage }) {
    this.bus = bus;
    this.storage = storage;
  }

  get items() { return [...this.#items.values()]; }
  get(id) { return this.#items.get(id); }
  blob(id) { return this.#blobs.get(id); }

  url(id) {
    if (!this.#urls.has(id) && this.#blobs.has(id)) this.#urls.set(id, URL.createObjectURL(this.#blobs.get(id)));
    return this.#urls.get(id);
  }

  bitmap(id) { return this.#bitmaps.get(id) ?? null; }

  /** Restaura los medios guardados en IndexedDB. */
  async restore() {
    const records = await this.storage.getAllMedia();
    for (const { blob, ...meta } of records) {
      this.#items.set(meta.id, meta);
      this.#blobs.set(meta.id, blob);
      if (meta.kind === 'image') await this.#loadBitmap(meta.id);
    }
    this.bus.emit('media:changed');
  }

  /** Importa varios archivos en paralelo (con límite para no saturar). */
  async importFiles(files) {
    const list = [...files].filter((f) => detectKind(f));
    const rejected = files.length - list.length;
    if (rejected) this.bus.emit('toast', { type: 'warn', text: `${rejected} archivo(s) no compatibles se omitieron` });
    const results = new Array(list.length);
    const queue = list.map((f, i) => [f, i]);
    const workers = Array.from({ length: Math.min(3, queue.length) }, async () => {
      while (queue.length) {
        const [f, i] = queue.shift();
        try { results[i] = await this.#importOne(f); } catch (err) {
          console.error(err);
          this.bus.emit('toast', { type: 'error', text: `No se pudo importar «${f.name}»: ${err.message}` });
        }
      }
    });
    await Promise.all(workers);
    return results.filter(Boolean); // mismo orden en que se eligieron
  }

  async #importOne(file) {
    const kind = detectKind(file);
    const id = uid('med');
    this.#blobs.set(id, file);
    const url = this.url(id);
    const placeholder = { id, name: file.name, kind, mime: file.type, size: file.size, duration: 0, loading: true };
    this.#items.set(id, placeholder);
    this.bus.emit('media:changed');

    const meta = await probeMedia(url, kind);
    const item = { ...placeholder, ...meta, loading: false, waveform: null };
    this.#items.set(id, item);
    if (kind === 'image') await this.#loadBitmap(id);
    this.bus.emit('media:changed');

    // Forma de onda en segundo plano: no bloquea la importación.
    if (kind !== 'image') {
      buildWaveform(file, id, item.duration).then((waveform) => {
        const cur = this.#items.get(id);
        if (!cur) return;
        cur.waveform = waveform;
        cur.hasAudio = !!waveform || kind === 'audio';
        this.storage.putMedia({ ...cur, blob: file }).catch(() => {});
        this.bus.emit('media:changed');
      });
    }
    this.storage.putMedia({ ...item, blob: file }).catch((e) => {
      console.warn('No se pudo guardar en IndexedDB', e);
      this.bus.emit('toast', { type: 'warn', text: 'Sin espacio para guardar el archivo localmente; se perderá al recargar.' });
    });
    return item;
  }

  /**
   * Decodifica la imagen una sola vez en un canvas (máx. 4096 px por lado)
   * para subirla rápido a la GPU sin volver a decodificar en cada frame.
   */
  async #loadBitmap(id) {
    try {
      const img = new Image();
      img.src = this.url(id);
      await img.decode();
      const MAX = 4096;
      const k = Math.min(1, MAX / Math.max(img.naturalWidth, img.naturalHeight));
      const c = document.createElement('canvas');
      c.width = Math.max(1, Math.round(img.naturalWidth * k));
      c.height = Math.max(1, Math.round(img.naturalHeight * k));
      c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
      this.#bitmaps.set(id, c);
    } catch (e) { console.warn('No se pudo decodificar la imagen', e); }
  }

  async remove(id) {
    this.#items.delete(id);
    this.#blobs.delete(id);
    const url = this.#urls.get(id);
    if (url) URL.revokeObjectURL(url);
    this.#urls.delete(id);
    this.#bitmaps.delete(id);
    await this.storage.deleteMedia(id).catch(() => {});
    this.bus.emit('media:changed');
  }

  async clear() {
    for (const id of [...this.#items.keys()]) await this.remove(id);
  }
}
