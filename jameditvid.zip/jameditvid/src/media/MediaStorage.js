/**
 * Persistencia local con IndexedDB: guarda archivos (Blobs) y el proyecto
 * para que nada se pierda al recargar la página o cerrar el navegador.
 */
const DB_NAME = 'jameditvid';
const DB_VERSION = 1;

function openDB() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains('media')) db.createObjectStore('media', { keyPath: 'id' });
      if (!db.objectStoreNames.contains('projects')) db.createObjectStore('projects', { keyPath: 'key' });
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

export class MediaStorage {
  #dbPromise = null;

  #db() {
    this.#dbPromise ??= openDB().catch((e) => { console.warn('IndexedDB no disponible', e); return null; });
    return this.#dbPromise;
  }

  async #tx(store, mode, fn) {
    const db = await this.#db();
    if (!db) return undefined;
    return new Promise((resolve, reject) => {
      const tx = db.transaction(store, mode);
      const req = fn(tx.objectStore(store));
      tx.oncomplete = () => resolve(req?.result);
      tx.onerror = () => reject(tx.error);
      tx.onabort = () => reject(tx.error);
    });
  }

  putMedia(record) { return this.#tx('media', 'readwrite', (s) => s.put(record)); }
  deleteMedia(id) { return this.#tx('media', 'readwrite', (s) => s.delete(id)); }
  getAllMedia() { return this.#tx('media', 'readonly', (s) => s.getAll()).then((r) => r ?? []); }
  clearMedia() { return this.#tx('media', 'readwrite', (s) => s.clear()); }

  saveProject(project) {
    return this.#tx('projects', 'readwrite', (s) => s.put({ key: 'current', project, savedAt: Date.now() }));
  }
  loadProject() {
    return this.#tx('projects', 'readonly', (s) => s.get('current')).then((r) => r?.project ?? null);
  }

  /** Pide al navegador no borrar los datos si hay poco espacio. */
  async requestPersistence() {
    try { return await navigator.storage?.persist?.(); } catch { return false; }
  }

  async estimate() {
    try { return await navigator.storage?.estimate?.(); } catch { return null; }
  }
}
