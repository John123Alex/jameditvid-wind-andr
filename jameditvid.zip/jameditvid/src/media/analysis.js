/**
 * Análisis de archivos: metadatos, miniaturas y forma de onda.
 * Todo es asíncrono; lo pesado (picos de audio) va a un Worker.
 */

const THUMB_H = 90;

export function detectKind(file) {
  const t = file.type || '';
  if (t.startsWith('video/')) return 'video';
  if (t.startsWith('audio/')) return 'audio';
  if (t.startsWith('image/')) return 'image';
  const ext = file.name.split('.').pop().toLowerCase();
  if (['mp4', 'mov', 'webm', 'mkv', 'm4v', 'avi', '3gp', 'ogv'].includes(ext)) return 'video';
  if (['mp3', 'wav', 'ogg', 'm4a', 'aac', 'flac', 'opus', 'weba'].includes(ext)) return 'audio';
  if (['png', 'jpg', 'jpeg', 'gif', 'webp', 'bmp', 'avif', 'svg'].includes(ext)) return 'image';
  return null;
}

const once = (el, ok, fail = 'error') =>
  new Promise((resolve, reject) => {
    const onOk = () => { cleanup(); resolve(); };
    const onFail = () => { cleanup(); reject(el.error || new Error('No se pudo leer el archivo')); };
    const cleanup = () => { el.removeEventListener(ok, onOk); el.removeEventListener(fail, onFail); };
    el.addEventListener(ok, onOk);
    el.addEventListener(fail, onFail);
  });

/** Lee duración/dimensiones y genera la miniatura. */
export async function probeMedia(url, kind) {
  if (kind === 'image') {
    const img = new Image();
    img.src = url;
    await img.decode();
    const thumb = drawThumb(img, img.naturalWidth, img.naturalHeight);
    return { width: img.naturalWidth, height: img.naturalHeight, duration: 0, thumb };
  }
  if (kind === 'audio') {
    const a = new Audio();
    a.preload = 'metadata';
    a.src = url;
    await once(a, 'loadedmetadata');
    return { duration: await realDuration(a), width: 0, height: 0, thumb: null };
  }
  // video
  const v = document.createElement('video');
  v.muted = true;
  v.playsInline = true;
  v.preload = 'auto';
  v.src = url;
  await once(v, 'loadedmetadata');
  const duration = await realDuration(v);
  v.currentTime = Math.min(duration * 0.1, 1);
  await once(v, 'seeked').catch(() => {});
  const thumb = drawThumb(v, v.videoWidth, v.videoHeight);
  const meta = { duration, width: v.videoWidth, height: v.videoHeight, thumb };
  v.removeAttribute('src');
  v.load();
  return meta;
}

/** Algunos WebM grabados reportan duración Infinity: se fuerza el cálculo. */
async function realDuration(el) {
  if (Number.isFinite(el.duration) && el.duration > 0) return el.duration;
  el.currentTime = 1e9;
  await once(el, 'timeupdate').catch(() => {});
  const d = el.duration;
  el.currentTime = 0;
  return Number.isFinite(d) ? d : 0;
}

function drawThumb(source, w, h) {
  if (!w || !h) return null;
  const c = document.createElement('canvas');
  c.height = THUMB_H;
  c.width = Math.round((w / h) * THUMB_H);
  c.getContext('2d').drawImage(source, 0, 0, c.width, c.height);
  return c.toDataURL('image/jpeg', 0.7);
}

// ---------- Forma de onda ----------
let worker = null;
const pending = new Map();
function getWorker() {
  if (!worker) {
    worker = new Worker(new URL('./waveform.worker.js', import.meta.url), { type: 'module' });
    worker.onmessage = (e) => {
      pending.get(e.data.id)?.(e.data.peaks);
      pending.delete(e.data.id);
    };
  }
  return worker;
}

const MAX_DECODE_BYTES = 350 * 1024 * 1024; // evita agotar memoria en el celular

/** Devuelve una imagen (dataURL) de la forma de onda o null si no hay audio. */
export async function buildWaveform(blob, id, duration) {
  if (blob.size > MAX_DECODE_BYTES) return null;
  try {
    const buf = await blob.arrayBuffer();
    const ctx = new OfflineAudioContext(1, 1, 44100);
    const audio = await ctx.decodeAudioData(buf);
    const buckets = Math.min(4000, Math.max(200, Math.round(duration * 40)));
    const channels = [];
    for (let i = 0; i < Math.min(2, audio.numberOfChannels); i++) channels.push(audio.getChannelData(i).slice());
    const peaks = await new Promise((resolve) => {
      pending.set(id, resolve);
      getWorker().postMessage({ id, channels, buckets }, channels.map((c) => c.buffer));
    });
    return drawWaveform(peaks);
  } catch {
    return null; // sin pista de audio o códec no soportado para decodificar
  }
}

function drawWaveform(peaks) {
  const h = 60;
  const c = document.createElement('canvas');
  c.width = peaks.length;
  c.height = h;
  const g = c.getContext('2d');
  g.fillStyle = 'rgba(255,255,255,0.85)';
  let max = 0.0001;
  for (const p of peaks) max = Math.max(max, p);
  for (let i = 0; i < peaks.length; i++) {
    const v = (peaks[i] / max) * (h / 2 - 1);
    g.fillRect(i, h / 2 - v, 1, Math.max(1, v * 2));
  }
  return c.toDataURL('image/png');
}
