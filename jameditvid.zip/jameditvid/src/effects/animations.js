/**
 * Animaciones de entrada/salida y movimiento continuo (Ken Burns, etc.).
 * Todas son funciones puras: (clip, tiempo) -> ajustes de transformación.
 */
import { clamp } from '../core/utils.js';

export const ANIM_IN = [
  ['none', 'Ninguna'], ['fade', 'Aparecer (fundido)'], ['slideLeft', 'Deslizar desde la derecha'],
  ['slideRight', 'Deslizar desde la izquierda'], ['slideUp', 'Subir desde abajo'], ['slideDown', 'Bajar desde arriba'],
  ['zoomIn', 'Acercar'], ['zoomOut', 'Alejar'], ['spin', 'Girar'], ['pop', 'Rebote (pop)'], ['blurIn', 'Enfocar'],
  ['typewriter', 'Máquina de escribir (texto)'],
];
export const ANIM_OUT = [
  ['none', 'Ninguna'], ['fade', 'Desvanecer'], ['slideLeft', 'Salir a la izquierda'], ['slideRight', 'Salir a la derecha'],
  ['slideUp', 'Salir hacia arriba'], ['slideDown', 'Salir hacia abajo'], ['zoomIn', 'Acercar'], ['zoomOut', 'Alejar'],
  ['spin', 'Girar'], ['pop', 'Encoger'], ['blurIn', 'Desenfocar'],
];
export const MOTIONS = [
  ['none', 'Ninguno'], ['kenBurnsIn', 'Ken Burns (acercar)'], ['kenBurnsOut', 'Ken Burns (alejar)'],
  ['panLeft', 'Paneo a la izquierda'], ['panRight', 'Paneo a la derecha'], ['float', 'Flotar suave'], ['breathe', 'Respirar'],
];

const easeOut = (t) => 1 - (1 - t) ** 3;
const easeBack = (t) => { const c = 1.70158; return 1 + (c + 1) * (t - 1) ** 3 + c * (t - 1) ** 2; };

/** Aplica una animación con progreso p (0 = invisible, 1 = estado normal). */
function apply(type, p, s) {
  const e = easeOut(p);
  switch (type) {
    case 'fade': s.opacity *= p; break;
    case 'slideLeft': s.dx += (1 - e) * 100; break;
    case 'slideRight': s.dx -= (1 - e) * 100; break;
    case 'slideUp': s.dy += (1 - e) * 100; break;
    case 'slideDown': s.dy -= (1 - e) * 100; break;
    case 'zoomIn': s.scale *= 0.3 + 0.7 * e; s.opacity *= p; break;
    case 'zoomOut': s.scale *= 1 + (1 - e) * 0.8; s.opacity *= p; break;
    case 'spin': s.rotation += (1 - e) * 360; s.scale *= e; break;
    case 'pop': s.scale *= p < 1 ? Math.max(0, easeBack(p)) : 1; break;
    case 'blurIn': s.blur = Math.max(s.blur, (1 - e) * 18); s.opacity *= Math.min(1, p * 2); break;
    case 'typewriter': s.textProgress = Math.min(s.textProgress, p); break;
    default: break;
  }
}

/**
 * Estado animado del clip en el tiempo t de la línea.
 * Devuelve { dx, dy (en % del lienzo), scale, rotation, opacity, blur, textProgress }
 */
export function animatedState(clip, t) {
  const s = { dx: 0, dy: 0, scale: 1, rotation: 0, opacity: 1, blur: 0, textProgress: 1 };
  const local = t - clip.start;
  const remain = clip.duration - local;

  const ai = clip.animIn;
  if (ai?.type && ai.type !== 'none' && ai.duration > 0 && local < ai.duration) {
    apply(ai.type, clamp(local / ai.duration, 0, 1), s);
  }
  const ao = clip.animOut;
  if (ao?.type && ao.type !== 'none' && ao.duration > 0 && remain < ao.duration) {
    const p = clamp(remain / ao.duration, 0, 1);
    // Las salidas "deslizar" van en dirección contraria a las entradas homónimas.
    const mirrored = { slideLeft: 'slideRight', slideRight: 'slideLeft', slideUp: 'slideDown', slideDown: 'slideUp', zoomIn: 'zoomOut', zoomOut: 'zoomIn' }[ao.type] ?? ao.type;
    apply(mirrored, p, s);
  }

  const m = clip.motion;
  if (m?.type && m.type !== 'none') {
    const k = clamp(local / Math.max(clip.duration, 0.001), 0, 1);
    const a = m.amount ?? 0.15;
    switch (m.type) {
      case 'kenBurnsIn': s.scale *= 1 + a * k; s.dx += a * 10 * k; break;
      case 'kenBurnsOut': s.scale *= 1 + a * (1 - k); s.dx -= a * 10 * (1 - k); break;
      case 'panLeft': s.scale *= 1 + a; s.dx += a * 50 * (0.5 - k); break;
      case 'panRight': s.scale *= 1 + a; s.dx -= a * 50 * (0.5 - k); break;
      case 'float': s.dy += Math.sin(local * 1.5) * a * 8; s.rotation += Math.sin(local) * a * 4; break;
      case 'breathe': s.scale *= 1 + Math.sin(local * 2) * a * 0.15; break;
      default: break;
    }
  }
  return s;
}

