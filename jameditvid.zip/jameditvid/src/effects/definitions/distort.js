import { range, select } from '../params.js';

/** Distorsiones geométricas. */
export default [
  {
    id: 'wave', name: 'Ondas', category: 'distort', animated: true,
    params: [range('amplitude', 'Amplitud', 0, 0.1, 0.02, 0.001), range('frequency', 'Frecuencia', 1, 60, 12, 0.5), range('speed', 'Velocidad', 0, 10, 2)],
    glsl: `void main(){
  vec2 uv = v_uv;
  uv.x += sin(uv.y * u_frequency + u_time * u_speed) * u_amplitude;
  uv.y += cos(uv.x * u_frequency * 0.7 + u_time * u_speed) * u_amplitude * 0.5;
  emit(tex(uv)); }`,
  },
  {
    id: 'swirl', name: 'Remolino', category: 'distort',
    params: [range('angle', 'Ángulo', -10, 10, 3), range('radius', 'Radio', 0.05, 1, 0.5)],
    glsl: `void main(){
  vec2 p = (v_uv - 0.5) * vec2(u_res.x / u_res.y, 1.0);
  float d = length(p);
  if (d < u_radius) { float k = (u_radius - d) / u_radius; float a = k * k * u_angle; float s = sin(a), c = cos(a); p = mat2(c, -s, s, c) * p; }
  emit(tex(p / vec2(u_res.x / u_res.y, 1.0) + 0.5)); }`,
  },
  {
    id: 'bulge', name: 'Ojo de pez / Lupa', category: 'distort',
    params: [range('strength', 'Intensidad (− pellizco)', -1, 1, 0.5), range('radius', 'Radio', 0.1, 1, 0.6)],
    glsl: `void main(){
  vec2 aspect = vec2(u_res.x / u_res.y, 1.0);
  vec2 p = (v_uv - 0.5) * aspect;
  float d = length(p);
  if (d < u_radius) { float k = d / u_radius; p *= mix(1.0, smoothstep(0.0, 1.0, k), u_strength); }
  emit(tex(p / aspect + 0.5)); }`,
  },
  {
    id: 'kaleidoscope', name: 'Caleidoscopio', category: 'distort', animated: true,
    params: [range('segments', 'Segmentos', 2, 16, 6, 1), range('rotation', 'Rotación', 0, 360, 0, 1), range('spin', 'Giro animado', 0, 2, 0.2)],
    glsl: `void main(){
  vec2 p = v_uv - 0.5;
  float r = length(p);
  float a = atan(p.y, p.x) + radians(u_rotation) + u_time * u_spin;
  float seg = 6.2831853 / u_segments;
  a = mod(a, seg); a = abs(a - seg * 0.5);
  emit(tex(vec2(cos(a), sin(a)) * r + 0.5)); }`,
  },
  {
    id: 'mirror', name: 'Espejo', category: 'distort',
    params: [select('mode', 'Modo', [['h', 'Izquierda → derecha'], ['v', 'Arriba → abajo'], ['quad', 'Cuatro cuadrantes'], ['hr', 'Derecha → izquierda']])],
    glsl: `void main(){
  vec2 uv = v_uv;
  if (u_mode < 0.5) uv.x = uv.x > 0.5 ? 1.0 - uv.x : uv.x;
  else if (u_mode < 1.5) uv.y = uv.y < 0.5 ? 1.0 - uv.y : uv.y;
  else if (u_mode < 2.5) { uv.x = uv.x > 0.5 ? 1.0 - uv.x : uv.x; uv.y = uv.y < 0.5 ? 1.0 - uv.y : uv.y; }
  else uv.x = uv.x < 0.5 ? 1.0 - uv.x : uv.x;
  emit(tex(uv)); }`,
  },
  {
    id: 'shake', name: 'Sacudida de cámara', category: 'distort', animated: true,
    params: [range('amount', 'Intensidad', 0, 0.08, 0.015, 0.001), range('speed', 'Velocidad', 1, 40, 14), range('zoom', 'Zoom para ocultar bordes', 1, 1.3, 1.06)],
    glsl: `void main(){
  float t = u_time * u_speed;
  vec2 o = vec2(noise(vec2(t, 0.0)) - 0.5, noise(vec2(0.0, t)) - 0.5) * 2.0 * u_amount;
  emit(tex((v_uv - 0.5) / u_zoom + 0.5 + o)); }`,
  },
  {
    id: 'zoomPulse', name: 'Pulso (zoom al ritmo)', category: 'distort', animated: true,
    params: [range('bpm', 'BPM', 30, 200, 120, 1), range('amount', 'Intensidad', 0, 0.3, 0.06, 0.005)],
    glsl: `void main(){
  float beat = fract(u_time * u_bpm / 60.0);
  float z = 1.0 + u_amount * exp(-beat * 6.0);
  emit(tex((v_uv - 0.5) / z + 0.5)); }`,
  },
  {
    id: 'ripple', name: 'Gota de agua', category: 'distort', animated: true,
    params: [range('amplitude', 'Amplitud', 0, 0.05, 0.015, 0.001), range('frequency', 'Frecuencia', 5, 80, 35, 1), range('speed', 'Velocidad', 0, 10, 3)],
    glsl: `void main(){
  vec2 p = v_uv - 0.5;
  float d = length(p);
  vec2 uv = v_uv + normalize(p + 1e-5) * sin(d * u_frequency - u_time * u_speed) * u_amplitude * smoothstep(0.7, 0.0, d);
  emit(tex(uv)); }`,
  },
];
