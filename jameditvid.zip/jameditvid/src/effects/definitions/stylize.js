import { range, color, toggle } from '../params.js';

/** Efectos especiales y estilizados (muchos son animados con u_time). */
export default [
  {
    id: 'pixelate', name: 'Pixelado', category: 'stylize',
    params: [range('size', 'Tamaño de píxel', 1, 80, 12, 1)],
    glsl: `void main(){ vec2 s = u_size / u_res; emit(tex((floor(v_uv / s) + 0.5) * s)); }`,
  },
  {
    id: 'rgbSplit', name: 'Aberración cromática', category: 'stylize',
    params: [range('amount', 'Separación', 0, 30, 6, 0.1), range('angle', 'Ángulo', 0, 360, 0, 1)],
    glsl: `void main(){
  float a = radians(u_angle); vec2 o = vec2(cos(a), sin(a)) * u_amount / u_res;
  vec4 c = tex(v_uv);
  emit(vec4(tex(v_uv + o).r, c.g, tex(v_uv - o).b, c.a)); }`,
  },
  {
    id: 'glitch', name: 'Glitch digital', category: 'stylize', animated: true,
    params: [range('intensity', 'Intensidad', 0, 1, 0.5), range('speed', 'Velocidad', 0.1, 10, 4), range('blocks', 'Bloques', 4, 60, 18, 1)],
    glsl: `void main(){
  float t = floor(u_time * u_speed * 4.0);
  float row = floor(v_uv.y * u_blocks);
  float r = rand(vec2(row, t));
  float shift = (r > 1.0 - u_intensity * 0.5) ? (rand(vec2(t, row * 3.1)) - 0.5) * 0.2 * u_intensity : 0.0;
  vec2 uv = vec2(fract(v_uv.x + shift), v_uv.y);
  float split = u_intensity * 0.012 * (rand(vec2(t, 7.0)) - 0.5) * 2.0;
  vec4 c = tex(uv);
  vec3 col = vec3(tex(uv + vec2(split, 0.0)).r, c.g, tex(uv - vec2(split, 0.0)).b);
  if (rand(vec2(t, row + 50.0)) > 1.0 - u_intensity * 0.08) col = vec3(rand(uv + t));
  emit(vec4(col, c.a)); }`,
  },
  {
    id: 'vhs', name: 'VHS retro', category: 'stylize', animated: true,
    params: [range('intensity', 'Intensidad', 0, 1, 0.6), toggle('date', 'Rayas de tracking', true)],
    glsl: `void main(){
  vec2 uv = v_uv;
  float wob = sin(uv.y * 40.0 + u_time * 6.0) * 0.0015 * u_intensity;
  float track = u_date > 0.5 ? smoothstep(0.02, 0.0, abs(fract(uv.y + u_time * 0.15) - 0.5)) : 0.0;
  uv.x += wob + track * 0.02 * u_intensity;
  float sh = 0.004 * u_intensity;
  vec4 c = tex(uv);
  vec3 col = vec3(tex(uv + vec2(sh, 0.0)).r, c.g, tex(uv - vec2(sh, 0.0)).b);
  col = mix(col, vec3(luma(col)), 0.25 * u_intensity);
  col *= 0.92 + 0.08 * sin(uv.y * u_res.y * 1.5);
  col += (rand(uv * u_time) - 0.5) * 0.12 * u_intensity + track * 0.3 * u_intensity;
  emit(vec4(col, c.a)); }`,
  },
  {
    id: 'grain', name: 'Grano de película', category: 'stylize', animated: true,
    params: [range('amount', 'Cantidad', 0, 0.5, 0.12), range('size', 'Tamaño', 1, 4, 1.5, 0.1)],
    glsl: `void main(){ vec4 c = tex(v_uv);
  float n = rand(floor(v_uv * u_res / u_size) + fract(u_time * 13.7)) - 0.5;
  emit(vec4(c.rgb + n * u_amount, c.a)); }`,
  },
  {
    id: 'scanlines', name: 'Líneas CRT', category: 'stylize',
    params: [range('density', 'Densidad', 50, 1200, 400, 1), range('intensity', 'Intensidad', 0, 1, 0.35), range('curve', 'Curvatura', 0, 0.3, 0.08)],
    glsl: `void main(){
  vec2 cc = v_uv - 0.5; vec2 uv = v_uv + cc * dot(cc, cc) * u_curve * 2.0;
  if (uv.x < 0.0 || uv.x > 1.0 || uv.y < 0.0 || uv.y > 1.0) { emit(vec4(0.0, 0.0, 0.0, 1.0)); return; }
  vec4 c = tex(uv);
  float s = 0.5 + 0.5 * sin(uv.y * u_density * 3.14159);
  emit(vec4(c.rgb * (1.0 - u_intensity * s), c.a)); }`,
  },
  {
    id: 'edges', name: 'Bordes (neón)', category: 'stylize',
    params: [range('amount', 'Mezcla', 0, 1, 1), color('tint', 'Color de borde', '#00ffd5'), toggle('dark', 'Fondo oscuro', true)],
    glsl: `void main(){
  vec2 p = 1.0 / u_res;
  float tl = luma(tex(v_uv + vec2(-p.x, p.y)).rgb), t = luma(tex(v_uv + vec2(0.0, p.y)).rgb), tr = luma(tex(v_uv + p).rgb);
  float l = luma(tex(v_uv - vec2(p.x, 0.0)).rgb), r = luma(tex(v_uv + vec2(p.x, 0.0)).rgb);
  float bl = luma(tex(v_uv - p).rgb), b = luma(tex(v_uv - vec2(0.0, p.y)).rgb), br = luma(tex(v_uv + vec2(p.x, -p.y)).rgb);
  float gx = -tl - 2.0*l - bl + tr + 2.0*r + br;
  float gy = -tl - 2.0*t - tr + bl + 2.0*b + br;
  float e = clamp(length(vec2(gx, gy)) * 2.0, 0.0, 1.0);
  vec4 c = tex(v_uv);
  vec3 base = u_dark > 0.5 ? vec3(0.0) : c.rgb;
  emit(vec4(mix(c.rgb, base + u_tint * e, u_amount), c.a)); }`,
  },
  {
    id: 'halftone', name: 'Semitono (cómic)', category: 'stylize',
    params: [range('size', 'Tamaño del punto', 3, 40, 10, 1), toggle('colorDots', 'Puntos a color', true)],
    glsl: `void main(){
  vec2 px = v_uv * u_res;
  float a = radians(45.0); mat2 R = mat2(cos(a), -sin(a), sin(a), cos(a));
  vec2 g = R * px / u_size; vec2 cell = (floor(g) + 0.5);
  vec2 center = inverse(R) * cell * u_size / u_res;
  vec4 c = tex(center);
  float r = sqrt(1.0 - luma(c.rgb)) * 0.6;
  float d = smoothstep(r, r - 0.08, length(fract(g) - 0.5));
  vec3 ink = u_colorDots > 0.5 ? c.rgb * 0.6 : vec3(0.0);
  emit(vec4(mix(vec3(1.0), ink, d), c.a)); }`,
  },
  {
    id: 'thermal', name: 'Visión térmica', category: 'stylize',
    params: [range('amount', 'Cantidad', 0, 1, 1)],
    glsl: `void main(){ vec4 c = tex(v_uv); float l = luma(c.rgb);
  vec3 a = vec3(0.0, 0.0, 0.5), b = vec3(0.0, 0.8, 1.0), d = vec3(1.0, 1.0, 0.0), e = vec3(1.0, 0.0, 0.0);
  vec3 t = l < 0.33 ? mix(a, b, l / 0.33) : (l < 0.66 ? mix(b, d, (l - 0.33) / 0.33) : mix(d, e, (l - 0.66) / 0.34));
  emit(vec4(mix(c.rgb, t, u_amount), c.a)); }`,
  },
  {
    id: 'nightVision', name: 'Visión nocturna', category: 'stylize', animated: true,
    params: [range('gain', 'Ganancia', 0.5, 4, 1.8), range('noise', 'Ruido', 0, 0.5, 0.15)],
    glsl: `void main(){ vec4 c = tex(v_uv);
  float l = luma(c.rgb) * u_gain + (rand(v_uv + u_time) - 0.5) * u_noise;
  float v = smoothstep(0.75, 0.3, length(v_uv - 0.5));
  emit(vec4(vec3(0.1, 1.0, 0.2) * l * v, c.a)); }`,
  },
  {
    id: 'oldFilm', name: 'Película antigua', category: 'stylize', animated: true,
    params: [range('amount', 'Cantidad', 0, 1, 0.8), range('scratches', 'Rayones', 0, 1, 0.5)],
    glsl: `void main(){
  float t = floor(u_time * 18.0);
  vec2 uv = v_uv + vec2(0.0, (rand(vec2(t, 1.0)) - 0.5) * 0.004 * u_amount);
  vec4 c = tex(uv);
  vec3 s = vec3(dot(c.rgb, vec3(0.393,0.769,0.189)), dot(c.rgb, vec3(0.349,0.686,0.168)), dot(c.rgb, vec3(0.272,0.534,0.131)));
  vec3 col = mix(c.rgb, s, u_amount);
  col *= 0.9 + 0.1 * rand(vec2(t, 3.0));
  float x = rand(vec2(t, 9.0));
  if (rand(vec2(t, 5.0)) < u_scratches && abs(v_uv.x - x) < 0.0015) col *= 0.4;
  col += (rand(v_uv * 400.0 + t) > 0.9985 ? 0.6 : 0.0) * u_scratches;
  col *= smoothstep(0.85, 0.35, length(v_uv - 0.5) * u_amount);
  emit(vec4(col, c.a)); }`,
  },
  {
    id: 'chromaKey', name: 'Croma (pantalla verde)', category: 'keying',
    params: [color('key', 'Color a eliminar', '#00ff00'), range('similarity', 'Similitud', 0, 1, 0.35), range('smoothness', 'Suavidad', 0, 0.5, 0.08), range('spill', 'Quitar reflejo', 0, 1, 0.5)],
    glsl: `
vec2 toUV(vec3 c) { return vec2(-0.169 * c.r - 0.331 * c.g + 0.5 * c.b, 0.5 * c.r - 0.419 * c.g - 0.081 * c.b); }
void main(){
  vec4 c = tex(v_uv);
  float d = distance(toUV(c.rgb), toUV(u_key)) * 2.0;
  float a = smoothstep(u_similarity * 0.5, u_similarity * 0.5 + u_smoothness, d);
  vec3 col = c.rgb;
  float spillv = clamp(pow(clamp(d / max(u_similarity, 0.001), 0.0, 1.0), 1.5), 0.0, 1.0);
  col = mix(vec3(luma(col)), col, mix(1.0, spillv, u_spill));
  emit(vec4(col, c.a * a)); }`,
  },
  {
    id: 'lumaKey', name: 'Luma key (quitar negro)', category: 'keying',
    params: [range('threshold', 'Umbral', 0, 1, 0.1), range('smoothness', 'Suavidad', 0, 0.5, 0.1), { key: 'invert', label: 'Quitar blanco', type: 'bool', default: false }],
    glsl: `void main(){ vec4 c = tex(v_uv); float l = luma(c.rgb); if (u_invert > 0.5) l = 1.0 - l;
  emit(vec4(c.rgb, c.a * smoothstep(u_threshold, u_threshold + u_smoothness, l))); }`,
  },
];
