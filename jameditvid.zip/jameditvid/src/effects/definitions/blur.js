import { range, color } from '../params.js';

/** Desenfoques, nitidez, brillo e iluminación (algunos son multipasada). */

// Desenfoque gaussiano separable de 13 muestras: rápido incluso en celular.
const gaussianPass = (dir) => ({
  uniforms: { u_dir: dir },
  glsl: `
uniform vec2 u_dir;
void main() {
  vec2 px = u_dir * u_radius / u_res;
  vec4 sum = texture(u_tex, v_uv) * 0.1964825;
  sum += (texture(u_tex, v_uv + px * 1.411764) + texture(u_tex, v_uv - px * 1.411764)) * 0.2969069;
  sum += (texture(u_tex, v_uv + px * 3.294117) + texture(u_tex, v_uv - px * 3.294117)) * 0.0944703;
  sum += (texture(u_tex, v_uv + px * 5.176470) + texture(u_tex, v_uv - px * 5.176470)) * 0.0103813;
  outColor = sum;
}`,
});

export default [
  {
    id: 'blur', name: 'Desenfoque', category: 'blur',
    params: [range('radius', 'Radio', 0, 20, 4, 0.1)],
    passes: [gaussianPass([1, 0]), gaussianPass([0, 1]), gaussianPass([0.7, 0.7]), gaussianPass([-0.7, 0.7])],
  },
  {
    id: 'sharpen', name: 'Nitidez', category: 'blur',
    params: [range('amount', 'Cantidad', 0, 3, 0.8)],
    glsl: `void main(){
  vec2 p = 1.0 / u_res;
  vec4 c = tex(v_uv);
  vec3 n = tex(v_uv + vec2(p.x,0.)).rgb + tex(v_uv - vec2(p.x,0.)).rgb + tex(v_uv + vec2(0.,p.y)).rgb + tex(v_uv - vec2(0.,p.y)).rgb;
  emit(vec4(c.rgb + (c.rgb * 4.0 - n) * u_amount, c.a)); }`,
  },
  {
    id: 'radialBlur', name: 'Zoom blur', category: 'blur',
    params: [range('strength', 'Intensidad', 0, 0.5, 0.12), range('cx', 'Centro X', 0, 1, 0.5), range('cy', 'Centro Y', 0, 1, 0.5)],
    glsl: `void main(){
  vec2 dir = v_uv - vec2(u_cx, 1.0 - u_cy);
  vec4 acc = vec4(0.0);
  for (int i = 0; i < 24; i++) { float s = 1.0 - u_strength * float(i) / 23.0; acc += texture(u_tex, vec2(u_cx, 1.0 - u_cy) + dir * s); }
  outColor = acc / 24.0; }`,
  },
  {
    id: 'tiltShift', name: 'Tilt-shift (miniatura)', category: 'blur',
    params: [range('focus', 'Posición foco', 0, 1, 0.5), range('width', 'Ancho foco', 0.02, 0.6, 0.18), range('radius', 'Desenfoque', 0, 12, 6, 0.1)],
    glsl: `void main(){
  float d = abs((1.0 - v_uv.y) - u_focus);
  float k = smoothstep(u_width * 0.5, u_width * 1.5, d) * u_radius;
  vec2 p = k / u_res;
  vec4 acc = vec4(0.0);
  for (int x = -2; x <= 2; x++) for (int y = -2; y <= 2; y++) acc += texture(u_tex, v_uv + vec2(float(x), float(y)) * p);
  vec4 c = unpremul(acc / 25.0);
  c.rgb = mix(vec3(luma(c.rgb)), c.rgb, 1.25);
  emit(c); }`,
  },
  {
    id: 'vignette', name: 'Viñeta', category: 'light',
    params: [range('amount', 'Cantidad', 0, 1.5, 0.6), range('softness', 'Suavidad', 0.05, 1, 0.45), color('tint', 'Color', '#000000')],
    glsl: `void main(){
  vec4 c = tex(v_uv);
  vec2 d = (v_uv - 0.5) * vec2(u_res.x / u_res.y, 1.0);
  float v = smoothstep(0.8, 0.8 - u_softness, length(d) * (0.6 + u_amount * 0.6));
  emit(vec4(mix(u_tint, c.rgb, mix(1.0, v, min(u_amount, 1.0))), c.a)); }`,
  },
  {
    id: 'glow', name: 'Resplandor (bloom)', category: 'light',
    params: [range('threshold', 'Umbral', 0, 1, 0.6), range('intensity', 'Intensidad', 0, 3, 1.2), range('radius', 'Radio', 1, 20, 8, 0.1)],
    passes: [
      { glsl: `void main(){ vec4 c = tex(v_uv); float l = luma(c.rgb); emit(vec4(c.rgb * smoothstep(u_threshold, u_threshold + 0.15, l), c.a)); }` },
      gaussianPass([1, 0]),
      gaussianPass([0, 1]),
      { glsl: `void main(){ vec4 o = orig(v_uv); vec3 g = texture(u_tex, v_uv).rgb; emit(vec4(o.rgb + g * u_intensity, o.a)); }` },
    ],
  },
  {
    id: 'lightLeak', name: 'Fuga de luz', category: 'light', animated: true,
    params: [range('intensity', 'Intensidad', 0, 1.5, 0.7), range('speed', 'Velocidad', 0, 2, 0.4), color('tint', 'Color', '#ff8a3d')],
    glsl: `void main(){
  vec4 c = tex(v_uv);
  vec2 p = v_uv + vec2(sin(u_time * u_speed) * 0.3, cos(u_time * u_speed * 0.7) * 0.2);
  float leak = smoothstep(0.9, 0.0, length(p - vec2(0.1, 0.9))) + 0.6 * smoothstep(0.7, 0.0, length(p - vec2(1.0, 0.2)));
  vec3 col = c.rgb + u_tint * leak * u_intensity;
  emit(vec4(1.0 - (1.0 - c.rgb) * (1.0 - u_tint * leak * u_intensity), c.a)); }`,
  },
];
