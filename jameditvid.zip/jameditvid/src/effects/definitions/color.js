import { range, color, select } from '../params.js';

/** Efectos de corrección y gradación de color. */
export default [
  {
    id: 'adjust',
    name: 'Ajustes de color',
    category: 'color',
    params: [
      range('exposure', 'Exposición', -2, 2, 0),
      range('brightness', 'Brillo', -1, 1, 0),
      range('contrast', 'Contraste', 0, 3, 1),
      range('saturation', 'Saturación', 0, 3, 1),
      range('hue', 'Tono (°)', -180, 180, 0, 1),
      range('temperature', 'Temperatura', -1, 1, 0),
      range('tint', 'Matiz', -1, 1, 0),
      range('gamma', 'Gamma', 0.2, 3, 1),
      range('highlights', 'Altas luces', -1, 1, 0),
      range('shadows', 'Sombras', -1, 1, 0),
    ],
    glsl: `
void main() {
  vec4 c = tex(v_uv);
  vec3 col = c.rgb * pow(2.0, u_exposure);
  col += u_brightness;
  col = (col - 0.5) * u_contrast + 0.5;
  float l = luma(col);
  col += u_shadows * (1.0 - smoothstep(0.0, 0.5, l)) * 0.5;
  col += u_highlights * smoothstep(0.5, 1.0, l) * 0.5;
  col = mix(vec3(luma(col)), col, u_saturation);
  col.r += u_temperature * 0.1; col.b -= u_temperature * 0.1;
  col.g += u_tint * 0.1;
  vec3 hsv = rgb2hsv(clamp(col, 0.0, 1.0));
  hsv.x = fract(hsv.x + u_hue / 360.0);
  col = hsv2rgb(hsv);
  col = pow(max(col, 0.0), vec3(1.0 / u_gamma));
  emit(vec4(col, c.a));
}`,
  },
  {
    id: 'lut',
    name: 'Look cinematográfico',
    category: 'color',
    params: [
      select('look', 'Estilo', [
        ['teal', 'Teal & Orange'], ['vintage', 'Vintage'], ['cold', 'Frío'], ['warm', 'Cálido'],
        ['noir', 'Noir'], ['bleach', 'Bleach bypass'], ['matrix', 'Matrix'], ['pastel', 'Pastel'],
      ]),
      range('intensity', 'Intensidad', 0, 1, 0.8),
    ],
    glsl: `
vec3 look(vec3 c, float id) {
  float l = luma(c);
  if (id < 0.5) { vec3 sh = vec3(0.0, 0.35, 0.45); vec3 hi = vec3(1.0, 0.6, 0.3); return mix(c, mix(sh, hi, l) * 0.5 + c * 0.7, 0.8); }
  if (id < 1.5) { vec3 v = vec3(c.r * 0.9 + 0.08, c.g * 0.85 + 0.06, c.b * 0.7 + 0.08); return mix(vec3(luma(v)), v, 0.7); }
  if (id < 2.5) return c * vec3(0.85, 0.98, 1.15);
  if (id < 3.5) return c * vec3(1.15, 1.0, 0.82);
  if (id < 4.5) { float g = smoothstep(0.05, 0.95, l); return vec3(g); }
  if (id < 5.5) { vec3 g = vec3(l); vec3 m = mix(g, c, 0.4); return (m - 0.5) * 1.35 + 0.5; }
  if (id < 6.5) return vec3(c.r * 0.6, c.g * 1.15, c.b * 0.55);
  return mix(c, vec3(1.0), 0.25) * vec3(1.02, 0.98, 1.05);
}
void main() {
  vec4 c = tex(v_uv);
  emit(vec4(mix(c.rgb, look(c.rgb, u_look), u_intensity), c.a));
}`,
  },
  {
    id: 'grayscale', name: 'Blanco y negro', category: 'color',
    params: [range('amount', 'Cantidad', 0, 1, 1)],
    glsl: `void main(){ vec4 c = tex(v_uv); emit(vec4(mix(c.rgb, vec3(luma(c.rgb)), u_amount), c.a)); }`,
  },
  {
    id: 'sepia', name: 'Sepia', category: 'color',
    params: [range('amount', 'Cantidad', 0, 1, 1)],
    glsl: `void main(){ vec4 c = tex(v_uv);
  vec3 s = vec3(dot(c.rgb, vec3(0.393,0.769,0.189)), dot(c.rgb, vec3(0.349,0.686,0.168)), dot(c.rgb, vec3(0.272,0.534,0.131)));
  emit(vec4(mix(c.rgb, s, u_amount), c.a)); }`,
  },
  {
    id: 'invert', name: 'Negativo', category: 'color',
    params: [range('amount', 'Cantidad', 0, 1, 1)],
    glsl: `void main(){ vec4 c = tex(v_uv); emit(vec4(mix(c.rgb, 1.0 - c.rgb, u_amount), c.a)); }`,
  },
  {
    id: 'duotone', name: 'Duotono', category: 'color',
    params: [color('dark', 'Color oscuro', '#1b0b4d'), color('light', 'Color claro', '#ff7a59'), range('amount', 'Cantidad', 0, 1, 1)],
    glsl: `void main(){ vec4 c = tex(v_uv); vec3 d = mix(u_dark, u_light, luma(c.rgb)); emit(vec4(mix(c.rgb, d, u_amount), c.a)); }`,
  },
  {
    id: 'posterize', name: 'Posterizar', category: 'color',
    params: [range('levels', 'Niveles', 2, 16, 5, 1)],
    glsl: `void main(){ vec4 c = tex(v_uv); emit(vec4(floor(c.rgb * u_levels) / (u_levels - 1.0), c.a)); }`,
  },
  {
    id: 'threshold', name: 'Umbral (cómic)', category: 'color',
    params: [range('level', 'Umbral', 0, 1, 0.5), range('softness', 'Suavidad', 0, 0.5, 0.05)],
    glsl: `void main(){ vec4 c = tex(v_uv); float v = smoothstep(u_level - u_softness, u_level + u_softness, luma(c.rgb)); emit(vec4(vec3(v), c.a)); }`,
  },
  {
    id: 'colorPop', name: 'Resaltar un color', category: 'color',
    params: [color('keep', 'Color a conservar', '#ff0000'), range('range', 'Rango', 0.01, 0.5, 0.12)],
    glsl: `void main(){ vec4 c = tex(v_uv);
  float h1 = rgb2hsv(c.rgb).x, h2 = rgb2hsv(u_keep).x;
  float d = min(abs(h1 - h2), 1.0 - abs(h1 - h2));
  float k = 1.0 - smoothstep(u_range * 0.6, u_range, d);
  emit(vec4(mix(vec3(luma(c.rgb)), c.rgb, k), c.a)); }`,
  },
  {
    id: 'hueCycle', name: 'Arcoíris animado', category: 'color', animated: true,
    params: [range('speed', 'Velocidad', 0, 3, 0.5), range('amount', 'Cantidad', 0, 1, 1)],
    glsl: `void main(){ vec4 c = tex(v_uv); vec3 h = rgb2hsv(c.rgb); h.x = fract(h.x + u_time * u_speed); emit(vec4(mix(c.rgb, hsv2rgb(h), u_amount), c.a)); }`,
  },
];
