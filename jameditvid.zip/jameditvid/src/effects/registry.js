/**
 * Registro de efectos. Para añadir uno nuevo:
 *   1. Crea su definición en definitions/<categoría>.js (id, name, category, params, glsl o passes).
 *   2. Listo: el inspector genera los controles y el compositor compila el shader.
 */
import { uid } from '../core/utils.js';
import color from './definitions/color.js';
import blur from './definitions/blur.js';
import stylize from './definitions/stylize.js';
import distort from './definitions/distort.js';

export const CATEGORIES = [
  { id: 'color', name: 'Color' },
  { id: 'light', name: 'Luz' },
  { id: 'blur', name: 'Desenfoque' },
  { id: 'stylize', name: 'Especiales' },
  { id: 'distort', name: 'Distorsión' },
  { id: 'keying', name: 'Croma / recorte' },
];

const ALL = [...color, ...blur, ...stylize, ...distort];
const BY_ID = new Map(ALL.map((d) => [d.id, normalize(d)]));

/** Convierte `glsl` simple en una lista de pasadas uniforme. */
function normalize(def) {
  const passes = def.passes ?? [{ glsl: def.glsl }];
  return { ...def, passes };
}

export const effectDefinitions = () => [...BY_ID.values()];
export const getEffectDef = (id) => BY_ID.get(id);

/** Crea una instancia de efecto (lo que se guarda dentro del clip). */
export function createEffectInstance(type) {
  const def = BY_ID.get(type);
  if (!def) throw new Error(`Efecto desconocido: ${type}`);
  const params = {};
  for (const p of def.params) params[p.key] = p.default;
  return { id: uid('fx'), type, enabled: true, params };
}

/** ¿Algún efecto activo del clip depende del tiempo? */
export const clipHasAnimatedEffects = (clip) =>
  clip.effects.some((e) => e.enabled && BY_ID.get(e.type)?.animated);
