/**
 * Código GLSL común que se antepone a cada efecto.
 *
 * Dentro de un efecto dispones de:
 *   v_uv            coordenada 0..1
 *   u_res           tamaño en píxeles de la imagen
 *   u_time          segundos desde el inicio del clip (para efectos animados)
 *   tex(uv)         color de la pasada anterior (sin premultiplicar)
 *   orig(uv)        color original que recibió el efecto
 *   emit(color)     escribe el color final
 *   luma, rand, noise, rgb2hsv, hsv2rgb
 *   u_<param>       cada parámetro declarado en la definición del efecto
 */
export const PRELUDE = /* glsl */ `#version 300 es
precision highp float;
in vec2 v_uv;
out vec4 outColor;
uniform sampler2D u_tex;
uniform sampler2D u_orig;
uniform vec2 u_res;
uniform float u_time;

vec4 unpremul(vec4 c) { return c.a > 0.0001 ? vec4(c.rgb / c.a, c.a) : vec4(0.0); }
vec4 tex(vec2 uv) { return unpremul(texture(u_tex, uv)); }
vec4 orig(vec2 uv) { return unpremul(texture(u_orig, uv)); }
void emit(vec4 c) { c = clamp(c, 0.0, 1.0); outColor = vec4(c.rgb * c.a, c.a); }

float luma(vec3 c) { return dot(c, vec3(0.2126, 0.7152, 0.0722)); }
float rand(vec2 co) { return fract(sin(dot(co, vec2(12.9898, 78.233))) * 43758.5453); }
float noise(vec2 p) {
  vec2 i = floor(p); vec2 f = fract(p);
  float a = rand(i), b = rand(i + vec2(1.0, 0.0)), c = rand(i + vec2(0.0, 1.0)), d = rand(i + vec2(1.0, 1.0));
  vec2 u = f * f * (3.0 - 2.0 * f);
  return mix(a, b, u.x) + (c - a) * u.y * (1.0 - u.x) + (d - b) * u.x * u.y;
}
vec3 rgb2hsv(vec3 c) {
  vec4 K = vec4(0.0, -1.0 / 3.0, 2.0 / 3.0, -1.0);
  vec4 p = mix(vec4(c.bg, K.wz), vec4(c.gb, K.xy), step(c.b, c.g));
  vec4 q = mix(vec4(p.xyw, c.r), vec4(c.r, p.yzx), step(p.x, c.r));
  float d = q.x - min(q.w, q.y);
  float e = 1.0e-10;
  return vec3(abs(q.z + (q.w - q.y) / (6.0 * d + e)), d / (q.x + e), q.x);
}
vec3 hsv2rgb(vec3 c) {
  vec4 K = vec4(1.0, 2.0 / 3.0, 1.0 / 3.0, 3.0);
  vec3 p = abs(fract(c.xxx + K.xyz) * 6.0 - K.www);
  return c.z * mix(K.xxx, clamp(p - K.xxx, 0.0, 1.0), c.y);
}
`;
