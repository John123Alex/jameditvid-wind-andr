/** Constructores de parámetros para definir efectos de forma compacta. */
export const range = (key, label, min, max, def, step = 0.01) => ({ key, label, type: 'range', min, max, default: def, step });
export const color = (key, label, def) => ({ key, label, type: 'color', default: def });
export const toggle = (key, label, def = false) => ({ key, label, type: 'bool', default: def });
/** options: [['valor', 'Etiqueta'], ...] — en GLSL llega como índice float. */
export const select = (key, label, options, def = 0) => ({ key, label, type: 'select', options, default: def });
