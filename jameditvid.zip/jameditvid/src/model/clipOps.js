/**
 * Operaciones de edición puras sobre un borrador del proyecto.
 * Se usan dentro de store.update(draft => ...). No tocan el DOM.
 */
import { uid } from '../core/utils.js';
import { clipEnd, createClip, trackAccepts, createTrack } from './project.js';

const MIN_DURATION = 1 / 30;

export function findClip(draft, id) {
  return draft.clips.find((c) => c.id === id);
}

/** Primera pista compatible donde [start, start+dur) no choca con nada. */
export function findFreeTrack(draft, clipType, start, duration, preferredTrackId = null) {
  const fits = (track) =>
    trackAccepts(track, clipType) &&
    !track.locked &&
    !draft.clips.some((c) => c.trackId === track.id && c.start < start + duration && clipEnd(c) > start);

  const preferred = draft.tracks.find((t) => t.id === preferredTrackId);
  if (preferred && fits(preferred)) return preferred;
  // Para video preferimos la pista más baja (la "principal"); para texto, la más alta.
  const ordered = clipType === 'text' ? [...draft.tracks] : [...draft.tracks].reverse();
  const found = ordered.find(fits);
  if (found) return found;

  const track = createTrack(clipType === 'audio' ? 'audio' : 'video',
    `${clipType === 'audio' ? 'Audio' : 'Video'} ${draft.tracks.filter((t) => t.type === (clipType === 'audio' ? 'audio' : 'video')).length + 1}`);
  if (clipType === 'audio') draft.tracks.push(track);
  else draft.tracks.unshift(track);
  return track;
}

/** Añade un medio a la línea de tiempo. Devuelve el/los clips creados. */
export function addMediaClip(draft, media, start, preferredTrackId = null) {
  const type = media.kind; // video | image | audio
  const duration = type === 'image' ? 5 : media.duration;
  const track = findFreeTrack(draft, type, start, duration, preferredTrackId);
  const clip = createClip({ type, trackId: track.id, start, duration, media });
  draft.clips.push(clip);
  return clip;
}

export function addTextClip(draft, start, duration = 4) {
  const track = findFreeTrack(draft, 'text', start, duration);
  const clip = createClip({ type: 'text', trackId: track.id, start, duration });
  draft.clips.push(clip);
  return clip;
}

/** Divide un clip en el instante t. Devuelve el clip derecho. */
export function splitClip(draft, clipId, t) {
  const clip = findClip(draft, clipId);
  if (!clip || t <= clip.start + MIN_DURATION || t >= clipEnd(clip) - MIN_DURATION) return null;
  const right = structuredClone(clip);
  right.id = uid('clip');
  const leftDur = t - clip.start;
  right.start = t;
  right.duration = clip.duration - leftDur;
  right.offset = clip.offset + leftDur * clip.speed;
  right.effects = right.effects.map((e) => ({ ...e, id: uid('fx') }));
  clip.duration = leftDur;
  // La animación de salida pasa al clip derecho; la de entrada se queda en el izquierdo.
  clip.animOut = { ...clip.animOut, type: 'none' };
  clip.fadeOut = 0;
  right.animIn = { ...right.animIn, type: 'none' };
  right.fadeIn = 0;
  draft.clips.push(right);
  return right;
}

export function deleteClip(draft, clipId) {
  draft.clips = draft.clips.filter((c) => c.id !== clipId);
}

/** Borra el clip y desplaza a la izquierda lo que había después en su pista. */
export function rippleDelete(draft, clipId) {
  const clip = findClip(draft, clipId);
  if (!clip) return;
  deleteClip(draft, clipId);
  for (const c of draft.clips) {
    if (c.trackId === clip.trackId && c.start >= clipEnd(clip) - 1e-6) c.start -= clip.duration;
  }
}

export function duplicateClip(draft, clipId) {
  const clip = findClip(draft, clipId);
  if (!clip) return null;
  const copy = structuredClone(clip);
  copy.id = uid('clip');
  copy.effects = copy.effects.map((e) => ({ ...e, id: uid('fx') }));
  copy.start = clipEnd(clip);
  const track = findFreeTrack(draft, clip.type, copy.start, copy.duration, clip.trackId);
  copy.trackId = track.id;
  draft.clips.push(copy);
  return copy;
}

/**
 * Recorta un borde del clip.
 * @param edge 'start' | 'end'
 * @param mediaDuration duración del archivo fuente (Infinity para imagen/texto)
 */
export function trimClip(clip, edge, newTime, mediaDuration = Infinity) {
  if (edge === 'start') {
    const end = clipEnd(clip);
    // No ir antes del inicio del archivo fuente.
    const minStart = clip.start - clip.offset / clip.speed;
    const start = Math.min(Math.max(newTime, minStart, 0), end - MIN_DURATION);
    clip.offset += (start - clip.start) * clip.speed;
    clip.duration = end - start;
    clip.start = start;
  } else {
    const maxEnd = clip.start + (mediaDuration - clip.offset) / clip.speed;
    const end = Math.max(Math.min(newTime, maxEnd), clip.start + MIN_DURATION);
    clip.duration = end - clip.start;
  }
}

/** Cambia la velocidad manteniendo el mismo fragmento del archivo fuente. */
export function setClipSpeed(clip, speed) {
  const sourceLen = clip.duration * clip.speed;
  clip.speed = speed;
  clip.duration = sourceLen / speed;
}

/**
 * Magnetismo: devuelve el tiempo "imantado" más cercano si está a menos de
 * `threshold` segundos (puntos: 0, cabezal, bordes de otros clips).
 */
export function snapTime(project, t, { threshold, playhead, excludeId }) {
  let best = t;
  let bestDist = threshold;
  const consider = (p) => {
    const d = Math.abs(p - t);
    if (d < bestDist) { bestDist = d; best = p; }
  };
  consider(0);
  if (playhead != null) consider(playhead);
  for (const c of project.clips) {
    if (c.id === excludeId) continue;
    consider(c.start);
    consider(clipEnd(c));
  }
  return { time: best, snapped: best !== t };
}

/** Resuelve solapes: si un clip movido pisa otro en la misma pista, lo empuja a otra. */
export function resolveOverlap(draft, clip) {
  const overlaps = draft.clips.some(
    (c) => c.id !== clip.id && c.trackId === clip.trackId && c.start < clipEnd(clip) - 1e-6 && clipEnd(c) > clip.start + 1e-6,
  );
  if (!overlaps) return;
  const track = findFreeTrack(
    { ...draft, clips: draft.clips.filter((c) => c.id !== clip.id) },
    clip.type, clip.start, clip.duration,
  );
  if (!draft.tracks.includes(track)) {
    if (track.type === 'audio') draft.tracks.push(track); else draft.tracks.unshift(track);
  }
  clip.trackId = track.id;
}
