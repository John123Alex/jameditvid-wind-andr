/**
 * Modelo de datos del proyecto (JSON puro, serializable).
 *
 * project.tracks[0] es la pista SUPERIOR: se dibuja encima de las demás.
 * Tipos de pista: 'video' (acepta video, imagen y texto) y 'audio'.
 */
import { uid } from '../core/utils.js';

export const PROJECT_VERSION = 1;

export const RESOLUTION_PRESETS = [
  { id: '1080p', label: 'Horizontal 1080p (16:9)', w: 1920, h: 1080 },
  { id: '720p', label: 'Horizontal 720p (16:9)', w: 1280, h: 720 },
  { id: '4k', label: 'Horizontal 4K (16:9)', w: 3840, h: 2160 },
  { id: 'vertical', label: 'Vertical 9:16 (Reels/TikTok/Shorts)', w: 1080, h: 1920 },
  { id: 'square', label: 'Cuadrado 1:1 (Instagram)', w: 1080, h: 1080 },
  { id: 'portrait45', label: 'Retrato 4:5 (Instagram)', w: 1080, h: 1350 },
  { id: 'cinema', label: 'Cine 21:9', w: 2560, h: 1080 },
  { id: '43', label: 'Clásico 4:3', w: 1440, h: 1080 },
];

export function createTrack(type, name) {
  return { id: uid('trk'), type, name, muted: false, hidden: false, locked: false };
}

export function createProject(overrides = {}) {
  return {
    version: PROJECT_VERSION,
    name: 'Proyecto sin título',
    width: 1920,
    height: 1080,
    fps: 30,
    background: '#000000',
    tracks: [
      createTrack('video', 'Video 3'),
      createTrack('video', 'Video 2'),
      createTrack('video', 'Video 1'),
      createTrack('audio', 'Audio 1'),
      createTrack('audio', 'Audio 2'),
    ],
    clips: [],
    ...overrides,
  };
}

export const defaultTransform = () => ({
  x: 0, y: 0, // desplazamiento en % del lienzo desde el centro
  scale: 1,
  rotation: 0, // grados
  opacity: 1,
  fit: 'contain', // contain | cover | stretch | none
  flipH: false,
  flipV: false,
});

export const defaultText = () => ({
  content: 'Tu texto aquí',
  font: 'Inter, system-ui, sans-serif',
  size: 96,
  color: '#ffffff',
  bold: true,
  italic: false,
  align: 'center',
  lineHeight: 1.2,
  strokeColor: '#000000',
  strokeWidth: 0,
  shadow: true,
  background: false,
  bgColor: '#000000',
  bgOpacity: 0.6,
  padding: 24,
});

/** Crea un clip. `media` es el registro de la biblioteca (o null para texto). */
export function createClip({ type, trackId, start = 0, duration, media = null }) {
  const clip = {
    id: uid('clip'),
    type, // video | image | audio | text
    trackId,
    mediaId: media?.id ?? null,
    name: media?.name ?? 'Texto',
    start,
    duration: duration ?? (type === 'video' || type === 'audio' ? media.duration : 5),
    offset: 0, // punto de entrada dentro del archivo fuente (s)
    speed: 1,
    volume: 1,
    muted: false,
    fadeIn: 0,
    fadeOut: 0,
    blend: 'normal',
    transform: defaultTransform(),
    effects: [],
    animIn: { type: 'none', duration: 0.6 },
    animOut: { type: 'none', duration: 0.6 },
    motion: { type: 'none', amount: 0.15 },
  };
  if (type === 'text') clip.text = defaultText();
  if (type === 'text' || type === 'image') clip.transform.fit = type === 'text' ? 'none' : 'contain';
  return clip;
}

// ---------- Selectores (funciones puras de lectura) ----------

export const isVisual = (clip) => clip.type !== 'audio';
export const hasAudio = (clip) => clip.type === 'video' || clip.type === 'audio';
export const clipEnd = (clip) => clip.start + clip.duration;

export function projectDuration(project) {
  let d = 0;
  for (const c of project.clips) d = Math.max(d, clipEnd(c));
  return d;
}

export const trackById = (project, id) => project.tracks.find((t) => t.id === id);

export function clipsOnTrack(project, trackId) {
  return project.clips.filter((c) => c.trackId === trackId).sort((a, b) => a.start - b.start);
}

/** Clips visibles en el instante t, ordenados de fondo a frente. */
export function visualClipsAt(project, t) {
  const out = [];
  for (let i = project.tracks.length - 1; i >= 0; i--) {
    const track = project.tracks[i];
    if (track.type !== 'video' || track.hidden) continue;
    for (const c of project.clips) {
      if (c.trackId === track.id && t >= c.start && t < clipEnd(c)) out.push(c);
    }
  }
  return out;
}

/** ¿Qué tipos de clip acepta una pista? */
export const trackAccepts = (track, clipType) =>
  track.type === 'audio' ? clipType === 'audio' : clipType !== 'audio';

/** Tiempo del archivo fuente que corresponde al tiempo t de la línea. */
export const sourceTime = (clip, t) => clip.offset + (t - clip.start) * clip.speed;
