/**
 * Compositor WebGL2: combina las capas (video, imagen, texto) con sus
 * efectos, transformaciones y modos de fusión. Todo ocurre en la GPU,
 * por eso la vista previa es fluida incluso con varios efectos.
 *
 * Flujo por capa:
 *   fuente -> textura -> [pasadas de efectos en framebuffers] -> lienzo
 */
import { compileProgram, createTexture, TargetPool } from './glUtils.js';
import { PRELUDE } from '../effects/glslPrelude.js';
import { getEffectDef } from '../effects/registry.js';
import { hexToRgb } from '../core/utils.js';

const QUAD_VS = `#version 300 es
layout(location = 0) in vec2 a_pos;
out vec2 v_uv;
void main() { v_uv = a_pos; gl_Position = vec4(a_pos * 2.0 - 1.0, 0.0, 1.0); }`;

// Ubica un rectángulo (centro, tamaño, rotación) del espacio del proyecto en la salida.
const LAYER_VS = `#version 300 es
layout(location = 0) in vec2 a_pos;
uniform vec2 u_size;     // tamaño en px del proyecto (con signo para espejo)
uniform vec2 u_center;   // centro en px del proyecto
uniform vec2 u_rot;      // (cos, sin)
uniform vec4 u_frame;    // offset x, y y escala x, y del proyecto -> salida
uniform vec2 u_out;      // tamaño de la salida
out vec2 v_uv;
void main() {
  vec2 p = (a_pos - 0.5) * u_size;
  p = vec2(p.x * u_rot.x - p.y * u_rot.y, p.x * u_rot.y + p.y * u_rot.x) + u_center;
  vec2 o = u_frame.xy + p * u_frame.zw;
  gl_Position = vec4(o.x / u_out.x * 2.0 - 1.0, 1.0 - o.y / u_out.y * 2.0, 0.0, 1.0);
  v_uv = vec2(a_pos.x, 1.0 - a_pos.y);
}`;

const LAYER_FS = `#version 300 es
precision highp float;
in vec2 v_uv;
uniform sampler2D u_tex;
uniform float u_opacity;
out vec4 outColor;
void main() { outColor = texture(u_tex, v_uv) * u_opacity; }`;

export class Compositor {
  constructor(canvas) {
    this.canvas = canvas;
    this.programs = new Map();
    this.textures = new Map(); // key -> { tex, version, w, h }
    this.onError = null;
    this.#init();
    canvas.addEventListener('webglcontextlost', (e) => { e.preventDefault(); this.lost = true; });
    canvas.addEventListener('webglcontextrestored', () => { this.#init(); this.lost = false; this.onRestored?.(); });
  }

  #init() {
    const gl = this.canvas.getContext('webgl2', {
      alpha: false, antialias: false, depth: false, stencil: false,
      premultipliedAlpha: true, preserveDrawingBuffer: false, powerPreference: 'high-performance',
    });
    if (!gl) throw new Error('Tu navegador no soporta WebGL2. Actualiza el navegador para usar el editor.');
    this.gl = gl;
    this.programs.clear();
    this.textures.clear();
    this.pool = new TargetPool(gl);
    this.maxTexture = gl.getParameter(gl.MAX_TEXTURE_SIZE);

    const vao = gl.createVertexArray();
    gl.bindVertexArray(vao);
    const vbo = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, vbo);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([0, 0, 1, 0, 0, 1, 1, 1]), gl.STATIC_DRAW);
    gl.enableVertexAttribArray(0);
    gl.vertexAttribPointer(0, 2, gl.FLOAT, false, 0, 0);

    gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, true);
    gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL, true);
    this.layerProgram = compileProgram(gl, LAYER_VS, LAYER_FS, 'capa');
  }

  resize(w, h) {
    w = Math.max(2, Math.min(Math.round(w), this.maxTexture));
    h = Math.max(2, Math.min(Math.round(h), this.maxTexture));
    if (this.canvas.width !== w) this.canvas.width = w;
    if (this.canvas.height !== h) this.canvas.height = h;
  }

  /** Compila (una sola vez) el programa de una pasada de efecto. */
  #effectProgram(def, passIndex) {
    const key = `${def.id}#${passIndex}`;
    let p = this.programs.get(key);
    if (p) return p;
    const decls = def.params
      .map((pr) => `uniform ${pr.type === 'color' ? 'vec3' : 'float'} u_${pr.key};`)
      .join('\n');
    const src = `${PRELUDE}\n${decls}\n${def.passes[passIndex].glsl}`;
    p = compileProgram(this.gl, QUAD_VS, src, `efecto ${def.name}`);
    this.programs.set(key, p);
    return p;
  }

  /** Sube una fuente (video, canvas) a su textura si cambió. */
  #upload(key, source, version, w, h) {
    const gl = this.gl;
    let entry = this.textures.get(key);
    if (!entry) {
      entry = { tex: createTexture(gl), version: -1, w, h, ready: false };
      this.textures.set(key, entry);
    }
    gl.bindTexture(gl.TEXTURE_2D, entry.tex);
    if (source == null) return entry.ready ? entry : null; // reutiliza el último frame
    if (version === null || version !== entry.version) {
      try {
        gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, source);
        entry.version = version;
        entry.w = w;
        entry.h = h;
        entry.ready = true;
      } catch (err) {
        // Puede fallar si el video aún no tiene frame; se usa el anterior.
        if (!entry.ready) return null;
      }
    }
    return entry;
  }

  /** Elimina texturas de clips que ya no existen. */
  prune(aliveKeys) {
    for (const [k, e] of this.textures) {
      if (!aliveKeys.has(k)) { this.gl.deleteTexture(e.tex); this.textures.delete(k); }
    }
  }

  /**
   * Renderiza un frame.
   * @param {object} p
   * @param p.project     proyecto
   * @param p.layers      [{ clip, source, width, height, version, state, localTime }] de fondo a frente
   * @param p.fit         'contain' | 'cover' | 'stretch' (si la salida tiene otra proporción)
   */
  render({ project, layers, fit = 'contain' }) {
    if (this.lost) return;
    const gl = this.gl;
    const OW = this.canvas.width;
    const OH = this.canvas.height;
    const PW = project.width;
    const PH = project.height;

    // Mapeo proyecto -> salida
    let sx = OW / PW, sy = OH / PH;
    if (fit === 'contain') sx = sy = Math.min(sx, sy);
    else if (fit === 'cover') sx = sy = Math.max(sx, sy);
    const ox = (OW - PW * sx) / 2;
    const oy = (OH - PH * sy) / 2;

    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
    gl.viewport(0, 0, OW, OH);
    gl.disable(gl.BLEND);
    gl.clearColor(0, 0, 0, 1);
    gl.clear(gl.COLOR_BUFFER_BIT);
    // Fondo del proyecto (y recorte a su área si hay barras)
    gl.enable(gl.SCISSOR_TEST);
    const sxRect = Math.max(0, Math.round(ox));
    const syRect = Math.max(0, Math.round(OH - (oy + PH * sy)));
    gl.scissor(sxRect, syRect, Math.min(OW, Math.round(PW * sx)), Math.min(OH, Math.round(PH * sy)));
    const [br, bg, bb] = hexToRgb(project.background || '#000000');
    gl.clearColor(br, bg, bb, 1);
    gl.clear(gl.COLOR_BUFFER_BIT);

    for (const layer of layers) {
      try {
        this.#drawLayer(layer, { PW, PH, OW, OH, ox, oy, sx, sy, scissor: [sxRect, syRect, Math.round(PW * sx), Math.round(PH * sy)] });
      } catch (err) {
        console.error(err);
        this.onError?.(err, layer.clip);
      }
      this.pool.releaseAll();
    }
    gl.disable(gl.SCISSOR_TEST);
  }

  #drawLayer(layer, f) {
    const gl = this.gl;
    const { clip, source, width, height, version, state, localTime } = layer;
    const entry = this.#upload(clip.id, source, version, width, height);
    if (!entry) return;

    // --- Efectos ---
    let tex = entry.tex;
    const effects = clip.effects.filter((e) => e.enabled && getEffectDef(e.type));
    if (state.blur > 0.05) effects.push({ type: 'blur', enabled: true, params: { radius: state.blur } }); // animación «Enfocar»

    if (effects.length) {
      // Los efectos trabajan a la resolución útil (no mayor que la salida) para ahorrar GPU.
      const outMax = Math.max(f.OW, f.OH);
      const k = Math.min(1, outMax / Math.max(entry.w, entry.h));
      const w = Math.max(2, Math.round(entry.w * k));
      const h = Math.max(2, Math.round(entry.h * k));
      gl.disable(gl.SCISSOR_TEST);
      gl.disable(gl.BLEND);
      gl.viewport(0, 0, w, h);
      for (const fx of effects) {
        const def = getEffectDef(fx.type);
        const origTex = tex;
        for (let i = 0; i < def.passes.length; i++) {
          const prog = this.#effectProgram(def, i);
          const target = this.pool.acquire(w, h);
          gl.bindFramebuffer(gl.FRAMEBUFFER, target.fbo);
          prog.use();
          gl.activeTexture(gl.TEXTURE0);
          gl.bindTexture(gl.TEXTURE_2D, tex);
          prog.i1('u_tex', 0);
          gl.activeTexture(gl.TEXTURE1);
          gl.bindTexture(gl.TEXTURE_2D, origTex);
          prog.i1('u_orig', 1);
          gl.activeTexture(gl.TEXTURE0);
          prog.f2('u_res', w, h);
          prog.f1('u_time', localTime);
          for (const pr of def.params) {
            const v = fx.params[pr.key] ?? pr.default;
            if (pr.type === 'color') prog.f3(`u_${pr.key}`, hexToRgb(v));
            else if (pr.type === 'bool') prog.f1(`u_${pr.key}`, v ? 1 : 0);
            else prog.f1(`u_${pr.key}`, Number(v));
          }
          const extra = def.passes[i].uniforms;
          if (extra) for (const [n, val] of Object.entries(extra)) prog.f2(n, val[0], val[1]);
          gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
          tex = target.tex;
        }
      }
      gl.bindFramebuffer(gl.FRAMEBUFFER, null);
      gl.viewport(0, 0, f.OW, f.OH);
      gl.enable(gl.SCISSOR_TEST);
      gl.scissor(...f.scissor);
    }

    // --- Composición en el lienzo ---
    const t = clip.transform;
    let bw, bh;
    switch (t.fit) {
      case 'cover': { const s = Math.max(f.PW / entry.w, f.PH / entry.h); bw = entry.w * s; bh = entry.h * s; break; }
      case 'stretch': bw = f.PW; bh = f.PH; break;
      case 'none': bw = entry.w; bh = entry.h; break;
      default: { const s = Math.min(f.PW / entry.w, f.PH / entry.h); bw = entry.w * s; bh = entry.h * s; }
    }
    const scale = t.scale * state.scale;
    const rot = ((t.rotation + state.rotation) * Math.PI) / 180;
    const opacity = Math.max(0, Math.min(1, t.opacity * state.opacity));
    if (opacity <= 0.001 || scale === 0) return;

    const prog = this.layerProgram;
    prog.use();
    gl.activeTexture(gl.TEXTURE0);
    gl.bindTexture(gl.TEXTURE_2D, tex);
    prog.i1('u_tex', 0);
    prog.f1('u_opacity', opacity);
    prog.f2('u_size', bw * scale * (t.flipH ? -1 : 1), bh * scale * (t.flipV ? -1 : 1));
    prog.f2('u_center', f.PW / 2 + ((t.x + state.dx) / 100) * f.PW, f.PH / 2 + ((t.y + state.dy) / 100) * f.PH);
    prog.f2('u_rot', Math.cos(rot), Math.sin(rot));
    prog.f4('u_frame', f.ox, f.oy, f.sx, f.sy);
    prog.f2('u_out', f.OW, f.OH);

    gl.enable(gl.BLEND);
    switch (clip.blend) {
      case 'add': gl.blendFunc(gl.ONE, gl.ONE); break;
      case 'multiply': gl.blendFunc(gl.DST_COLOR, gl.ONE_MINUS_SRC_ALPHA); break;
      case 'screen': gl.blendFunc(gl.ONE, gl.ONE_MINUS_SRC_COLOR); break;
      default: gl.blendFunc(gl.ONE, gl.ONE_MINUS_SRC_ALPHA);
    }
    gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
    gl.disable(gl.BLEND);
  }

  /** Precompila todos los efectos (útil para detectar errores y evitar tirones). */
  warmup(defs) {
    const errors = [];
    for (const def of defs) {
      for (let i = 0; i < def.passes.length; i++) {
        try { this.#effectProgram(def, i); } catch (e) { errors.push(e.message); }
      }
    }
    return errors;
  }
}
