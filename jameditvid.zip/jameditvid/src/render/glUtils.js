/** Utilidades WebGL2: compilar shaders, crear texturas y framebuffers. */

export function compileProgram(gl, vsSource, fsSource, label = 'programa') {
  const vs = compile(gl, gl.VERTEX_SHADER, vsSource, label);
  const fs = compile(gl, gl.FRAGMENT_SHADER, fsSource, label);
  const prog = gl.createProgram();
  gl.attachShader(prog, vs);
  gl.attachShader(prog, fs);
  gl.bindAttribLocation(prog, 0, 'a_pos');
  gl.linkProgram(prog);
  gl.deleteShader(vs);
  gl.deleteShader(fs);
  if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) {
    const log = gl.getProgramInfoLog(prog);
    gl.deleteProgram(prog);
    throw new Error(`[${label}] Error al enlazar: ${log}`);
  }
  return wrapProgram(gl, prog);
}

function compile(gl, type, source, label) {
  const sh = gl.createShader(type);
  gl.shaderSource(sh, source);
  gl.compileShader(sh);
  if (!gl.getShaderParameter(sh, gl.COMPILE_STATUS)) {
    const log = gl.getShaderInfoLog(sh);
    gl.deleteShader(sh);
    throw new Error(`[${label}] Error de compilación:\n${log}`);
  }
  return sh;
}

/** Envoltorio con caché de ubicaciones de uniforms. */
function wrapProgram(gl, program) {
  const locs = new Map();
  const loc = (name) => {
    if (!locs.has(name)) locs.set(name, gl.getUniformLocation(program, name));
    return locs.get(name);
  };
  return {
    program,
    use: () => gl.useProgram(program),
    loc,
    f1: (n, v) => { const l = loc(n); if (l) gl.uniform1f(l, v); },
    f2: (n, a, b) => { const l = loc(n); if (l) gl.uniform2f(l, a, b); },
    f3: (n, a) => { const l = loc(n); if (l) gl.uniform3fv(l, a); },
    f4: (n, a, b, c, d) => { const l = loc(n); if (l) gl.uniform4f(l, a, b, c, d); },
    i1: (n, v) => { const l = loc(n); if (l) gl.uniform1i(l, v); },
    dispose: () => gl.deleteProgram(program),
  };
}

export function createTexture(gl) {
  const tex = gl.createTexture();
  gl.bindTexture(gl.TEXTURE_2D, tex);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
  return tex;
}

/** Framebuffer con textura RGBA del tamaño indicado. */
export function createTarget(gl, w, h) {
  const tex = createTexture(gl);
  gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA8, w, h, 0, gl.RGBA, gl.UNSIGNED_BYTE, null);
  const fbo = gl.createFramebuffer();
  gl.bindFramebuffer(gl.FRAMEBUFFER, fbo);
  gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, tex, 0);
  gl.bindFramebuffer(gl.FRAMEBUFFER, null);
  return { tex, fbo, w, h };
}

export function deleteTarget(gl, t) {
  gl.deleteTexture(t.tex);
  gl.deleteFramebuffer(t.fbo);
}

/** Reutiliza framebuffers por tamaño para no crear/destruir en cada frame. */
export class TargetPool {
  #free = new Map();
  #used = [];
  constructor(gl) { this.gl = gl; }

  acquire(w, h) {
    const key = `${w}x${h}`;
    const list = this.#free.get(key);
    const t = list?.pop() ?? createTarget(this.gl, w, h);
    this.#used.push(t);
    return t;
  }

  /** Devuelve al pool todo lo usado en el frame. */
  releaseAll() {
    for (const t of this.#used) {
      const key = `${t.w}x${t.h}`;
      if (!this.#free.has(key)) this.#free.set(key, []);
      const list = this.#free.get(key);
      if (list.length < 6) list.push(t); else deleteTarget(this.gl, t);
    }
    this.#used.length = 0;
  }

  dispose() {
    this.releaseAll();
    for (const list of this.#free.values()) for (const t of list) deleteTarget(this.gl, t);
    this.#free.clear();
  }
}
