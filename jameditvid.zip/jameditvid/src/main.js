/** Punto de entrada. */
import './styles/variables.css';
import './styles/base.css';
import './styles/layout.css';
import './styles/components.css';
import './styles/timeline.css';
import './styles/responsive.css';
import { App } from './app/App.js';

new App().start().catch((err) => {
  console.error(err);
  const el = document.getElementById('fatal');
  el.hidden = false;
  el.querySelector('p').textContent = err.message;
});

// Service worker (solo en producción): permite instalar la app en el celular y usarla sin conexión.
if ('serviceWorker' in navigator && import.meta.env.PROD) {
  window.addEventListener('load', () => navigator.serviceWorker.register('./sw.js').catch(() => {}));
}
