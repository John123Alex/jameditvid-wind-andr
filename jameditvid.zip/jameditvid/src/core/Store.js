/**
 * Store central del proyecto con historial (deshacer / rehacer).
 *
 * - El proyecto es JSON puro (sin archivos): clonarlo es barato.
 * - Cada edición se hace sobre un borrador clonado y se guarda una
 *   instantánea anterior en el historial.
 * - `coalesce`: ediciones seguidas con la misma clave (p. ej. arrastrar un
 *   deslizador) se agrupan en un solo paso de deshacer.
 * - La posición de reproducción NO vive aquí (cambia 60 veces/s): la maneja
 *   el PlaybackEngine para no re-renderizar la interfaz en cada frame.
 */
export class Store {
  #project;
  #selection = null; // id del clip seleccionado
  #undo = [];
  #redo = [];
  #listeners = new Set();
  #lastCoalesce = { key: null, at: 0 };

  constructor(project, { historyLimit = 150 } = {}) {
    this.#project = project;
    this.historyLimit = historyLimit;
  }

  get project() { return this.#project; }
  get selection() { return this.#selection; }
  get canUndo() { return this.#undo.length > 0; }
  get canRedo() { return this.#redo.length > 0; }

  get selectedClip() {
    return this.#selection ? this.#project.clips.find((c) => c.id === this.#selection) ?? null : null;
  }

  /** Suscribirse a cambios. fn({ type: 'project'|'selection', reason }) */
  subscribe(fn) {
    this.#listeners.add(fn);
    return () => this.#listeners.delete(fn);
  }

  #notify(change) {
    for (const fn of [...this.#listeners]) {
      try { fn(change); } catch (e) { console.error('[store]', e); }
    }
  }

  /**
   * Modifica el proyecto.
   * @param {(draft) => void} mutator  muta el borrador
   * @param {{label?: string, coalesce?: string, history?: boolean}} opts
   */
  update(mutator, { label = 'Edición', coalesce = null, history = true } = {}) {
    const draft = structuredClone(this.#project);
    const result = mutator(draft);
    if (result === false) return; // el mutador canceló

    if (history) {
      const now = performance.now();
      const merge = coalesce && this.#lastCoalesce.key === coalesce && now - this.#lastCoalesce.at < 900;
      if (!merge) {
        this.#undo.push({ project: this.#project, label, selection: this.#selection });
        if (this.#undo.length > this.historyLimit) this.#undo.shift();
      }
      this.#lastCoalesce = { key: coalesce, at: now };
      this.#redo.length = 0;
    }
    this.#project = draft;
    if (this.#selection && !draft.clips.some((c) => c.id === this.#selection)) this.#selection = null;
    this.#notify({ type: 'project', reason: label });
  }

  /** Reemplaza el proyecto completo (abrir / nuevo). Limpia el historial. */
  replace(project) {
    this.#project = project;
    this.#selection = null;
    this.#undo.length = 0;
    this.#redo.length = 0;
    this.#notify({ type: 'project', reason: 'replace' });
    this.#notify({ type: 'selection' });
  }

  undo() {
    const entry = this.#undo.pop();
    if (!entry) return;
    this.#redo.push({ project: this.#project, label: entry.label, selection: this.#selection });
    this.#project = entry.project;
    this.#selection = entry.selection;
    this.#lastCoalesce.key = null;
    this.#notify({ type: 'project', reason: `Deshacer: ${entry.label}` });
    this.#notify({ type: 'selection' });
  }

  redo() {
    const entry = this.#redo.pop();
    if (!entry) return;
    this.#undo.push({ project: this.#project, label: entry.label, selection: this.#selection });
    this.#project = entry.project;
    this.#lastCoalesce.key = null;
    this.#notify({ type: 'project', reason: `Rehacer: ${entry.label}` });
  }

  select(clipId) {
    if (clipId === this.#selection) return;
    this.#selection = clipId;
    this.#notify({ type: 'selection' });
  }
}
